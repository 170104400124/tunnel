package com.tunnel.dao.android;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;

import com.tunnel.model.DutyData;

import java.util.List;

import tunnel.JDBC.DBOpenHelper;

/**
 * Created by Leon on 2019/5/6.
 */

public class DutyImp {


    Context context = null;
    public DutyImp(Context context) {
        this.context = context;
    }

    public List<DutyData> getDutyList(String userId) {
        String sql = "select * from duty where user_id = '" + userId + "'";
        List<DutyData> list = AndroidUtils.query2JavaBeans(sql, context, DutyData.class);

        return list;
    }



    public boolean insert(DutyData data) {
        DBOpenHelper dbHelper = new DBOpenHelper(context);
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues cv = new ContentValues();

        cv.put("user_id", data.getUser_id());
        cv.put("tunnel_id", data.getTunnel_id());

        db.insert("duty", null, cv);
        db.close();
        return true;
    }

    public boolean delete(String user_id) {
        DBOpenHelper dbHelper = new DBOpenHelper(context);
        SQLiteDatabase db = dbHelper.getWritableDatabase();

        String whereCaluse = "user_id=?";
        String whereArgs[] = new String[]{user_id};

        db.delete("duty", whereCaluse, whereArgs);
        db.close();
        return true;
    }
}
