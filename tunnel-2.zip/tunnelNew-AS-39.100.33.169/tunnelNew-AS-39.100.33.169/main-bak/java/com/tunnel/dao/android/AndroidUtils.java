package com.tunnel.dao.android;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.google.gson.Gson;
import com.google.gson.JsonIOException;
import com.google.gson.JsonObject;

import tunnel.JDBC.DBOpenHelper;

public class AndroidUtils {

	public List<Map<String,Object>> fetch(String query, Context context) {
		DBOpenHelper dbHelper = new DBOpenHelper(context);
		SQLiteDatabase db = dbHelper.getReadableDatabase();
		Cursor c = db.rawQuery(query, null);
		int count = c.getCount();

		List<Map<String,Object>> list = new ArrayList<Map<String,Object>>();
		String[] coloms = c.getColumnNames();//[_id,name] 有多少字段项
		while(c.moveToNext()){
			Map<String, Object> map = getResultMap(c);
			list.add(map);
		}
		return list;
	}

	public static Map<String, Object> getResultMap(Cursor c) {
		int count = c.getColumnCount();
		Map<String, Object> map = new HashMap<String, Object>();
		for(int i=0;i<count;i++){
            String key = c.getColumnName(i);
            Object values = null;
            int type = c.getType(i);
            switch (type) {
                case Cursor.FIELD_TYPE_BLOB:
                    values = c.getBlob(i);
                    break;
                case Cursor.FIELD_TYPE_FLOAT:
                    values = c.getFloat(i);
                    break;
                case Cursor.FIELD_TYPE_INTEGER:
                    values = c.getInt(i);
                    break;
                case Cursor.FIELD_TYPE_STRING:
                    values = c.getString(i);
                    break;

                default:
                    break;
            }
            map.put(key, values);
        }
		return map;
	}

	private static List<String> resultSetToJsonList(Cursor c) throws SQLException, JsonIOException {
		// json数组
		List<String> jsonList = new ArrayList<String>();

		// 获取列数
		int columnCount = c.getColumnCount();

		// 遍历ResultSet中的每条数据
		while (c.moveToNext()) {
			JsonObject jsonObj = new JsonObject();

			// 遍历每一列
			for (int i = 0; i < columnCount; i++) {
				String columnName = c.getColumnName(i);
				String value = c.getString(i);
				jsonObj.addProperty(columnName, value);
			}
			jsonList.add(jsonObj.toString());
		}

		return jsonList;
	}
	
	/**
	 * 根据sql 查询结果，并用json格式表示javabean。
	 * @param sql select 查询语句
	 * @return 字符串列表，每个元素是javabean的json表示。
	 */
	public static List<String> querySql(String sql, Context context) {
		List<String> jsonList = null;
        DBOpenHelper dbHelper = new DBOpenHelper(context);
        SQLiteDatabase db = dbHelper.getReadableDatabase();
		try {
            Cursor c = db.rawQuery(sql, null);

			jsonList = AndroidUtils.resultSetToJsonList(c);
		} catch (SQLException e) {
			e.getStackTrace();
		}

		db.close();
		return jsonList;
	}

	/**
	 * 根据sql语句，直接返回符合要求的javabean 列表
	 * @param sql 查询语句
	 * @param T javabean 类型
	 * @return 符合条件的javabean 列表
	 */
	public static <T> List<T> query2JavaBeans(String sql, Context context, Class T) {
		List<String> jsonList = querySql(sql, context);
		List<T> beanList = new ArrayList<T>();
		
		Gson gson = new Gson();
		for(String json : jsonList) {
			T bean = (T) gson.fromJson(json, T);
			beanList.add(bean);
		}
		return beanList;
	}
}
