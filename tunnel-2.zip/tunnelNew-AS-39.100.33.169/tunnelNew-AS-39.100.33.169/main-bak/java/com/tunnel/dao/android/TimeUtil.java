package com.tunnel.dao.android;

/**
 * Created by Leon on 2019/5/6.
 */

public class TimeUtil {
    public static java.util.Date toJavaDate(java.sql.Timestamp sqlTimeStamp) {
        return new java.util.Date(sqlTimeStamp.getTime());
    }

    public static java.sql.Timestamp toSqlTimeStamp(java.util.Date date) {
        java.sql.Timestamp sqlTimestamp = new java.sql.Timestamp(date.getTime());
        return sqlTimestamp;
    }
}
