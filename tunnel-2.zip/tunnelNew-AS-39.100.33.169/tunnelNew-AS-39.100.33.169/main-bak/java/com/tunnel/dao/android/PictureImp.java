package com.tunnel.dao.android;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;

import com.tunnel.model.PictureData;

import java.util.List;

import tunnel.JDBC.DBOpenHelper;

/**
 * Created by Leon on 2019/5/6.
 */

public class PictureImp {
    Context context = null;

    public PictureImp(Context context) {
        this.context = context;
    }

    public boolean insert(PictureData data) {
        DBOpenHelper dbHelper = new DBOpenHelper(context);
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        String sql = "INSERT or replace INTO picture ('key', address) VALUES (?, ?)";
        SQLiteStatement stmt = db.compileStatement(sql);
        db.execSQL(sql,new Object[]{data.getKey(), data.getAddress() });
        db.close();

//        ContentValues cv=new ContentValues();
//
//        cv.put("key", data.getKey());
//        cv.put("address", data.getAddress());
//        cv.put("picture", data.getPicture());//图片转为二进制
//        long result = db.insert("picture", null, cv);
//
//        db.close();
        return true;
    }

    public List<PictureData> getAll() {
        String sql = "select * from picture ";
        List<PictureData> list = AndroidUtils.query2JavaBeans(sql, context, PictureData.class);

        return list;
    }

    public List<PictureData> get(String key) {
        String sql = "select * from picture where key = '" + key + "'";
        List<PictureData> list = AndroidUtils.query2JavaBeans(sql, context, PictureData.class);

        return list;
    }
}
