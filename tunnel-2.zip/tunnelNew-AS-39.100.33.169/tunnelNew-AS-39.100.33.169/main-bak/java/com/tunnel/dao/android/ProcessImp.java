package com.tunnel.dao.android;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;

import com.tunnel.model.ProcessData;

import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import tunnel.JDBC.DBOpenHelper;

/**
 * Created by Leon on 2019/5/6.
 */

public class ProcessImp {


    Context context = null;
    public ProcessImp(Context context) {
        this.context = context;
    }

    public List<ProcessData> fetchAll() {
        String sql = "select * from process";
        List<ProcessData> list = AndroidUtils.query2JavaBeans(sql, context, ProcessData.class);

        return list;
    }

}
