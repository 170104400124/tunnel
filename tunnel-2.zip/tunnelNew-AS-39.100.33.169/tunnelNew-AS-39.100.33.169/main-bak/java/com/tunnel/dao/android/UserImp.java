package com.tunnel.dao.android;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.widget.Toast;

import com.tunnel.model.DutyData;
import com.tunnel.model.LogData;
import com.tunnel.model.UserData;

import java.util.List;

import tunnel.JDBC.DBOpenHelper;
import tunnel.LoginActivity;
import tunnel.model.MD5Utils;

/**
 * Created by Leon on 2019/5/6.
 */

public class UserImp {


    Context context = null;
    public UserImp(Context context) {
        this.context = context;
    }

    public List<UserData> getUser(String userId, String password) {
        String sql = "select * from user where user_id='" + userId +"' and password= '"+password+"'";
        List<UserData> list = AndroidUtils.query2JavaBeans(sql, context, UserData.class);

        return list;
    }

    public boolean isExist(String userId) {
        String sql = "select * from user where user_id='" + userId +"' ";
        List<UserData> list = AndroidUtils.query2JavaBeans(sql, context, UserData.class);

        return list.size() > 0;
    }

    public boolean update(UserData ud) {
        DBOpenHelper dbHelper = new DBOpenHelper(context);
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues cv=new ContentValues();
        cv.put("user_id",  ud.getUser_id());
        cv.put("password", ud.getPassword());
        cv.put("phone", ud.getPhone());
        cv.put("position", ud.getPosition());

        String whereCaluse = "user_id=?";
        String whereArgs[] = new String[]{ud.getUser_id()};

        db.update("user", cv, whereCaluse, whereArgs);
        db.close();
        return true;
    }

    public boolean update(String user_id, String password) {
        DBOpenHelper dbHelper = new DBOpenHelper(context);
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues cv=new ContentValues();
        cv.put("user_id",  user_id);
        cv.put("password", password);

        String whereCaluse = "user_id=?";
        String whereArgs[] = new String[]{user_id};

        db.update("user", cv, whereCaluse, whereArgs);
        db.close();
        return true;
    }


    public boolean insert(UserData ud) {
        DBOpenHelper dbHelper = new DBOpenHelper(context);
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues cv = new ContentValues();

        cv.put("user_id", ud.getUser_id());
        cv.put("password", ud.getPassword());

        db.insert("user", null, cv);
        db.close();
        return true;
    }

}
