package com.tunnel.dao.android;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;

import com.tunnel.model.LogData;
import com.tunnel.model.PictureData;

import java.text.SimpleDateFormat;
import java.util.Date;

import tunnel.JDBC.DBOpenHelper;

/**
 * Created by Leon on 2019/5/6.
 */

public class LogImp {
    Context context = null;
    SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");// HH:mm:ss

    public LogImp(Context context) {
        this.context = context;
    }

    public boolean insert(LogData data) {
        DBOpenHelper dbHelper = new DBOpenHelper(context);
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues cv = new ContentValues();

        cv.put("explanation", data.getExplanation());
        cv.put("user_id", data.getUser_id());
        cv.put("tunnel_id", data.getTunnel_id());
        cv.put("process_id", data.getProcess_id());
        cv.put("old_rock", data.getOldRock());
        cv.put("new_rock", data.getNewRock());
        cv.put("footage_id", data.getFootage_id());
        cv.put("report_footage", data.getReport_footage());

        cv.put("save_time", simpleDateFormat.format(data.getSave_time()));
        cv.put("key", data.getKey());
        cv.put("isUpload", data.getIsUpload());

        db.insert("log", null, cv);
        db.close();
        return true;
    }

    public boolean update(LogData data, String firstKey) {
        DBOpenHelper dbHelper = new DBOpenHelper(context);
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues cv=new ContentValues();
        cv.put("explanation", data.getExplanation());
        cv.put("user_id", data.getUser_id());
        cv.put("tunnel_id", data.getTunnel_id());
        cv.put("process_id", data.getProcess_id());
        cv.put("old_rock", data.getOldRock());
        cv.put("new_rock", data.getNewRock());
        cv.put("report_footage", data.getReport_footage());

        cv.put("save_time", simpleDateFormat.format(data.getSave_time()));
        //cv.put("key", data.getKey());
        //cv.put("report_footage", offset);
        cv.put("isUpload", data.getIsUpload());
        String whereCaluse = "key=?";
        String whereArgs[] = new String[]{String.valueOf(firstKey)};

        db.update("log", cv, whereCaluse, whereArgs);
        db.close();
        return true;
    }

    public boolean insertRemark(LogData data) {
        DBOpenHelper dbHelper = new DBOpenHelper(context);
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        String sql = "INSERT or replace  INTO log (explanation, user_id, tunnel_id, process_id, save_time, 'key', report_footage, isUpload) VALUES (?, ?,?, ?,?, ?,?, ?)";
        SQLiteStatement stmt = db.compileStatement(sql);
        db.execSQL(sql,new Object[]{data.getExplanation(), data.getUser_id(),data.getTunnel_id() , data.getProcess_id(), simpleDateFormat.format(data.getSave_time()),data.getKey(),   data.getOffset(),data.getIsUpload() });
        db.close();
//        ContentValues cv=new ContentValues();
//
//        cv.put("explanation", data.getExplanation());
//        cv.put("user_id", data.getUser_id());
//        cv.put("tunnel_id", data.getTunnel_id());
//        cv.put("process_id", data.getProcess_id());
//
//        cv.put("save_time", simpleDateFormat.format(data.getSave_time()));
//        cv.put("key", data.getKey());
//        cv.put("report_footage", data.getOffset());
//        cv.put("isUpload", data.getIsUpload());
//
//        db.insert("log", null, cv);
//        db.close();
        return true;
    }
}
