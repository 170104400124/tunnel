package com.tunnel.model;

import java.sql.Timestamp;

public class OffsetData {
	/**
	 * 自增id，主键
	 */
	private int id;
	private String tunnel_id;
	private String user_id;
	/**
	 * 流程id，比如锚杆，超前钻孔等
	 */
	private String process_id;
	//进尺数？
	private String report_footage;
	/**
	 * 总进尺数
	 */
	private String sum_footage;
	// ?
	private String offset;
    /**
	 * log 表唯一键，用来和picture表进行关联
	 */
	private String key;
	/**
	 * 记录时间
	 */
	private Timestamp save_time;
	/**
	 * 上传时间
	 */
	private Timestamp upload_time;
	/**
	 * 备注
	 */
	private String explanation;
	/**
	 * 是否上传
	 */
	private boolean isUpload;


	public OffsetData() {
	}

	public OffsetData(String tunnel_id, String user_id, String process_id, String report_footage, String sum_footage,
			String offset) {
		super();
		this.tunnel_id = tunnel_id;
		this.user_id = user_id;
		this.process_id = process_id;
		this.report_footage = report_footage;
		this.sum_footage = sum_footage;
		this.offset = offset;
	}

	public String getTunnel_id() {
		return tunnel_id;
	}

	public void setTunnel_id(String tunnel_id) {
		this.tunnel_id = tunnel_id;
	}

	public String getUser_id() {
		return user_id;
	}

	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}

	public String getProcess_id() {
		return process_id;
	}

	public void setProcess_id(String process_id) {
		this.process_id = process_id;
	}

	public String getReport_footage() {
		return report_footage;
	}

	public void setReport_footage(String report_footage) {
		this.report_footage = report_footage;
	}

	public String getSum_footage() {
		return sum_footage;
	}

	public void setSum_footage(String sum_footage) {
		this.sum_footage = sum_footage;
	}

	public String getOffset() {
		return offset;
	}

	public void setOffset(String offset) {
		this.offset = offset;
	}

	public Timestamp getSave_time() {
		return save_time;
	}

	public void setSave_time(Timestamp save_time) {
		this.save_time = save_time;
	}

	public Timestamp getUpload_time() {
		return upload_time;
	}

	public void setUpload_time(Timestamp upload_time) {
		this.upload_time = upload_time;
	}

	public boolean getIsUpload() {
		return isUpload;
	}

	public void setIsUpload(boolean isUpload) {
		this.isUpload = isUpload;
	}


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public String getExplanation() {
        return explanation;
    }

    public void setExplanation(String explanation) {
        this.explanation = explanation;
    }

    public boolean isUpload() {
        return isUpload;
    }

    public void setUpload(boolean upload) {
        isUpload = upload;
    }

}
