package com.tunnel.model;

public class DutyData {


	/**
	 * 自增id
	 */
	private int id;
	private String user_id;
	private String tunnel_id;
	
	public DutyData() {
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getUser_id() {
		return user_id;
	}

	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}

	public String getTunnel_id() {
		return tunnel_id;
	}

	public void setTunnel_id(String tunnel_id) {
		this.tunnel_id = tunnel_id;
	}
	
	
}
