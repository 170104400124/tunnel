package com.tunnel.model;

//import com.mysql.jdbc.Blob;

/**
 * 岩石等级？
 */
public class GradeData {
	private int tunnel_id;
	private int user_id;
	private int process_id;
//	private Blob picture;
	private String modify_footageString;
	private String description;
	
	public GradeData() {
	}

	public int getTunnel_id() {
		return tunnel_id;
	}

	public void setTunnel_id(int tunnel_id) {
		this.tunnel_id = tunnel_id;
	}

	public int getUser_id() {
		return user_id;
	}

	public void setUser_id(int user_id) {
		this.user_id = user_id;
	}

	public int getProcess_id() {
		return process_id;
	}

	public void setProcess_id(int process_id) {
		this.process_id = process_id;
	}

//	public Blob getPicture() {
//		return picture;
//	}
//
//	public void setPicture(Blob picture) {
//		this.picture = picture;
//	}

	public String getModify_footageString() {
		return modify_footageString;
	}

	public void setModify_footageString(String modify_footageString) {
		this.modify_footageString = modify_footageString;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}
	
	
}
