package com.tunnel.model;

/**
 * 设计要求，对标DesignInfo_V_plus, DesignInfo_V
 */
public class ProcessData {
	/**
	 * 主键, 不是自增id
	 */
	private String process_id;
	/**
	 * 等级，例如 V+,V,IV 等
	 */
	private String rock_grade;
	/**
	 * 子流程，例如小导管安装，锚杆等
	 */
	private String subprocess;
	/**
	 * 未使用
	 */
	private String lowprocess;
	/**
	 * 设计要求
	 */
	private String requirement;
	
	public ProcessData() {
	}

	public String getProcess_id() {
		return process_id;
	}

	public void setProcess_id(String process_id) {
		this.process_id = process_id;
	}

	public String getRock_grade() {
		return rock_grade;
	}

	public void setRock_grade(String rock_grade) {
		this.rock_grade = rock_grade;
	}

	public String getSubprocess() {
		return subprocess;
	}

	public void setSubprocess(String subprocess) {
		this.subprocess = subprocess;
	}

	public String getLowprocess() {
		return lowprocess;
	}

	public void setLowprocess(String lowprocess) {
		this.lowprocess = lowprocess;
	}

	public String getRequirement() {
		return requirement;
	}

	public void setRequirement(String requirement) {
		this.requirement = requirement;
	}
	
	
}
