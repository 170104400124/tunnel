package com.tunnel.model;

import java.sql.Timestamp;

public class LogShowData {
    //-------------------------------------------------------------------
    //---- 来自 user 表
    //-------------------------------------------------------------------
	private String user_name;
	private String position;

    //-------------------------------------------------------------------
    //---- 来自 log 表
    //-------------------------------------------------------------------
	private String zuankongLength;
	private String report_footage;
	private String sum_footage;
	private String offset;
	private Timestamp save_time;
	private Timestamp upload_time;
	/**
	 * 备注
	 */
	private String explanation;

    //-------------------------------------------------------------------
    //---- 来自 tunnel 表
    //-------------------------------------------------------------------
	/**
	 * 例如，隧道二分部
	 */
	private String tunnel_section;
	/**
	 * 隧道名，例如梯子岭隧道
	 */
	private String tunnel_name;
	/**
	 * 进口/出口
	 */
	private String tunnel_subface;

    //-------------------------------------------------------------------
    //---- 来自 picture 表
    //-------------------------------------------------------------------
	/**
	 * 照片保存路径
	 */
	private String pic;

    //-------------------------------------------------------------------
    //---- 来自 process 表
    //-------------------------------------------------------------------
	/**
	 * 等级，例如 V+,V,IV 等
	 */
	private String rock_grade;
	
	public LogShowData(String user_name, String position, String report_footage, String sum_footage, String offset,
			Timestamp save_time, Timestamp upload_time, String explanation, String tunnel_section, String tunnel_name,
			String tunnel_subface, String pic, String rock_grade) {
		super();
		this.user_name = user_name;
		this.position = position;
		this.report_footage = report_footage;
		this.sum_footage = sum_footage;
		this.offset = offset;
		this.save_time = save_time;
		this.upload_time = upload_time;
		this.explanation = explanation;
		this.tunnel_section = tunnel_section;
		this.tunnel_name = tunnel_name;
		this.tunnel_subface = tunnel_subface;
		this.pic = pic;
		this.rock_grade = rock_grade;
	}

	public LogShowData(String user_name, String position, String zuankongLength, String report_footage, String sum_footage, String offset, Timestamp save_time, Timestamp upload_time, String explanation, String tunnel_section, String tunnel_name, String tunnel_subface, String pic, String rock_grade) {
		this.user_name = user_name;
		this.position = position;
		this.zuankongLength = zuankongLength;
		this.report_footage = report_footage;
		this.sum_footage = sum_footage;
		this.offset = offset;
		this.save_time = save_time;
		this.upload_time = upload_time;
		this.explanation = explanation;
		this.tunnel_section = tunnel_section;
		this.tunnel_name = tunnel_name;
		this.tunnel_subface = tunnel_subface;
		this.pic = pic;
		this.rock_grade = rock_grade;
	}

	public String getZuankongLength() {
		return zuankongLength;
	}

	public void setZuankongLength(String zuankongLength) {
		this.zuankongLength = zuankongLength;
	}

	public String getPic() {
		return pic;
	}

	public void setPic(String pic) {
		this.pic = pic;
	}

	public String getRock_grade() {
		return rock_grade;
	}

	public void setRock_grade(String rock_grade) {
		this.rock_grade = rock_grade;
	}

	public String getPicture() {
		return pic;
	}

	public void setPicture(String picture) {
		this.pic = picture;
	}

	public String getUser_name() {
		return user_name;
	}
	public void setUser_name(String user_name) {
		this.user_name = user_name;
	}
	public String getPosition() {
		return position;
	}
	public void setPosition(String position) {
		this.position = position;
	}
	public String getReport_footage() {
		return report_footage;
	}
	public void setReport_footage(String
										  report_footage) {
		this.report_footage = report_footage;
	}
	public String getSum_footage() {
		return sum_footage;
	}
	public void setSum_footage(String sum_footage) {
		this.sum_footage = sum_footage;
	}
	public String getOffset() {
		return offset;
	}
	public void setOffset(String offset) {
		this.offset = offset;
	}
	public Timestamp getSave_time() {
		return save_time;
	}
	public void setSave_time(Timestamp save_time) {
		this.save_time = save_time;
	}
	public Timestamp getUpload_time() {
		return upload_time;
	}
	public void setUpload_time(Timestamp upload_time) {
		this.upload_time = upload_time;
	}
	public String getExplanation() {
		return explanation;
	}
	public void setExplanation(String explanation) {
		this.explanation = explanation;
	}
	public String getTunnel_section() {
		return tunnel_section;
	}
	public void setTunnel_section(String tunnel_section) {
		this.tunnel_section = tunnel_section;
	}
	public String getTunnel_name() {
		return tunnel_name;
	}
	public void setTunnel_name(String tunnel_name) {
		this.tunnel_name = tunnel_name;
	}
	public String getTunnel_subface() {
		return tunnel_subface;
	}
	public void setTunnel_subface(String tunnel_subface) {
		this.tunnel_subface = tunnel_subface;
	}
	
	
	
}
