package com.tunnel.model;

import java.util.Date;

public class LogData {
	/**
	 * 自增id，主键
	 */
	private int id;
	private String user_id;
	private String tunnel_id;
	private String footage_id;
	/**
	 * 流程id，比如锚杆，超前钻孔等
	 */
	/**
	 * 超前钻孔长度
	 */
	private String zuankongLength;
	private String process_id;
	//分段进尺数
	private String report_footage;
	/**
	 * 总进尺数
	 */
	private String sum_footage;
	// 进尺数差值
	private String offset;
	/**
	 * log 表唯一键，用来和picture表进行关联
	 */
	private String key;

    /**
	 * 记录时间
	 */
	private Date save_time;
	/**
	 * 上传时间
	 */
	private Date upload_time;
	/**
	 * 备注
	 */
	private String explanation;
	/**
	 * 是否上传
	 */
	private int isUpload;

	/*
	 *原设计围岩等级
	 */
	private String oldRock;

	/*
	 *变更围岩等级
	 */
	private String newRock;

	public LogData() {
	}

	public String getReport_footage() {
		return report_footage;
	}


	public String getOldRock() {
		return oldRock;
	}

	public void setOldRock(String oldRock) {
		this.oldRock = oldRock;
	}

	public String getNewRock() {
		return newRock;
	}

	public void setNewRock(String newRock) {
		this.newRock = newRock;
	}

	public void setReport_footage(String report_footage) {
		this.report_footage = report_footage;
	}



	public String getSum_footage() {
		return sum_footage;
	}



	public void setSum_footage(String sum_footage) {
		this.sum_footage = sum_footage;
	}



	public String getOffset() {
		return offset;
	}

	public String getFootage_id() {
		return footage_id;
	}

	public void setFootage_id(String footage_id) {
		this.footage_id = footage_id;
	}

	public void setOffset(String offset) {
		this.offset = offset;
	}



	public String getKey() {
		return key;
	}



	public void setKey(String key) {
		this.key = key;
	}



	public int getIsUpload() {
		return isUpload;
	}



	public void setIsUpload(int isUpload) {
		this.isUpload = isUpload;
	}



	public int getId() {
		return id;
	}



	public void setId(int id) {
		this.id = id;
	}



	public LogData(String user_id, String tunnel_id, String process_id, String explanation) {
		super();
		this.user_id = user_id;
		this.tunnel_id = tunnel_id;
		this.process_id = process_id;
		this.explanation = explanation;
	}

	public String getZuankongLength() {
		return zuankongLength;
	}

	public void setZuankongLength(String zuankongLength) {
		this.zuankongLength = zuankongLength;
	}

	public LogData(String report_footage, Date storage_time, Date upload_time, String explanation) {
		super();
		this.report_footage = report_footage;
		this.save_time = save_time;
		this.upload_time = upload_time;
		this.explanation = explanation;
	}

	public String getUser_id() {
		return user_id;
	}

	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}

	public String getTunnel_id() {
		return tunnel_id;
	}

	public void setTunnel_id(String tunnel_id) {
		this.tunnel_id = tunnel_id;
	}

	public String getProcess_id() {
		return process_id;
	}

	public void setProcess_id(String process_id) {
		this.process_id = process_id;
	}

	public Date getUpload_time() {
		return upload_time;
	}

	public void setUpload_time(Date upload_time) {
		this.upload_time = upload_time;
	}

	public String getExplanation() {
		return explanation;
	}

	public void setExplanation(String explanation) {
		this.explanation = explanation;
	}

    public Date getSave_time() {
        return save_time;
    }

    public void setSave_time(Date save_time) {
        this.save_time = save_time;
    }
	
}
