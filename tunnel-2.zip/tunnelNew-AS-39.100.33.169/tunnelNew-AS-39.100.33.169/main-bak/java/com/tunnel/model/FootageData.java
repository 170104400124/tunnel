package com.tunnel.model;

public class FootageData {
	private int tunnel_id;
	private double tunnel_starting;
	private double tunnel_end;
	private String tunnel_grade;
	private int isFinish;
	private double length;
	private String footage_id;
	
	public FootageData() {
	}

	public int getTunnel_id() {
		return tunnel_id;
	}

	public void setTunnel_id(int tunnel_id) {
		this.tunnel_id = tunnel_id;
	}

	public double getTunnel_starting() {
		return tunnel_starting;
	}

	public void setTunnel_starting(double tunnel_starting) {
		this.tunnel_starting = tunnel_starting;
	}

	public double getTunnel_end() {
		return tunnel_end;
	}

	public void setTunnel_end(double tunnel_end) {
		this.tunnel_end = tunnel_end;
	}

	public String getTunnel_grade() {
		return tunnel_grade;
	}

	public void setTunnel_grade(String tunnel_grade) {
		this.tunnel_grade = tunnel_grade;
	}

	public int getIsFinish() {
		return isFinish;
	}

	public void setIsFinish(int isFinish) {
		this.isFinish = isFinish;
	}

	public double getLength() {
		return length;
	}

	public void setLength(double length) {
		this.length = length;
	}

	public String getFootage_id() {
		return footage_id;
	}

	public void setFootage_id(String footage_id) {
		this.footage_id = footage_id;
	}
}
