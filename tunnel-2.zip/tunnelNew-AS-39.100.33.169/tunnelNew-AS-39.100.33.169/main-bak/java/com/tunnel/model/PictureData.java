package com.tunnel.model;

public class PictureData {
    /**
     * 主键
     */
    private int id;
	/**
	 * 照片保存路径
	 */
	private String address;
	/**
	 * log key（外键），用来和log 表进行关联。
	 * 一条log表记录，都有一个uniq key；每个uniq key 对应多张张片。
	 */
	private String key;

    /**
     * 二进制照片数据
     */
    byte[] picture = null;


	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getKey() {
		return key;
	}
	public void setKey(String key) {
		this.key = key;
	}

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }


//    public byte[] getPicture() {
//        return picture;
//    }
//
//    public void setPicture(byte[] picture) {
//        this.picture = picture;
//    }
}
