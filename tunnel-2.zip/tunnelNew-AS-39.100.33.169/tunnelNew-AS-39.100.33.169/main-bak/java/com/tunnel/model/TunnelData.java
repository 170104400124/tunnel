package com.tunnel.model;

public class TunnelData {
	/**
	 * 主键
	 */
	private String tunnel_id;
	/**
	 * 例如，隧道二分部
	 */
	private String tunnel_section;
	/**
	 * 隧道名，例如梯子岭隧道
	 */
	private String tunnel_name;
	/**
	 * 进口/出口
	 */
	private String tunnel_subface;
	private String remarks;
	
	public TunnelData(String tunnel_id, String tunnel_section, String tunnel_name, String tunnel_subface,
			String remarks) {
		super();
		this.tunnel_id = tunnel_id;
		this.tunnel_section = tunnel_section;
		this.tunnel_name = tunnel_name;
		this.tunnel_subface = tunnel_subface;
		this.remarks = remarks;
	}

	public TunnelData() {
	}

	public String getTunnel_id() {
		return tunnel_id;
	}

	public void setTunnel_id(String tunnel_id) {
		this.tunnel_id = tunnel_id;
	}

	public String getTunnel_section() {
		return tunnel_section;
	}

	public void setTunnel_section(String tunnel_section) {
		this.tunnel_section = tunnel_section;
	}

	public String getTunnel_name() {
		return tunnel_name;
	}

	public void setTunnel_name(String tunnel_name) {
		this.tunnel_name = tunnel_name;
	}

	public String getTunnel_subface() {
		return tunnel_subface;
	}

	public void setTunnel_subface(String tunnel_subface) {
		this.tunnel_subface = tunnel_subface;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	
	
}
