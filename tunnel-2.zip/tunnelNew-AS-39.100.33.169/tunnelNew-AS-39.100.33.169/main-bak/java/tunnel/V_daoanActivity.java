package tunnel;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import com.jie.cameraimage.R;

import android.app.Activity;
import android.content.res.AssetManager;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;

public class V_daoanActivity extends Activity {

	private TextView V_daoanDemand;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_v_daoan);
		V_daoanDemand = (TextView) findViewById(R.id.V_txDemand);
		AssetManager am=getAssets();
		try {
		InputStream is=am.open("zx.txt");
		 
		String code=getCode(is);
		is=am.open("zx.txt");
		BufferedReader br=new BufferedReader(new InputStreamReader(is,code));
		 
		String line=br.readLine();
		int i=0;
		while(line!=null){
			V_daoanDemand.append(line+"\n");
		line=br.readLine();
		i++;
		if(i==200){
		break;
		}
		}
		} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		}
		// novel.setText(readNovel());
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.v_daoan, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
	
	public String getCode(InputStream is){
		try {
		BufferedInputStream bin = new BufferedInputStream(is);  
	   int p;
	   p = (bin.read() << 8) + bin.read();
	  
	   String code = null;  
	      
	   switch (p) {  
	       case 0xefbb:  
	           code = "UTF-8";  
	           break;  
	       case 0xfffe:  
	           code = "Unicode";  
	           break;  
	       case 0xfeff:  
	           code = "UTF-16BE";  
	           break;  
	       default:  
	           code = "GBK";  
	   } 
	   is.close();
	   return code;
	} catch (IOException e) {
	// TODO Auto-generated catch block
		e.printStackTrace();
	}   
	return null; 
	}
}
