package tunnel.pic;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.v4.content.FileProvider;
import android.util.Log;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import tunnel.conf.Config;
import tunnel.util.ExceptionUtil;

/**
 * 作者 ： hjb
 * 时间 ： 2017/4/28.
 */

public class CameraUtils {
    public static final int TAKE_PICTURE = 101;
    public static String photoPath;
    public static final int LOCAL_PICTURE = 102;
    public static File photoFile = null;
    public static void takePhoto(Activity ac, String appID, int requestCode ) {
        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (takePictureIntent.resolveActivity(ac.getPackageManager()) != null) {
            try {
                photoFile = createImageFile(ac);
            } catch (IOException ex) {
            }
            if (photoFile != null) {

                Uri photoURI = getPhotoUri(ac, appID, photoFile);
//                if (Build.VERSION.SDK_INT >= Config.IMAGE_VERSION) {
//                    photoURI = FileProvider.getUriForFile(ac,
//                            appID + ".fileprovider", photoFile);
//                } else {
//                    photoURI = Uri.fromFile(photoFile);
//                }
                takePictureIntent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
                takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);
                ac.startActivityForResult(takePictureIntent, requestCode);
            }
        }
        // Save a file: path for use with ACTION_VIEW intents
//        if (Build.VERSION.SDK_INT >= Config.IMAGE_VERSION) {
//            photoPath = String.valueOf(FileProvider.getUriForFile(ac,
//                    appID + ".fileprovider", photoFile));
//        } else {
//            photoPath = String.valueOf(Uri.fromFile(photoFile));
//        }
        photoPath = String.valueOf(getPhotoUri(ac, appID, photoFile));
    }

    public static Uri getPhotoUri(Activity ac, String appID, File f) {
        return getPhotoUriOld(ac, appID, f);
    }

    public static Uri getPhotoUriNew(Activity ac, String appID, File f) {
        Uri photoURI = null;
        try {
            photoURI = FileProvider.getUriForFile(ac,
                        appID + ".fileprovider", f);
            return photoURI;
        }catch(Exception e) {
            Log.i("getPhotoUri", e.getMessage());
        }

        try {
            photoURI = Uri.fromFile(f);
            return photoURI;
        }catch(Exception e) {
            Log.i("getPhotoUri", e.getMessage());
        }

        return null;
    }

    public static Uri getPhotoUriOld(Activity ac, String appID, File f) {
        Uri photoURI = null;
        if (Build.VERSION.SDK_INT >= Config.IMAGE_VERSION) {
            photoURI = FileProvider.getUriForFile(ac,
                    appID + ".fileprovider", photoFile);
        } else {
            photoURI = Uri.fromFile(photoFile);
        }
        return photoURI;
    }

    private static File createImageFile(Activity ac) throws IOException {
        // Create an image file name
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss_SSS").format(new Date());
        String imageFileName = "JPEG_" + timeStamp + "_";

//        File storageDir = ac.getExternalFilesDir(Environment.DIRECTORY_PICTURES);
        File storageDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM);
//        boolean mkdir = storageDir.mkdirs();
        File image = File.createTempFile(
                imageFileName,  /* prefix */
                ".jpg",         /* suffix */
                storageDir      /* directory */
        );

//        File image = File.createTempFile(
//                imageFileName,  /* prefix */
//                ".jpg"
//        );
        return image;
    }
}
