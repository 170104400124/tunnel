package tunnel.util;

import android.app.Activity;
import android.util.Log;
import android.widget.Toast;

import java.io.PrintWriter;
import java.io.StringWriter;

public class ExceptionUtil {
    public static String getErrorInfoFromException(Exception e) {
        try {
//            StringWriter sw = new StringWriter();
//            PrintWriter pw = new PrintWriter(sw);
//            e.printStackTrace(pw);
//
//            return "\r\n" + sw.toString() + "\r\n";

            StringBuilder sb = new StringBuilder();
            StackTraceElement[] ste = e.getStackTrace();
            for(int index=0; index<5; index++) {
                StackTraceElement s = ste[index];
                sb.append(s.toString());
                sb.append("\r\n");
            }
            return "\r\n" + sb.toString() + "\r\n" ;

        } catch (Exception e2) {
            return "bad getErrorInfoFromException";
        }
    }
    public static void showException(Activity activity, Exception e) {
        Log.e("error", e.getMessage());
        String info = ExceptionUtil.getErrorInfoFromException(e);
        Toast.makeText(activity, info, Toast.LENGTH_LONG).show();
    }
}
