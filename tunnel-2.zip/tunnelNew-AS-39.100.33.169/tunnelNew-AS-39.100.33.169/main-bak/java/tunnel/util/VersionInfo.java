package tunnel.util;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.util.Log;

import tunnel.LoginActivity;

/**
 * 版本查看
 */
public class VersionInfo {
    public static String getVersion(Context context) {
        String version = "NaN";
        String versionCode = "NaN";

        try {
            PackageManager pm = context.getPackageManager();
            PackageInfo packageInfo = null;
            packageInfo = pm.getPackageInfo(context.getPackageName(), 0);
            version = packageInfo.versionName;
            versionCode = packageInfo.versionCode + "";
        } catch (PackageManager.NameNotFoundException e) {
            Log.e("版本显示错误", e.getMessage());
        }
        return version;
    }
}
