package tunnel;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.view.View;
import android.widget.RadioButton;

import com.jie.cameraimage.R;

/**
 * 底部Tab 页面消息处理
 */
public class TabHelper {
    RadioButton btnHome;
    RadioButton btnLocal;
    RadioButton btnUpload;
    RadioButton btnMe;

    public void addListener(final  Activity context) {
        btnHome = (RadioButton) context.findViewById(R.id.radio_button0);
        btnLocal = (RadioButton) context.findViewById(R.id.radio_button1);
        btnUpload = (RadioButton) context.findViewById(R.id.radio_button2);
        btnMe = (RadioButton) context.findViewById(R.id.radio_button3);

        btnHome.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Class clazz = HomeActivity.class;
                if (context.getClass().equals(clazz)) {
                    return;
                }
                Intent intent = new Intent(context, clazz);
                context.startActivity(intent);
            }
        });

        btnLocal.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Class clazz = LocalActivity.class;
                if (context.getClass().equals(clazz)) {
                    return;
                }
                Intent intent = new Intent(context, clazz);
                context.startActivity(intent);
            }
        });

        btnUpload.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Class clazz = NoUploadActivity.class;
                if (context.getClass().equals(clazz)) {
                    return;
                }
                Intent intent = new Intent(context, clazz);
                context.startActivity(intent);
            }
        });

        btnMe.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Class clazz = MeActivity.class;
                if (context.getClass().equals(clazz)) {
                    return;
                }
                Intent intent = new Intent(context, clazz);
                context.startActivity(intent);
            }
        });
    }
}
