package tunnel.design;

/**
 * Created by Leon on 2019/4/23.
 */

/**
 * Ⅴ+围岩
 */
public class DesignInfo_V_plus extends DesignInfo {
    public DesignInfo_V_plus() {
        //超前小导管安装：
         chaoQianXiaoDaoGuan = "Ø42X3无缝钢管，长4m，间距400mm，角度10~20度。";
        // 小导管注浆：
         xiaoDaoGuanZhuJiang = "注浆压力1.0~1.5MPa，可根据实测隧道水压等情况适当调整。";
        // 超前管棚成品：
         chaoQianGuanPengChenPing = "Ø89X4.5无缝钢管，钢管外插角2度。";
        // 超前管棚注浆
         chaoQianGuanPengZhuJiang = "注浆压力0.3~0.7MPa，可根据实际情况适当调整。";
        // 超前钻探
         chaoQianZuanTan = "3孔偏角超前钻探法，超前探测20m，探孔分布在两边底部和拱顶，若发现涌水，需施做中间的4个探水孔；利用炮眼加深超前钻探6m。";

        //支立钢拱架
         zhiLiGangGongJia = "采用12工字钢，间距1m/榀，可根据围岩破碎及沉降情况加密至0.6~0.8m/榀。工字钢架纵向筋为Ø18，间距0.8m。锁脚锚杆长度2m。";
        // 锚杆
         maoGan = "Ø 22锚杆，长度2.5m，间距1.0m，呈梅花型布置；";
        // 挂网
         guaWang = "直径6钢筋，网格尺寸为20cm×20cm；锚杆垫板采用Q235B钢，厚度6mm，M16螺母紧固至洞壁。";
        // 锚喷
         maoPeng = "喷射C25混凝土，厚度150mm。";
    }
}
