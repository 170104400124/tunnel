package tunnel.design;

/**
 * Created by Leon on 2019/4/23.
 */

/**
 * Ⅱ级围岩支护
 */
public class DesignInfo_II extends DesignInfo {
    public DesignInfo_II() {
        //    //超前小导管安装：
         chaoQianXiaoDaoGuan = "无";
        //    // 小导管注浆：
         xiaoDaoGuanZhuJiang = "无";
        //    // 超前管棚成品：
         chaoQianGuanPengChenPing = "无";
        //    // 超前管棚注浆
         chaoQianGuanPengZhuJiang = "无";
        //    // 超前钻探
         chaoQianZuanTan = "无";

        //支立钢拱架
         zhiLiGangGongJia = "局部破碎段、渗流较大地段设锚杆、钢筋网，参照Ⅲ级围岩支护设置。（采用12工字钢，间距1m/榀，可根据围岩破碎及沉降情况加密至0.6~0.8m/榀。工字钢架纵向筋为Ø18，间距0.8m。锁脚锚杆长度2m。）";

        // 锚杆
         maoGan = "局部破碎段、渗流较大地段设锚杆、钢筋网，参照Ⅲ级围岩支护设置。（Ø 22锚杆，长度2.0m，环向间距1.2m，纵向间距1.5m；）";
        // 挂网
         guaWang = "局部破碎段、渗流较大地段设锚杆、钢筋网，参照Ⅲ级围岩支护设置。（直径6钢筋，网格尺寸为25cm×25cm；锚杆垫板采用Q235B钢，厚度6mm，M16螺母紧固至洞壁。）";
        // 锚喷
         maoPeng = "喷射C25混凝土厚度80mm，局部破碎段、渗流较大地段设锚杆、钢筋网，参照Ⅲ级围岩支护设置。";
    }
}
