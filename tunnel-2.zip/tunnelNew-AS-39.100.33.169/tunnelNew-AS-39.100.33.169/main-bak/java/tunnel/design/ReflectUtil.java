package tunnel.design;

import java.lang.reflect.Field;

/**
 * Created by Leon on 2019/4/23.
 */

public class ReflectUtil {
    public static void main(String[] args) {
        DesignInfo_V_plus di = new  DesignInfo_V_plus();
        System.out.println(getFileValue(di, "maoPeng"));
    }

    public static void reflect(Object obj) {
        if (obj == null) return;
        Field[] fields = obj.getClass().getDeclaredFields();
        for (int j = 0; j < fields.length; j++) {
            fields[j].setAccessible(true);
            // 字段名
            System.out.print(fields[j].getName() + ",");
            // 字段值
            if (fields[j].getType().getName().equals(
                    java.lang.String.class.getName())) {
                // String type
                try {
                    System.out.print(fields[j].get(obj));
                } catch (IllegalArgumentException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                } catch (IllegalAccessException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
            } else if (fields[j].getType().getName().equals(
                    java.lang.Integer.class.getName())
                    || fields[j].getType().getName().equals("int")) {
                // Integer type
                try {
                    System.out.println(fields[j].getInt(obj));
                } catch (IllegalArgumentException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                } catch (IllegalAccessException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
            }
            // 其他类型。。。
        }
        System.out.println();
    }

    /**
     * 从Javabean里获取字段值
     * @param obj javabean 对象
     * @param fieldName 字段名
     * @return
     */
    public static Object getFileValue(Object obj, String fieldName) {
        Object fieldValue = null;
        if (obj == null) {
            return fieldValue;
        }

        Field[] fields = obj.getClass().getFields();
        for (int j = 0; j < fields.length; j++) {
            fields[j].setAccessible(true);
            // 检查字段名
            if(!fields[j].getName().equals(fieldName)) {
                continue;
            }
            // 字段值

            try {
                fieldValue = fields[j].get(obj);
                break;
            } catch (IllegalArgumentException e) {
                e.printStackTrace();
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            }
        }
        return fieldValue;
    }
}
