package tunnel.design;

import android.util.Log;

import java.util.ArrayList;
import java.util.List;

/**
 * 围岩支护方式，运行时模板信息
 * Created by Leon on 2019/4/23.
 */


public class ActivityRunningConfig {
    protected static ActivityRunningConfig  arc = new ActivityRunningConfig();
    protected  ActivityRunningConfig() {
    }

    public static ActivityRunningConfig getInstance() {
        return arc;
    }
    /**
     * 按钮点击路径，最多2个元素。
     * 元素0，记录支护等级；
     * 元素1，记录具体要求，比如
     * 超前小导管安装
     * 小导管注浆
     * 超前管棚成品
     * 超前管棚注浆
     * 超前钻探
     * 支立钢拱架
     * 锚杆
     * 挂网
     * 锚喷
     */
    List<String> buttonPath = new ArrayList<String>();
    String insertTable = null;
    DesignInfo di = null;
    public void setDesignInfo(DesignInfo info){
        this.di = info;
    }

    public DesignInfo getDesignInfo() {
        return di;
    }

    public void setButtonPath(int index, String value) {
        if(index < buttonPath.size()) {
            // 直接设置
            this.buttonPath.set(index, value);
        }else if(index == buttonPath.size()) {
            // 追加
            this.buttonPath.add(index, value);
        }else {
            Log.e("button path", "元素越界");
            throw new RuntimeException("元素越界");
        }
    }

    public String getButtonPathLevel_0() {
        if(this.buttonPath.size() <= 0 ) {
            return null;
        }
        return this.buttonPath.get(0);
    }

    public void setButtonPathLevel_0(String value) {
        this.setButtonPath(0, value);
    }

    public String getButtonPathLevel_1() {
        if(this.buttonPath.size() <= 1) {
            return null;
        }
        return this.buttonPath.get(1);
    }

    public void setButtonPathLevel_1(String value) {
        this.setButtonPath(1, value);
    }

}
