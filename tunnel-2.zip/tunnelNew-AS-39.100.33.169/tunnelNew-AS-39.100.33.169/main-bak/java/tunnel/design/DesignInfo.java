package tunnel.design;

/**
 * 设计要求基础类
 * Created by Leon on 2019/4/23.
 */

public class DesignInfo {
    //  超前小导管
    public static final String CHAO_QIAN_XIAO_DAO_GUAN = "chaoQianXiaoDaoGuan";
    //    // 小导管注浆：
    public static final String XIAO_DAO_GUAN_ZHU_JIANG = "xiaoDaoGuanZhuJiang";
    //    // 超前管棚成品：
    public static final String CHAO_QIAN_GUAN_PENG_CHEN_PING = "chaoQianGuanPengChenPing";
    //  // 超前管棚安装：
    public static final String CHAO_QIAN_GUAN_PENG_AN_ZHAUNG = "chaoQianGuanPengAnZhuang";
    //    // 超前管棚注浆
    public static final String CHAO_QIAN_GUAN_PENG_ZHU_JIANG = "chaoQianGuanPengZhuJiang";
    //    // 超前钻探
    public static final String CHAO_QIAN_ZUAN_TAN = "chaoQianZuanTan";
    //支立钢拱架
    public static final String ZHI_LI_GANG_GONG_JIA = "zhiLiGangGongJia";
    // 锚杆
    public static final String MAO_GAN = "maoGan";
    // 挂网
    public static final String GUA_WANG = "guaWang";
    // 锚喷
    public static final String MAO_PENG = "maoPeng";

    // 进尺及说明
    public static final String JIN_CHI_JI_SHUO_MING= "jinChiJiShuoMing";

    /**
     * 超前小导管安装：
     */
    public String chaoQianXiaoDaoGuan = "无";
    //    // 小导管注浆：
    public String xiaoDaoGuanZhuJiang = "无";
    //    // 超前管棚成品：
    public String chaoQianGuanPengChenPing = "无";
    //  // 超前管棚成品：
    public String chaoQianGuanPengAnZhuang = "无";
    //    // 超前管棚注浆
    public String chaoQianGuanPengZhuJiang = "无";
    //    // 超前钻探
    public String chaoQianZuanTan = "无";
    //支立钢拱架
    public String zhiLiGangGongJia = "无";
    // 锚杆
    public String maoGan = "无";
    // 挂网
    public String guaWang = "无";
    // 锚喷
    public String maoPeng = "无";
    // 进尺及说明
    public String jinChiJiShuoMing = "无";
}
