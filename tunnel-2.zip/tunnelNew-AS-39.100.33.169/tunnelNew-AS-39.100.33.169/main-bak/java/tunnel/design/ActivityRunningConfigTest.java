package tunnel.design;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import org.junit.Test;

import static junit.framework.Assert.assertEquals;

public class ActivityRunningConfigTest {

	@Test
	public void test() {
//		2019-04-25 18:10:00
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(new Date());
		calendar.set(Calendar.HOUR_OF_DAY, 0);
		calendar.set(Calendar.MINUTE, 0);
		calendar.set(Calendar.SECOND, 0);

		String date2= sdf.format(calendar.getTime());
		System.out.println(date2);

		calendar.setTime(new Date());
		calendar.add(calendar.DATE,1);
		calendar.set(Calendar.HOUR_OF_DAY, 0);
		calendar.set(Calendar.MINUTE, 0);
		calendar.set(Calendar.SECOND, 0);

		String date3= sdf.format(calendar.getTime());
		System.out.println(date3);



		ActivityRunningConfig arc = ActivityRunningConfig.getInstance();
		assertEquals(arc.getButtonPathLevel_0(), null);

		arc.setButtonPathLevel_0("V_plus");
		assertEquals(arc.getButtonPathLevel_0(), "V_plus");
		assertEquals(arc.getButtonPathLevel_1(), null);

		arc.setButtonPathLevel_1(DesignInfo.CHAO_QIAN_XIAO_DAO_GUAN);
		assertEquals(arc.getButtonPathLevel_0(), "V_plus");
		assertEquals(arc.getButtonPathLevel_1(), DesignInfo.CHAO_QIAN_XIAO_DAO_GUAN);
		
		arc.setButtonPathLevel_1(DesignInfo.XIAO_DAO_GUAN_ZHU_JIANG);
		assertEquals(arc.getButtonPathLevel_0(), "V_plus");
		assertEquals(arc.getButtonPathLevel_1(), DesignInfo.XIAO_DAO_GUAN_ZHU_JIANG);
		
		arc.setButtonPathLevel_1(DesignInfo.CHAO_QIAN_GUAN_PENG_CHEN_PING);
		assertEquals(arc.getButtonPathLevel_0(), "V_plus");
		assertEquals(arc.getButtonPathLevel_1(), DesignInfo.CHAO_QIAN_GUAN_PENG_CHEN_PING);
		
		arc.setButtonPathLevel_1(DesignInfo.CHAO_QIAN_GUAN_PENG_ZHU_JIANG);
		assertEquals(arc.getButtonPathLevel_0(), "V_plus");
		assertEquals(arc.getButtonPathLevel_1(), DesignInfo.CHAO_QIAN_GUAN_PENG_ZHU_JIANG);
		
		arc.setButtonPathLevel_1(DesignInfo.MAO_GAN);
		assertEquals(arc.getButtonPathLevel_0(), "V_plus");
		assertEquals(arc.getButtonPathLevel_1(), DesignInfo.MAO_GAN);
		
		arc.setButtonPathLevel_1(DesignInfo.ZHI_LI_GANG_GONG_JIA);
		assertEquals(arc.getButtonPathLevel_0(), "V_plus");
		assertEquals(arc.getButtonPathLevel_1(), DesignInfo.ZHI_LI_GANG_GONG_JIA);
		
		arc.setButtonPathLevel_1(DesignInfo.GUA_WANG);
		assertEquals(arc.getButtonPathLevel_0(), "V_plus");
		assertEquals(arc.getButtonPathLevel_1(), DesignInfo.GUA_WANG);
		
		arc.setButtonPathLevel_1(DesignInfo.MAO_PENG);
		assertEquals(arc.getButtonPathLevel_0(), "V_plus");
		assertEquals(arc.getButtonPathLevel_1(), DesignInfo.MAO_PENG);
	}

}
