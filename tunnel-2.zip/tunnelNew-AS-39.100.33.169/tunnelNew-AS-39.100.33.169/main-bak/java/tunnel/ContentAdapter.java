package tunnel;

import java.util.List;
import java.util.Map;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.TextView;

import com.beardedhen.androidbootstrap.BootstrapButton;
import com.jie.cameraimage.R;

public class ContentAdapter extends BaseAdapter {

    private static final String TAG = "ContentAdapter";
    private List<Map<String, Object>> mContentList;
    private LayoutInflater mInflater;
    private MyClickListener mListener;

    public ContentAdapter(Context context, List<Map<String, Object>> contentList,
                          MyClickListener listener) {
        mContentList = contentList;
        mInflater = LayoutInflater.from(context);
        mListener = listener;
    }

    public void setContentList(List<Map<String, Object>> contentList) {
        this.mContentList = contentList;
    }

    @Override
    public int getCount() {
        Log.i(TAG, "getCount");
        return mContentList.size();
    }

    @Override
    public Object getItem(int position) {
        Log.i(TAG, "getItem");
        return mContentList.get(position);
    }

    @Override
    public long getItemId(int position) {
        Log.i(TAG, "getItemId");
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        Log.i(TAG, "getView");
        ViewHolder holder = null;
        if (convertView == null) {
            convertView = mInflater.inflate(R.layout.upload, null);
            holder = new ViewHolder();
            holder.tvMainprocess = (TextView) convertView
                    .findViewById(R.id.upload_mainprocess);
            holder.tvSubprocess = (TextView) convertView
                    .findViewById(R.id.upload_subprocess);
            holder.tvUploadTime = (TextView) convertView
                    .findViewById(R.id.upload_time);

            holder.uploadButton = (BootstrapButton) convertView.findViewById(R.id.upload_upload);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }

        Map<String, Object> itemMap = mContentList.get(position);

//        holder.tvMainprocess.setText(getValueByDefault(itemMap, "tunnel_id"));
//        holder.tvSubprocess.setText(getValueByDefault(itemMap, "process_id"));
        holder.tvMainprocess.setText(getValueByDefault(itemMap, "rock_grade"));
        holder.tvSubprocess.setText(getValueByDefault(itemMap, "subprocess"));
        holder.tvUploadTime.setText(getValueByDefault(itemMap, "save_time"));
        holder.tvTunnel = getValueByDefault(itemMap, "tunnel_id");

//			"save_time", "tunnel_id", "process_id"

        holder.uploadButton.setOnClickListener(mListener);
        // 这里 根据position 从list<Map<String, Object> 查找对应Map，再从map里对的 primary key
        holder.uploadButton.setTag(position);
        return convertView;
    }

    private String getValueByDefault(Map<String, Object> map, String key) {
        Object value = map.get(key);
        if(null == value) {
            return "";
        }
        return value.toString();
    }

    public class ViewHolder {
        // 对应ListView里的每一列，其中tvMainKey 显示主键，可以隐藏
        public TextView tvKey;
        public TextView tvUploadTime;
        public TextView tvMainprocess;
        public TextView tvSubprocess;
        public String tvTunnel;

        public BootstrapButton uploadButton;
    }

    /**
     * 用于回调的抽象类
     * @author Ivan Xu
     * 2014-11-26
     */
    public static abstract class MyClickListener implements OnClickListener {
        /**
         * 基类的onClick方法
         */
        @Override
        public void onClick(View v) {
            myOnClick((Integer) v.getTag(), v);
        }
        public abstract void myOnClick(Integer position, View v);
    }
}