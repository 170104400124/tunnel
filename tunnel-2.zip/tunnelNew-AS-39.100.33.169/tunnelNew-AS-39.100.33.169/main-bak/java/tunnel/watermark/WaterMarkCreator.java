package tunnel.watermark;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.util.Log;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;

/**
 * Created by Leon on 2019/5/8.
 */

public class WaterMarkCreator {

    //图片转为二进制数据
    public static byte[]  bitmabToBytes(Context context, String url, String markFileName){
        //将图片转化为位图
        Bitmap bitmap = BitmapFactory.decodeFile(url);
       	/* options表示 如果不压缩是100，表示压缩率为0。如果是70，就表示压缩率是70，表示压缩30%; */
        int quality = 10;
        String miniFileName = url+".mini.jpg";
        try {
            FileOutputStream fos=new FileOutputStream(new File(miniFileName));
            // 压缩并保存文件
            bitmap.compress(Bitmap.CompressFormat.JPEG, quality, fos);
            fos.flush();
            fos.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        bitmap = null;

        Bitmap jpg = BitmapFactory.decodeFile(miniFileName);
        WaterMarkCreator wm = new WaterMarkCreator();
        Bitmap bitmapWatermark = wm.addTextWatermark(jpg, "测试一下", 20, 0xFF0000, 0, 0, true);
        jpg = null;

        markFileName = miniFileName + ".mark.jpg";
        try {
            // 保存 水印文件
            FileOutputStream fos = new FileOutputStream(new File(markFileName));
            bitmapWatermark.compress(Bitmap.CompressFormat.JPEG, 100, fos);
            fos.flush();
            fos.close();
        }catch (Exception e) {
            e.printStackTrace();
        }

        byte[] imagedata= null;
        try {

            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            bitmapWatermark.compress(Bitmap.CompressFormat.JPEG, 100, baos);
            imagedata = baos.toByteArray();
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        //将字节数组输出流转化为字节数组byte[]
        return imagedata;
    }
    /**
     * Bitmap对象是否为空。
     */
    public static boolean isEmptyBitmap(Bitmap src) {
        return src == null || src.getWidth() == 0 || src.getHeight() == 0;
    }
    /**
     * 给一张Bitmap添加水印文字。
     *
     * @param src      源图片
     * @param content  水印文本
     * @param textSize 水印字体大小 ，单位pix。
     * @param color    水印字体颜色。
     * @param x        起始坐标x
     * @param y        起始坐标y
     * @param recycle  是否回收
     * @return 已经添加水印后的Bitmap。
     */
    public static Bitmap addTextWatermark(Bitmap src, String content, int textSize, int color, float x, float y, boolean recycle) {
        if (isEmptyBitmap(src) || content == null)
            return null;
        Bitmap ret = src.copy(src.getConfig(), true);
        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        Canvas canvas = new Canvas(ret);
        paint.setColor(color);
        paint.setTextSize(textSize);
        Rect bounds = new Rect();
        paint.getTextBounds(content, 0, content.length(), bounds);
        canvas.drawText(content, x, y, paint);
        if (recycle && !src.isRecycled())
            src.recycle();
        return ret;
    }

}
