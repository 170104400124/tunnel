package tunnel;

import com.jie.cameraimage.R;

import android.app.TabActivity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.RadioGroup;
import android.widget.RadioGroup.OnCheckedChangeListener;
import android.widget.TabHost;
import android.widget.TabHost.TabSpec;

public class BottomActivity extends TabActivity {
    /** Called when the activity is first created. */
	public TabHost mth;
	public static final String TAB_HOME="首页";
	public static final String TAB_LOCAL="本地";
	public static final String TAB_UPLOAD="未上传";
	public static final String TAB_ME="我";
	public RadioGroup radioGroup;
	
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
        mth=this.getTabHost();
        
        mth.addTab(mth.newTabSpec(TAB_HOME)
                .setIndicator(TAB_HOME)
                .setContent(new Intent(this,HomeActivity.class)));
        
        mth.addTab(mth.newTabSpec(TAB_LOCAL)
                .setIndicator(TAB_LOCAL)
                .setContent(new Intent(this,LocalActivity.class)));
        
        mth.addTab(mth.newTabSpec(TAB_UPLOAD)
                .setIndicator(TAB_UPLOAD)
                .setContent(new Intent(this,NoUploadActivity.class)));
        
        mth.addTab(mth.newTabSpec(TAB_ME)
                .setIndicator(TAB_ME)
                .setContent(new Intent(this,MeActivity.class)));

        this.radioGroup=(RadioGroup)findViewById(R.id.main_radio);
        radioGroup.setOnCheckedChangeListener(new OnCheckedChangeListener() {
			
			@Override
			public void onCheckedChanged(RadioGroup group, int checkedId) {
				// TODO Auto-generated method stub
				
				switch(checkedId){
				case R.id.radio_button0:
					mth.setCurrentTabByTag(TAB_HOME);
					break;
				case R.id.radio_button1:
					mth.setCurrentTabByTag(TAB_LOCAL);
					break;
				case R.id.radio_button2:
					mth.setCurrentTabByTag(TAB_UPLOAD);
					break;
				case R.id.radio_button3:
					mth.setCurrentTabByTag(TAB_ME);
					break;
//				case R.id.radio_button4:
//					Log.d("select ID", "===={"+checkedId);
//					break;
				}
			}
		});
        
    }
}