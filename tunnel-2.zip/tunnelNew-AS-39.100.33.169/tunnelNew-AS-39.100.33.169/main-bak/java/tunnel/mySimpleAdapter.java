package tunnel;

import com.beardedhen.androidbootstrap.BootstrapButton;
import java.util.List;
import java.util.Map;

import com.jie.cameraimage.R;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

public class mySimpleAdapter extends BaseAdapter {

    private static final String TAG = "mySimpleAdapter";
    private List<Map<String, Object>> mContentList;
    private MyClickListener mListener;
    private LayoutInflater mInflater;

	public mySimpleAdapter(Context context, List<Map<String, Object>> data,mySimpleAdapter.MyClickListener listener) {
		mContentList = data;
        mInflater = LayoutInflater.from(context);
        this.mListener = listener;
	}


    public void setContentList(List<Map<String, Object>> contentList) {
        this.mContentList = contentList;
    }

    @Override
    public int getCount() {
        Log.i(TAG, "getCount");
        return mContentList.size();
    }

    @Override
    public Object getItem(int position) {
        Log.i(TAG, "getItem");
        return mContentList.get(position);
    }

    @Override
    public long getItemId(int position) {
        Log.i(TAG, "getItemId");
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup group) {
        Log.i(TAG, "getView");
        ViewHolder holder = null;
        if (convertView == null) {
            convertView = mInflater.inflate(R.layout.items, null);
            holder = new ViewHolder();
            holder.tx_upload = (TextView) convertView.findViewById(R.id.local_isUpload);
            holder.tx_offset = (TextView) convertView.findViewById(R.id.local_footage);
            holder.local_check = (BootstrapButton) convertView.findViewById(R.id.local_check);

            holder.tx_local_time = (TextView) convertView.findViewById(R.id.local_time);
            //holder.local_footage = (TextView) convertView.findViewById(R.id.local_footage);
            holder.tx_local_mainprocess = (TextView) convertView.findViewById(R.id.local_mainprocess);
            holder.tx_local_subprocess = (TextView) convertView.findViewById(R.id.local_subprocess);
            holder.tx_local_explanation = (TextView) convertView.findViewById(R.id.local_explanation);
            holder.local_old_rock = (TextView) convertView.findViewById(R.id.local_old_rock);
            holder.local_new_rock = (TextView) convertView.findViewById(R.id.local_new_rock);
            holder.position = position;

            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }

        Map<String, Object> itemMap = mContentList.get(position);

        String isUpload = getValueByDefault(itemMap,"isUpload");
    	if(isUpload.equals("0")) {
            holder.tx_upload.setText("未上传");
            //tx_upload.setBackgroundColor(Color.BLUE);
        }
    	else if(isUpload.equals("1")) {
            holder.tx_upload.setText("已上传");
            //tx_upload.setBackgroundColor(Color.RED);
        }

        holder.tx_local_key = getValueByDefault(itemMap,"key");
        //holder.local_footage.setText(getValueByDefault(itemMap,"report_footage"));
        holder.tx_local_time.setText(getValueByDefault(itemMap,"save_time"));
        holder.tx_local_mainprocess.setText(getValueByDefault(itemMap,"rock_grade"));
        holder.tx_local_subprocess.setText(getValueByDefault(itemMap,"subprocess"));
        holder.tx_local_explanation.setText(getValueByDefault(itemMap,"explanation"));
        holder.local_new_rock.setText(getValueByDefault(itemMap,"new_rock"));
        holder.local_old_rock.setText(getValueByDefault(itemMap,"old_rock"));
        holder.tx_offset.setText(getValueByDefault(itemMap,"report_footage"));

        holder.local_check.setOnClickListener(mListener);
        holder.local_check.setTag(holder);

//        // 这里 根据position 从list<Map<String, Object> 查找对应Map，再从map里对的 primary key
        convertView.setOnClickListener(mListener);
//        convertView.setTag(position);

        return convertView;
    }

    private String getValueByDefault(Map<String, Object> map, String key) {
        Object value = map.get(key);
        if(null == value) {
            return "";
        }
        return value.toString();
    }

    public class ViewHolder {
        // 对应ListView里的每一列，其中tvMainKey 显示主键，可以隐藏
        //tx_local_key为主键
        public String tx_local_key;
        public BootstrapButton local_check;
        public TextView tx_upload;
        public TextView tx_offset;
        public TextView tx_local_time;
        public TextView tx_local_mainprocess;
        public TextView tx_local_subprocess;
        public TextView tx_local_explanation;
        public TextView local_new_rock;
        public TextView local_old_rock;
        //public TextView local_footage;
        public int position;
    }

    /**
     * 用于回调的抽象类
     * @author Ivan Xu
     * 2014-11-26
     */
    public static abstract class MyClickListener implements View.OnClickListener {
        /**
         * 基类的onClick方法
         */
        public abstract void myOnClick(Integer position, View v);
        @Override
        public void onClick(View v) {
            ViewHolder holder = (ViewHolder) v.getTag();
            myOnClick(holder.position, v);
        }

    }
}
