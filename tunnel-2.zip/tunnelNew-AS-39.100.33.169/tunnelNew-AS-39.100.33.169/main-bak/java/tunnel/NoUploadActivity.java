package tunnel;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import com.beardedhen.androidbootstrap.BootstrapButton;
import com.jie.cameraimage.R;
import com.tunnel.dao.android.AndroidUtils;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.RelativeLayout;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.AbsListView.OnScrollListener;
import android.widget.Button;
import tunnel.JDBC.DBOpenHelper;
import tunnel.model.Const;
import tunnel.model.ImageModel;
import tunnel.service.NetWorkTask;
import tunnel.service.UploadUtil;
import tunnel.util.ExceptionUtil;

import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;
import android.widget.Toast;

public class NoUploadActivity extends Activity implements OnClickListener, OnItemClickListener {

	private TextView place;
	ListView lv;
	RelativeLayout rl;
	DBOpenHelper dbHelper = new DBOpenHelper(NoUploadActivity.this);
	SimpleAdapter adapter;
	List<Map<String, Object>> list ;
	int totalNum;//数据总条数
	int pageSize=15;//每页显示的条数
	int totalPage;//总的页数
	int currentPage=1;//当前页码
	boolean isbottom=false;//判断是否到当前页码的底部
	private String user_id;
	private String offset;
	private String tunnelName;
	private String remarks;
	private String key;
	private String processName;
	private String savetime;
	private List<ImageModel> imageList;
	RadioButton btnHome;
	RadioButton btnLocal;
	RadioButton btnUpload;
	RadioButton btnMe;

	@Override
	protected void onResume() {
		super.onResume();

		SQLiteDatabase db = dbHelper.getReadableDatabase();
		String sql="select * from log join process on process.process_id = log.process_id where log.isUpload=? and log.user_id = ?";
		Cursor c=db.rawQuery(sql, new String[]{"0",user_id});
		totalNum=c.getCount();
		totalPage=(int)Math.ceil((totalNum/pageSize));
		if(1==currentPage)
		{
			getData(currentPage);
		}
		ca.setContentList(list);
		ca.notifyDataSetChanged();
	}
	ContentAdapter ca = null;

	@Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_no_upload);
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        lv=(ListView) findViewById(R.id.lv);
        rl=(RelativeLayout) findViewById(R.id.rl);

//		BootstrapButton bbUpload = (BootstrapButton)findViewById(R.id.upload_upload);
//		bbUpload.setOnClickListener(this);

        place = (TextView) findViewById(R.id.place);
        SharedPreferences sp = getSharedPreferences("data", Context.MODE_PRIVATE);
		String txPlace = sp.getString("place", "");
		user_id = sp.getString("user_id", "");
		place.setText(txPlace);
		btnHome = (RadioButton) findViewById(R.id.radio_button0);
		btnLocal = (RadioButton) findViewById(R.id.radio_button1);
		btnUpload = (RadioButton) findViewById(R.id.radio_button2);
		btnMe = (RadioButton) findViewById(R.id.radio_button3);
		
		btnHome.setOnClickListener(new View.OnClickListener() {
			
			public void onClick(View v) {
				Intent intent = new Intent(NoUploadActivity.this, HomeActivity.class);
				startActivity(intent);
			}
		});
		btnLocal.setOnClickListener(new View.OnClickListener() {
			
			public void onClick(View v) {
				Intent intent = new Intent(NoUploadActivity.this, LocalActivity.class);
				startActivity(intent);
			}
		});
		btnMe.setOnClickListener(new View.OnClickListener() {
			
			public void onClick(View v) {
				Intent intent = new Intent(NoUploadActivity.this, MeActivity.class);
				startActivity(intent);
			}
		});

        String sql="select * from log left join process on log.process_id=process.process_id where log.isUpload=? and log.user_id = ?";
        Cursor c=db.rawQuery(sql, new String[]{"0", user_id});
        totalNum=c.getCount();
        totalPage=(int)Math.floor(totalNum/pageSize) + 1;
        if(1==currentPage)
        {
        	getData(currentPage);
        }

		// mock, 添加n条无效记录
//		{
//			Map<String, Object> r1 = new HashMap<String, Object>();
//			r1.put("save_time", "9999-99-99");
//			r1.put("tunnel_id", "tunnel_id_0");
//			r1.put("process_id", "process_id_0");
//			r1.put("primary_key", "key_000");
//
//			Map<String, Object> r2 = new HashMap<String, Object>();
//			r2.put("save_time", "9999-99-99");
//			r2.put("tunnel_id", "tunnel_id_0");
//			r2.put("process_id", "process_id_0");
//			r2.put("primary_key", "key_999");
//
//			list.add(r1);
//			list.add(r2);
//		}

//        adapter=new SimpleAdapter(getApplicationContext(),list, R.layout.upload, new String[] {
//			"save_time", "rock_grade", "subprocess" }, new int[] { R.id.upload_time,
//			R.id.upload_mainprocess, R.id.upload_subprocess});
//        lv.setAdapter(adapter);

		ca = new ContentAdapter(this, list, mListener);
		lv.setAdapter(ca);
//		lv.setOnItemClickListener(this);
        lv.setOnScrollListener(new OnScrollListener() {
			
			@Override
			public void onScrollStateChanged(AbsListView view, int scrollState) {
				if(isbottom&&(scrollState == OnScrollListener.SCROLL_STATE_IDLE))
				{
					rl.setVisibility(View.VISIBLE);		
				}
				else
				{
					rl.setVisibility(View.GONE);
				}
			}
			
			@Override
			public void onScroll(AbsListView view, int firstVisibleItem,
					int visibleItemCount, int totalItemCount) {
				isbottom=((firstVisibleItem+visibleItemCount)==totalItemCount);
			}
		});
        
    }
    //点击加载更多的监听事件
    public void click(View v)
    {
    	currentPage++;
    	list.addAll(getData(currentPage));
    	ca.notifyDataSetChanged();
		rl.setVisibility(View.GONE);
    }
  //获取当前页的数据
  	@SuppressLint("NewApi") 
  	public List<Map<String, Object>>  getData(int currentPage){
  		SQLiteDatabase db = dbHelper.getReadableDatabase();
  		int index = (currentPage-1)*pageSize;//0   0   1  20   2  40 
  		String sql = "select * from log left join process on  process.process_id = log.process_id where log.isUpload=? and log.user_id = ? order by log.save_time desc limit ?,?";//从哪一个位置    请求多少条
  		Cursor c = db.rawQuery(sql, new String[]{"0", user_id, index+"",pageSize+""});
  		return getCursorList(c);
  		
  	}
  	@SuppressLint("NewApi") 
  	public List<Map<String, Object>> getCursorList(Cursor c){
  		list = new ArrayList<Map<String,Object>>();
		while(c.moveToNext()){
			Map<String, Object> map = AndroidUtils.getResultMap(c);
			list.add(map);
		}
		return list;
	}
  	
  	//一键上传
  	public void onClick(View view) {
		switch (view.getId()) {
		case R.id.upload_upload:
			Date currentDate = new Date();
			SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");// HH:mm:ss
			//获取当前时间
			String uploadtime = simpleDateFormat.format(currentDate);
	    	String isUpload = "1";
			DBOpenHelper dbHelper = new DBOpenHelper(NoUploadActivity.this);
			 //执行创建数据库或是表的语句
			SQLiteDatabase db = dbHelper.getReadableDatabase();
			//计算log表里数据数量
			 Cursor cursor = null;
		     //执行通过用户名和密码的参数查询出用户，并保存在cursor中
		     cursor = db.rawQuery("select * from log, picture where isUpload=? and picture.key=log.key and log.user_id = ?",new String[] {"0", user_id});
		     //得到的用户信息通过moveToNext()方法，while语句循环输出
		     int i = 0;
		     String url;
		     while (cursor.moveToNext()) {
		    	 NetWorkTask networkTask = new NetWorkTask();
		    	 user_id=cursor.getString(cursor.getColumnIndex("user_id"));
	    		 offset=cursor.getString(cursor.getColumnIndex("report_footage"));
	    		 tunnelName=cursor.getString(cursor.getColumnIndex("tunnel_id"));
	    		 processName=cursor.getString(cursor.getColumnIndex("process_id"));
	    		 key=cursor.getString(cursor.getColumnIndex("key"));
	    		 isUpload=cursor.getString(cursor.getColumnIndex("isUpload"));
	    		 remarks=cursor.getString(cursor.getColumnIndex("explanation"));
	    		 savetime=cursor.getString(cursor.getColumnIndex("save_time"));
		         url=cursor.getString(cursor.getColumnIndex("address"));
                 networkTask.setContext(this);
                 networkTask.setHandler(handler);
		         networkTask.execute(url, user_id, offset, tunnelName, processName, key, uploadtime, isUpload ,remarks, savetime,"","");
//		         if(NetWorkTask.upload.equals("1")){
//		         	db = dbHelper.getReadableDatabase();
//		         	ContentValues cv = new ContentValues();
//		          	cv.put("isUpload","1");
//		          	String whereCaluse = "key=?";
//		          	String whereArgs[] = new String[]{key};
//		          	db.update("log", cv, whereCaluse, whereArgs);
//		          	db.close() ;
//		          	Toast.makeText(this, "图片上传成功", Toast.LENGTH_SHORT).show();
//		         }
		     }
			break;
		}
  	}
 

	@Override
	public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
		Toast.makeText(this, "listview的item被点击了！，点击的位置是-->" + position + " id=" +id,
				Toast.LENGTH_SHORT).show();
	}

	/**
	 * 实现类，响应按钮点击事件
	 */
	private ContentAdapter.MyClickListener mListener = new ContentAdapter.MyClickListener() {
		@Override
		public void myOnClick(Integer position, View v) {
			try {
				Date currentDate = new Date();
				SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");// HH:mm:ss
				//获取当前时间
				String uploadtime = simpleDateFormat.format(currentDate);
				String isUpload = "1";
				DBOpenHelper dbHelper = new DBOpenHelper(NoUploadActivity.this);
				//执行创建数据库或是表的语句
				SQLiteDatabase db = dbHelper.getReadableDatabase();
				//计算log表里数据数量
				Cursor cursor = null;
				user_id = (String) list.get(position).get("user_id");
				offset = (String) list.get(position).get("report_footage");
				tunnelName = (String) list.get(position).get("tunnel_id");
				processName = (String) list.get(position).get("process_id");
				key = (String) list.get(position).get("key");
				remarks = (String) list.get(position).get("explanation");
				savetime = (String) list.get(position).get("save_time");
				//执行通过用户名和密码的参数查询出用户，并保存在cursor中
				cursor = db.rawQuery("select address from log, picture where picture.key=? and picture.key=log.key", new String[]{key});
//			select * from log left join picture on picture.key=log.key   where log.key="12019-04-25 17:46:43"
//			cursor = db.rawQuery("select * from log left join picture on picture.key=log.key where log.key=?",new String[] {key});
				//得到的用户信息通过moveToNext()方法，while语句循环输出
				String url;
				int num = cursor.getCount();
				if (num > 0) {
					while (cursor.moveToNext()) {
						url = cursor.getString(cursor.getColumnIndex("address"));
						NetWorkTask networkTask = new NetWorkTask();
						networkTask.setContext(NoUploadActivity.this);
						networkTask.setHandler(handler);
						networkTask.execute(url, user_id, offset, tunnelName, processName, key, uploadtime, isUpload, remarks, savetime, "", "");
					}
				} else {
					url = "";
					NetWorkTask networkTask = new NetWorkTask();
					networkTask.setContext(NoUploadActivity.this);
					networkTask.setHandler(handler);
					networkTask.execute(url, user_id, offset, tunnelName, processName, key, uploadtime, isUpload, remarks, savetime, "", "");
				}
			}catch (Exception e) {
				ExceptionUtil.showException(NoUploadActivity.this, e);
			}
		}
	};

	// 刷新消息
	Handler handler = new android.os.Handler() {
		@Override
		public void handleMessage(Message msg) {
			if(msg.what == Integer.valueOf(UploadUtil.SUCCESS)) {
				onResume();
			}
		}
	};
}
