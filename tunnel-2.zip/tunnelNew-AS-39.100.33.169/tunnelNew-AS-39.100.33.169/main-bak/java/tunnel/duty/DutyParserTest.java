package tunnel.duty;

import org.junit.Test;

import java.util.List;
import com.tunnel.model.DutyData;

import tunnel.LoginActivity;

import static junit.framework.Assert.assertTrue;

public class DutyParserTest {

	@Test
	public void test() {
		String json = "{\"duty\":[{\"id\":31,\"user_id\":\"sujun\",\"tunnel_id\":\"勾鼻墩1号隧道进口\"},{\"id\":27,\"user_id\":\"sujun\",\"tunnel_id\":\"排子隧道出口\"}],\"user\":{\"user_id\":\"sujun\",\"user_name\":\"苏军\",\"password\":\"sujun\",\"position\":\"技术员\",\"access\":\"其他\",\"available\":1}}\n";
		DutyParser parser = new DutyParser();
		parser.parse(json, null);

		List<DutyData> list = parser.getDutyDataList();
		com.tunnel.model.UserData ud = parser.getUserData();

		assertTrue(list.size() > 0);
		assertTrue(ud != null);
	}

	@Test
	public void testEmptyPosition() {
		String json = "{\"duty\":[{\"id\":31,\"user_id\":\"sujun\",\"tunnel_id\":\"勾鼻墩1号隧道进口\"},{\"id\":27,\"user_id\":\"sujun\",\"tunnel_id\":\"排子隧道出口\"}],\"user\":{\"user_id\":\"sujun\",\"user_name\":\"苏军\",\"password\":\"sujun\",\"position\":\"\",\"access\":\"其他\",\"available\":1}}\n";
		DutyParser parser = new DutyParser();
		parser.parse(json, null);

		List<DutyData> list = parser.getDutyDataList();
		com.tunnel.model.UserData ud = parser.getUserData();

		assertTrue(list.size() > 0);
		assertTrue(ud != null);
	}
}
