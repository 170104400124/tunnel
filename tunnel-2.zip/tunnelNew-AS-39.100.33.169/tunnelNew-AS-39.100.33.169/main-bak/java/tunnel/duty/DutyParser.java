package tunnel.duty;

import android.app.Activity;
import android.util.Log;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import com.tunnel.model.UserData;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.tunnel.model.DutyData;

import tunnel.util.ExceptionUtil;

public class DutyParser {

    public List<DutyData> getDutyDataList() {
        return duty;
    }

    public UserData getUserData() {
        return ud;
    }

    Gson gson = new Gson();
    UserData ud = null;
    List<DutyData> duty = null;
    public boolean parse(String json, Activity context) {

        Type type = new TypeToken<Map<String, Object>>() {}.getType();
        Map<String, Object> map = gson.fromJson(json, type);

        try {
            String userJson = map.get("user").toString();

            ud = gson.fromJson(userJson, UserData.class);
//            ud = parseUser(userJson);
            String dutyJson = map.get("duty").toString();
            List<Object> list = gson.fromJson(dutyJson, List.class);
            duty = new ArrayList<DutyData>();
            for(Object obj : list) {
                DutyData dd = gson.fromJson(obj.toString(), DutyData.class);
                dd.setUser_id(ud.getUser_id());
                duty.add(dd);
            }
        }catch(Exception e) {
            if(null != context) {
                ExceptionUtil.showException(context, e);
            }
            Log.e("duty parser", e.getMessage());
            return false;
        }

        return true;
    }

    public UserData parseUser(String udJson) {
        Type type = new TypeToken<Map<String, Object>>() {}.getType();
        Map<String, Object> map = gson.fromJson(udJson, type);

        UserData u = new UserData();

        Object user_id = getOrDefault(map, "user_id", "");
        u.setUser_id(user_id.toString());

        Object user_name = getOrDefault(map, "user_name", "");
        u.setUser_name(user_name.toString());

        Object password = getOrDefault(map, "password", "");
        u.setPassword(password.toString());

        Object position = getOrDefault(map, "position", "");
        u.setPosition(position.toString());

        Object phone = getOrDefault(map, "phone", "");
        u.setPhone(phone.toString());

        return u;
    }

    public Object getOrDefault(Map<String, Object> map, String key, String defValue) {
        Object value = map.get(key);
        if(null == value) {
            value = defValue;
        }
        return value;
    }
}
