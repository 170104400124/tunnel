package tunnel;

import java.util.ArrayList;
import java.util.List;

import com.jie.cameraimage.R;
import com.jie.cameraimage.R.id;
import com.jie.cameraimage.R.layout;
import com.jie.cameraimage.R.menu;

import android.app.Activity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.GridView;
import tunnel.adapter.MainGridViewAdapter;
import tunnel.model.ImageModel;

public class V_zuankongActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_v_zuankong);
		
		GridView imageGridView;
		imageGridView = (GridView) findViewById(R.id.main_data_gridView);
		List<ImageModel> imageList;
		imageList = new ArrayList<ImageModel>();
		MainGridViewAdapter adapter;
		ImageModel imageModel = new ImageModel();
		imageModel.setSpareImage(R.drawable.addimage);
		imageList.add(imageModel);
		adapter = new MainGridViewAdapter(imageList, this, View.GONE);
		imageGridView.setAdapter(adapter);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.v_zuankong, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
}
