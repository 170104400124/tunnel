package tunnel.model;

//import com.mysql.jdbc.Blob;

import java.sql.Timestamp;

public class LogData {
    private int user_id;
    private int tunnel_id;
    private int process_id;
   // private Blob picture;
    private Timestamp storage_time;
    private Timestamp upload_time;
    private String explanation;

    public LogData() {
    }

    public int getUser_id() {
        return user_id;
    }

    public void setUser_id(int user_id) {
        this.user_id = user_id;
    }

    public int getTunnel_id() {
        return tunnel_id;
    }

    public void setTunnel_id(int tunnel_id) {
        this.tunnel_id = tunnel_id;
    }

    public int getProcess_id() {
        return process_id;
    }

    public void setProcess_id(int process_id) {
        this.process_id = process_id;
    }

   // public Blob getPicture() {
   //     return picture;
   // }

   // public void setPicture(Blob picture) {
    //    this.picture = picture;
   // }

    public Timestamp getStorage_time() {
        return storage_time;
    }

    public void setStorage_time(Timestamp storage_time) {
        this.storage_time = storage_time;
    }

    public Timestamp getUpload_time() {
        return upload_time;
    }

    public void setUpload_time(Timestamp upload_time) {
        this.upload_time = upload_time;
    }

    public String getExplanation() {
        return explanation;
    }

    public void setExplanation(String explanation) {
        this.explanation = explanation;
    }
}
