package tunnel.model;

//import com.mysql.jdbc.Blob;

public class TunnelData {
    private int tunnel_id;
    private String tunnel_section;
    private String tunnel_name;
    private String tunnel_subface;
   // private Blob picture;
    private String remarks;

    public TunnelData() {
    }

    public int getTunnel_id() {
        return tunnel_id;
    }

    public void setTunnel_id(int tunnel_id) {
        this.tunnel_id = tunnel_id;
    }

    public String getTunnel_section() {
        return tunnel_section;
    }

    public void setTunnel_section(String tunnel_section) {
        this.tunnel_section = tunnel_section;
    }

    public String getTunnel_name() {
        return tunnel_name;
    }

    public void setTunnel_name(String tunnel_name) {
        this.tunnel_name = tunnel_name;
    }

    public String getTunnel_subface() {
        return tunnel_subface;
    }

    public void setTunnel_subface(String tunnel_subface) {
        this.tunnel_subface = tunnel_subface;
    }

    //public Blob getPicture() {
   //     return picture;
   // }

    //public void setPicture(Blob picture) {
   //     this.picture = picture;
   // }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }
}
