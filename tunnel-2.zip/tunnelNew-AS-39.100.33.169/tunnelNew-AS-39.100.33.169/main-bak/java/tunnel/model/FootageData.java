package tunnel.model;

public class FootageData {
    private int tunnel_id;
    private String tunnel_starting;
    private String tunnel_end;
    private String tunnel_grade;

    public FootageData() {
    }

    public int getTunnel_id() {
        return tunnel_id;
    }

    public void setTunnel_id(int tunnel_id) {
        this.tunnel_id = tunnel_id;
    }

    public String getTunnel_starting() {
        return tunnel_starting;
    }

    public void setTunnel_starting(String tunnel_starting) {
        this.tunnel_starting = tunnel_starting;
    }

    public String getTunnel_end() {
        return tunnel_end;
    }

    public void setTunnel_end(String tunnel_end) {
        this.tunnel_end = tunnel_end;
    }

    public String getTunnel_grade() {
        return tunnel_grade;
    }

    public void setTunnel_grade(String tunnel_grade) {
        this.tunnel_grade = tunnel_grade;
    }
}
