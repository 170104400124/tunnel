package tunnel.model;

import java.io.File;

import android.os.Environment;
import tunnel.MainActivity;

/**
 * @ClassName: Const
 * @Description: 常量接口
 * @Date 2016年10月28日
 * @author jie
 */
public interface Const {

	/**
	 * 最大上传图片数量
	 */
	public static int MAX_IMAGECOUNT = 9;
	
	/**
	 * 调用相机拍照
	 */
	public static int CALL_CAMERA = 1;
	
	/**
	 * 选择图片（单选）标识数据
	 */
	public static int SELECTIMAGE_ONE = 2;
	
	/**
	 * 选择图片（多选）标识数据
	 */
	public static int SELECTIMAGE_MORE = 3;

	public static final String DCIMPath = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM).toString();
	public static final String CAMERA_DIR = DCIMPath + "/Camera";

	/**
	 * 拍照图片存放文件夹
	 */
	public static String PHOTO_FILE_PATH = CAMERA_DIR + File.separator + MainActivity.class.getPackage().getName() + File.separator + "no_upload_media";

	/**
	 * 最大注释长度
	 */
	public static int MAX_COMMENT_LENGTH = 200;
	
}
