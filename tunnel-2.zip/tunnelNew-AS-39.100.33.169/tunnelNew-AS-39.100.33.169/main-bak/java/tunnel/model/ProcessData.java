package tunnel.model;

public class ProcessData {
    private int process_id;
    private String rock_grade;
    private String subprocess;
    private String lowprocess;
    private String requirement;

    public ProcessData() {
    }

    public int getProcess_id() {
        return process_id;
    }

    public void setProcess_id(int process_id) {
        this.process_id = process_id;
    }

    public String getRock_grade() {
        return rock_grade;
    }

    public void setRock_grade(String rock_grade) {
        this.rock_grade = rock_grade;
    }

    public String getSubprocess() {
        return subprocess;
    }

    public void setSubprocess(String subprocess) {
        this.subprocess = subprocess;
    }

    public String getLowprocess() {
        return lowprocess;
    }

    public void setLowprocess(String lowprocess) {
        this.lowprocess = lowprocess;
    }

    public String getRequirement() {
        return requirement;
    }

    public void setRequirement(String requirement) {
        this.requirement = requirement;
    }
}
