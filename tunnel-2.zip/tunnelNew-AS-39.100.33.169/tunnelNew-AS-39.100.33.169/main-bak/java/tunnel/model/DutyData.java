package tunnel.model;

public class DutyData {
    private int user_id;
    private int tunnel_id;

    public DutyData() {
    }

    public int getUser_id() {
        return user_id;
    }

    public void setUser_id(int user_id) {
        this.user_id = user_id;
    }

    public int getTunnel_id() {
        return tunnel_id;
    }

    public void setTunnel_id(int tunnel_id) {
        this.tunnel_id = tunnel_id;
    }
}
