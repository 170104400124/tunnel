package tunnel.model;

import java.sql.Timestamp;

public class OffsetData {
    private int tunnel_id;
    private int user_id;
    private int process_id;
    private String report_footage;
    private String sum_footage;
    private String offset;
    private Timestamp save_time;
    private Timestamp upload_time;

    public OffsetData() {
    }

    public int getTunnel_id() {
        return tunnel_id;
    }

    public void setTunnel_id(int tunnel_id) {
        this.tunnel_id = tunnel_id;
    }

    public int getUser_id() {
        return user_id;
    }

    public void setUser_id(int user_id) {
        this.user_id = user_id;
    }

    public int getProcess_id() {
        return process_id;
    }

    public void setProcess_id(int process_id) {
        this.process_id = process_id;
    }

    public String getReport_footage() {
        return report_footage;
    }

    public void setReport_footage(String report_footage) {
        this.report_footage = report_footage;
    }

    public String getSum_footage() {
        return sum_footage;
    }

    public void setSum_footage(String sum_footage) {
        this.sum_footage = sum_footage;
    }

    public String getOffset() {
        return offset;
    }

    public void setOffset(String offset) {
        this.offset = offset;
    }

    public Timestamp getSave_time() {
        return save_time;
    }

    public void setSave_time(Timestamp save_time) {
        this.save_time = save_time;
    }

    public Timestamp getUpload_time() {
        return upload_time;
    }

    public void setUpload_time(Timestamp upload_time) {
        this.upload_time = upload_time;
    }
}
