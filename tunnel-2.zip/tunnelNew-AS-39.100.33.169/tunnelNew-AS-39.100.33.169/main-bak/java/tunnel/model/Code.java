package tunnel.model;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;

import java.util.Random;

/**
 * Created by littlecurl 2018/6/24
 */

public class Code {
    /**
     * 闅忔満鏁版暟缁�
     * 鍘婚櫎浜嗘槗娣锋穯鐨� 鏁板瓧 0 鍜� 瀛楁瘝 o O
     *                鏁板瓧 1 鍜� 瀛楁瘝 i I l L
     *                鏁板瓧 6 鍜� 瀛楁瘝 b
     *                鏁板瓧 9 鍜� 瀛楁瘝 q
     *                瀛楁瘝 c C 鍜� G
     *                瀛楁瘝 t 锛堢粡甯稿拰闅忔満绾挎贩鍦ㄤ竴璧风湅涓嶆竻锛�
     */
    private static final char[] CHARS = {
            '2', '3', '4', '5',  '7', '8',
            'a',  'd', 'e', 'f', 'g', 'h', 'j', 'k', 'm',
            'n', 'p',  'r', 's',  'u', 'v', 'w', 'x', 'y', 'z',
            'A', 'B',  'D', 'E', 'F',  'H',  'J', 'K', 'M',
            'N', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'
    };

    private static Code bmpCode;

    public static Code getInstance() {
        if(bmpCode == null)
            bmpCode = new Code();
        return bmpCode;
    }

    //default settings
    //楠岃瘉鐮侀粯璁ら殢鏈烘暟鐨勪釜鏁�
    private static final int DEFAULT_CODE_LENGTH = 4;
    //榛樿瀛椾綋澶у皬
    private static final int DEFAULT_FONT_SIZE = 25;
    //榛樿绾挎潯鐨勬潯鏁�
    private static final int DEFAULT_LINE_NUMBER = 5;
    //padding鍊�
    private static final int BASE_PADDING_LEFT = 10, RANGE_PADDING_LEFT = 15, BASE_PADDING_TOP = 15, RANGE_PADDING_TOP = 20;
    //楠岃瘉鐮佺殑榛樿瀹介珮
    private static final int DEFAULT_WIDTH = 100, DEFAULT_HEIGHT = 40;

    //settings decided by the layout xml
    //canvas width and height
    private int width = DEFAULT_WIDTH, height = DEFAULT_HEIGHT;

    //random word space and pading_top
    private int base_padding_left = BASE_PADDING_LEFT, range_padding_left = RANGE_PADDING_LEFT,
            base_padding_top = BASE_PADDING_TOP, range_padding_top = RANGE_PADDING_TOP;

    //number of chars, lines; font size
    private int codeLength = DEFAULT_CODE_LENGTH, line_number = DEFAULT_LINE_NUMBER, font_size = DEFAULT_FONT_SIZE;

    //variables
    private String code;
    private int padding_left, padding_top;
    private Random random = new Random();
    //楠岃瘉鐮佸浘鐗�
    public Bitmap createBitmap() {
        padding_left = 0;

        Bitmap bp = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bp);

        code = createCode();

        c.drawColor(Color.WHITE);
        Paint paint = new Paint();
        paint.setAntiAlias(true);
        paint.setTextSize(font_size);
        //鐢婚獙璇佺爜
        for (int i = 0; i < code.length(); i++) {
            randomTextStyle(paint);
            randomPadding();
            c.drawText(code.charAt(i) + "", padding_left, padding_top, paint);
        }
        //鐢荤嚎鏉�
        for (int i = 0; i < line_number; i++) {
            drawLine(c, paint);
        }

        c.save( Canvas.ALL_SAVE_FLAG );//淇濆瓨
        c.restore();//
        return bp;
    }

    public String getCode() {
        return code;
    }

    //鐢熸垚楠岃瘉鐮�
    private String createCode() {
        StringBuilder buffer = new StringBuilder();
        for (int i = 0; i < codeLength; i++) {
            buffer.append(CHARS[random.nextInt(CHARS.length)]);
        }
        return buffer.toString();
    }
    //鐢诲共鎵扮嚎
    private void drawLine(Canvas canvas, Paint paint) {
        int color = randomColor();
        int startX = random.nextInt(width);
        int startY = random.nextInt(height);
        int stopX = random.nextInt(width);
        int stopY = random.nextInt(height);
        paint.setStrokeWidth(1);
        paint.setColor(color);
        canvas.drawLine(startX, startY, stopX, stopY, paint);
    }
    //鐢熸垚闅忔満棰滆壊
    private int randomColor() {
        return randomColor(1);
    }

    private int randomColor(int rate) {
        int red = random.nextInt(256) / rate;
        int green = random.nextInt(256) / rate;
        int blue = random.nextInt(256) / rate;
        return Color.rgb(red, green, blue);
    }
    //闅忔満鐢熸垚鏂囧瓧鏍峰紡锛岄鑹诧紝绮楃粏锛屽�炬枩搴�
    private void randomTextStyle(Paint paint) {
        int color = randomColor();
        paint.setColor(color);
        paint.setFakeBoldText(random.nextBoolean());  //true涓虹矖浣擄紝false涓洪潪绮椾綋
        float skewX = random.nextInt(11) / 10;
        skewX = random.nextBoolean() ? skewX : -skewX;
        paint.setTextSkewX(skewX); //float绫诲瀷鍙傛暟锛岃礋鏁拌〃绀哄彸鏂滐紝鏁存暟宸︽枩
        //paint.setUnderlineText(true); //true涓轰笅鍒掔嚎锛宖alse涓洪潪涓嬪垝绾�
        //paint.setStrikeThruText(true); //true涓哄垹闄ょ嚎锛宖alse涓洪潪鍒犻櫎绾�
    }
    //闅忔満鐢熸垚padding鍊�
    private void randomPadding() {
        padding_left += base_padding_left + random.nextInt(range_padding_left);
        padding_top = base_padding_top + random.nextInt(range_padding_top);
    }
}

