package tunnel;

import com.beardedhen.androidbootstrap.BootstrapButton;
import com.google.gson.Gson;
import com.jie.cameraimage.R;
import com.tunnel.dao.android.ProcessConst;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.*;

import tunnel.JDBC.DBOpenHelper;
import tunnel.design.ActivityRunningConfig;
import tunnel.design.DesignInfo;

public class CommonActivity extends Activity {
    protected BootstrapButton xiaodaoguan;
    protected BootstrapButton daoguanzhujiang;
    protected BootstrapButton zuankong;
    protected BootstrapButton maopen;
    protected BootstrapButton maogan;
    protected BootstrapButton guanpengchengpin;
    protected BootstrapButton guanpenganzhuang;
    protected BootstrapButton guanpengzhujiang;
    protected BootstrapButton guanpeng;
    protected BootstrapButton daoguananzhuang;
    protected BootstrapButton guawang;
    protected BootstrapButton gongjia;
    protected BootstrapButton V_shuoming;
    protected Button back;
    protected RadioButton btnHome;
    protected RadioButton btnLocal;
    protected RadioButton btnUpload;
    protected RadioButton btnMe;
    protected TextView place;
    protected TextView tvRockGrade;
    protected String footage_id;
    // 当前Context
    protected Activity currentContext = null;
    protected DBOpenHelper dbHelper = null;

    // 指向对话框的资源id
    protected int layoutResID = -1;
    // 设计信息，子类需要专门指定
    protected DesignInfo di = null;

    /**
     * 设置对话框资源id
     * @param layoutResID
     */
    public void setLayoutResID(int layoutResID) {
        this.layoutResID = layoutResID;
    }

    /**
     * 设置围岩等级设计规范
     * @param info
     */
    public void setDesignInfo(DesignInfo info) {
        di = info;
    }

    /**
     * 设置当前Context
     * @param context
     */
    public void setCurrentContext(Activity context) {
        this.currentContext = context;
        dbHelper = new DBOpenHelper(currentContext);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(layoutResID);

        daoguanzhujiang = (BootstrapButton) findViewById(R.id.daoguanzhujiang);
        zuankong = (BootstrapButton) findViewById(R.id.zuankong);
        maopen = (BootstrapButton) findViewById(R.id.maopen);
        maogan = (BootstrapButton) findViewById(R.id.maogan);
        guanpengchengpin = (BootstrapButton) findViewById(R.id.guanpengchengpin);
        guanpenganzhuang = (BootstrapButton) findViewById(R.id.guanpenganzhuang);
        guanpengzhujiang = (BootstrapButton) findViewById(R.id.guanpengzhujiang);
        daoguananzhuang = (BootstrapButton) findViewById(R.id.daoguananzhuang);
        btnHome = (RadioButton) findViewById(R.id.radio_button0);
        btnLocal = (RadioButton) findViewById(R.id.radio_button1);
        btnUpload = (RadioButton) findViewById(R.id.radio_button2);
        btnMe = (RadioButton) findViewById(R.id.radio_button3);
        back = (Button) findViewById(R.id.back);
        guawang = (BootstrapButton) findViewById(R.id.guawang);
        gongjia = (BootstrapButton) findViewById(R.id.gongjia);
        V_shuoming = (BootstrapButton) findViewById(R.id.V_shuoming);
        place = (TextView) findViewById(R.id.place);
        tvRockGrade = (TextView) findViewById(R.id.rock_grade);

        SharedPreferences sp = getSharedPreferences("data", Context.MODE_PRIVATE);
        final String txPlace = sp.getString("place", "");


        // 首先获取到意图对象
        Intent intent = getIntent();

        // 获取到传递过来的姓名
        final String tunnel = intent.getStringExtra("tunnel");
        //查询应该填写进尺数的process_id
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor =	db.rawQuery("select footage_id from design_footage where isFinish = ? and tunnel_id = ?",new String[]{"0",txPlace});
        while(cursor.moveToNext()) {
            int nameColumnIndex = cursor.getColumnIndex("footage_id");
            footage_id = cursor.getString(nameColumnIndex);
            if(null != footage_id) break;
        }
        SharedPreferences.Editor editor = sp.edit();
        editor.putString("footage_id", footage_id);
        place.setText(txPlace);

        tvRockGrade.setText(intent.getStringExtra("rock_grade"));

        btnHome.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent = new Intent(currentContext, HomeActivity.class);
                startActivity(intent);
            }
        });
        btnLocal.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent = new Intent(currentContext, LocalActivity.class);
                startActivity(intent);
            }
        });
        btnUpload.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent = new Intent(currentContext, NoUploadActivity.class);
                startActivity(intent);
            }
        });
        btnMe.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent = new Intent(currentContext, MeActivity.class);
                startActivity(intent);
            }
        });

        maopen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 子流程
                String sub = ProcessConst.SUB_XIAO_MAO_PENG;
                // 设计信息的id
                String designInfoId = DesignInfo.MAO_PENG;
                jump2SubProcess(sub, designInfoId, tunnel);
            }
        });

        daoguanzhujiang.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 子流程
                String sub = ProcessConst.SUB_XIAO_DAO_GUAN_ZHU_JIANG;
                // 设计信息的id
                String designInfoId = DesignInfo.XIAO_DAO_GUAN_ZHU_JIANG;
                jump2SubProcess(sub, designInfoId, tunnel);
            }
        });

        daoguananzhuang.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 子流程
                String sub = ProcessConst.SUB_XIAO_DAO_GUAN_AN_ZHUANG;
                // 设计信息的id
                String designInfoId = DesignInfo.CHAO_QIAN_XIAO_DAO_GUAN;
                jump2SubProcess(sub, designInfoId, tunnel);
            }
        });

        guanpengchengpin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 子流程
                String sub = ProcessConst.SUB_GUAN_PENG_CHEN_PING;
                // 设计信息的id
                String designInfoId = DesignInfo.CHAO_QIAN_GUAN_PENG_CHEN_PING;
                jump2SubProcess(sub, designInfoId, tunnel);
            }
        });

        guanpengzhujiang.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 子流程
                String sub = ProcessConst.SUB_GUAN_PENG_ZHU_JIANG;
                // 设计信息的id
                String designInfoId = DesignInfo.CHAO_QIAN_GUAN_PENG_ZHU_JIANG;
                jump2SubProcess(sub, designInfoId, tunnel);
            }
        });

        gongjia.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 子流程
                String sub = ProcessConst.SUB_XIAO_ZHI_LI_GANG_GONG_JIA;
                // 设计信息的id
                String designInfoId = DesignInfo.ZHI_LI_GANG_GONG_JIA;
                jump2SubProcess(sub, designInfoId, tunnel);
            }
        });

        guanpenganzhuang.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 子流程
                String sub = ProcessConst.SUB_GUAN_PENG_AN_ZHUANG;
                // 设计信息的id
                String designInfoId = DesignInfo.CHAO_QIAN_GUAN_PENG_AN_ZHAUNG;
                jump2SubProcess(sub, designInfoId, tunnel);
            }
        });

        maogan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 子流程
                String sub = ProcessConst.SUB_XIAO_MAO_GAN;
                // 设计信息的id
                String designInfoId = DesignInfo.MAO_GAN;
                jump2SubProcess(sub, designInfoId, tunnel);
            }
        });

        guawang.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // 子流程
                String sub = ProcessConst.SUB_XIAO_GUA_WANG;
                // 设计信息的id
                String designInfoId = DesignInfo.GUA_WANG;
                jump2SubProcess(sub, designInfoId, tunnel);
            }
        });

        zuankong.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 子流程
                String sub = ProcessConst.SUB_XIAO_CHAO_QIAN_ZUAN_TAN;
                // 设计信息的id
                String designInfoId = DesignInfo.CHAO_QIAN_ZUAN_TAN;
                jump2SubProcess(sub, designInfoId, tunnel);
            }
        });

        V_shuoming.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // 子流程
                String sub = ProcessConst.SUB_ZONG_JIN_CHI_SHU;
                // 设计信息的id
                String designInfoId = DesignInfo.JIN_CHI_JI_SHUO_MING;
                jump2SubProcess(sub, designInfoId, tunnel);
            }
        });

        back.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                currentContext.finish();
            }
        });
    }

    private void jump2SubProcess(String sub, String designInfoId, String tunnel) {
        Class clazz = Subprocess2ActivityHelper.getActivity(sub);

        Intent intent = new Intent(currentContext, clazz);
        Gson gson = new Gson();
        String diJson = gson.toJson(di);
        intent.putExtra("design_info", diJson);
        intent.putExtra("tunnel", tunnel);
        intent.putExtra("process", sub);

        String rock_grade = getIntent().getStringExtra("rock_grade");
        intent.putExtra("rock_grade", rock_grade);

        intent.putExtra("subprocess", sub);

        // 设置按钮路径-- Level_1
        ActivityRunningConfig.getInstance().setButtonPathLevel_1(designInfoId);
        startActivityForResult(intent, 1);
    }
}
