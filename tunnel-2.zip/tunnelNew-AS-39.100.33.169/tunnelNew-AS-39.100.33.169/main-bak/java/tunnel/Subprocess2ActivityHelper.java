package tunnel;

import com.tunnel.dao.android.ProcessConst;

import java.util.HashMap;
import java.util.Map;

/**
 * 子流程工具类
 */
public class Subprocess2ActivityHelper {
    protected static Map<String, Class> subprocess2Activity = null;

    /**
     * 根据子流程名，获得对应的Activity
     * @param subProcess
     * @return
     */
    public static Class getActivity(String subProcess) {
        if(null == subprocess2Activity) {
            subprocess2Activity = new HashMap<String, Class>();
            subprocess2Activity.put(ProcessConst.SUB_XIAO_MAO_PENG, MainActivity.class);
            subprocess2Activity.put(ProcessConst.SUB_XIAO_DAO_GUAN_ZHU_JIANG, MainActivity.class);
            subprocess2Activity.put(ProcessConst.SUB_XIAO_DAO_GUAN_AN_ZHUANG, MainActivity.class);
            subprocess2Activity.put(ProcessConst.SUB_GUAN_PENG_CHEN_PING, MainActivity.class);
            subprocess2Activity.put(ProcessConst.SUB_GUAN_PENG_ZHU_JIANG, MainActivity.class);
            subprocess2Activity.put(ProcessConst.SUB_XIAO_ZHI_LI_GANG_GONG_JIA, MainActivity.class);
            subprocess2Activity.put(ProcessConst.SUB_GUAN_PENG_AN_ZHUANG, MainActivity.class);
            subprocess2Activity.put(ProcessConst.SUB_XIAO_MAO_GAN, MainActivity.class);
            subprocess2Activity.put(ProcessConst.SUB_XIAO_GUA_WANG, MainActivity.class);

            subprocess2Activity.put(ProcessConst.SUB_XIAO_CHAO_QIAN_ZUAN_TAN, OffsetActivity.class);

            subprocess2Activity.put(ProcessConst.SUB_ZONG_JIN_CHI_SHU, RemarkActivity.class);

            subprocess2Activity.put(ProcessConst.SUB_WEI_YAN_BIAN_GENG, RockChangeActivity.class);
        }
        return subprocess2Activity.get(subProcess);
    }
}
