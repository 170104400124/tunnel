package tunnel.service;

import android.util.Log;

import java.io.IOException;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.Response;

/**
 * Created by Leon on 2019/5/8.
 */

public class UploadCallBack implements Callback {
    boolean isFinished = false;
    boolean isSuccess = false;

    public boolean isFinished() {
        return isFinished;
    }

    public boolean isSuccess() {
        return isSuccess;
    }

    @Override
    public void onFailure(Call call, IOException e) {

    }

    @Override
    public void onResponse(Call call, Response response) throws IOException {
        isFinished = true;
        Log.i("xxx","1、连接的消息"+response.message());
        if(response.isSuccessful()){
            isSuccess = true;
            Log.i("xxx","2、连接成功获取的内容"+response.body().string());
        }
    }
}
