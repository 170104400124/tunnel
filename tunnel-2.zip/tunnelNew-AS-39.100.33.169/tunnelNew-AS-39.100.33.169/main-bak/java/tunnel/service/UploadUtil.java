package tunnel.service;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.util.Map;
import java.util.TreeMap;
import java.util.UUID;

import android.app.Activity;
import android.util.Log;

import okhttp3.FormBody;
import okhttp3.Headers;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;

public class UploadUtil extends Activity {
    private static final int TIME_OUT = 5 * 1000;   //超时时间
    private static final String CHARSET = "utf-8"; //设置编码
    public static final String SUCCESS = "1";
    public static final String FAILURE = "0";
    public static boolean isupload = false;

    boolean okhttponResponse  = false;

    public static void add(FormBody.Builder builder, String key, String value) {
        if(value != null) {
            builder.add(key, value);
        }
    }

    public static String uploadFile(File file, String user_id, String offset, String tunnelName, String processName, String key, String uploadtime, int isUpload, String remarks, String savetime, String oldRock, String newRock, String RequestURL) {
        String BOUNDARY = UUID.randomUUID().toString();  //边界标识   随机生成
        String PREFIX = "--", LINE_END = "\r\n";
        HttpURLConnection conn = null;
        try {
//            tunnelName = MD5Utils.md5(tunnelName);
//            processName = MD5Utils.md5(processName);

            if (file != null && !file.getName().equals("")) {
                //一种：参数请求体z
                FormBody.Builder builder =new FormBody.Builder();
                add(builder, "user_id",user_id+"");
                add(builder, "offset",offset);
                add(builder, "tunnelName",tunnelName);
                add(builder, "processName",processName+"");
                add(builder, "key",key+"");
                add(builder, "uploadtime", uploadtime);
                add(builder,"isUpload", "0");
                add(builder, "remarks", remarks);
                add(builder, "savetime", savetime);
                add(builder, "oldRock", oldRock);
                add(builder, "newRock", newRock);

                FormBody paramsBody = builder.build();
                //二种：文件请求体
                MediaType type= MediaType.parse("application/octet-stream");//"text/xml;charset=utf-8"
                RequestBody fileBody=RequestBody.create(type,file);

                //三种：混合参数和文件请求
                RequestBody multipartBody = new MultipartBody.Builder()
                        .setType(MultipartBody.ALTERNATIVE)
                        //一样的效果
                        .addPart(Headers.of(
                                "Content-Disposition",
                                "form-data; name=\"params\"")
                                ,paramsBody)
                        .addPart(Headers.of(
                                "Content-Disposition",
                                "form-data; name=\"imageFile\"; filename=\""+file.getName()+"\"")
                                , fileBody)

                        //一样的效果
        /*.addFormDataPart("id",currentPlan.getPlanId()+"")
        .addFormDataPart("name",currentPlan.getName())
        .addFormDataPart("volume",currentPlan.getVolume())
        .addFormDataPart("type",currentPlan.getType()+"")
        .addFormDataPart("mode",currentPlan.getMode()+"")
        .addFormDataPart("params","plans.xml",fileBody)*/
                        .build();
                Request request=new Request.Builder().url(RequestURL)
                        .addHeader("User-Agent","android")
                        .header("Content-Type","text/html; charset=utf-8;")
                        .post(multipartBody)//传参数、文件或者混合，改一下就行请求体就行
                        .build();


                OkHttpClient client=new OkHttpClient();
                UploadCallBack callBack = new UploadCallBack();
                client.newCall(request).enqueue(callBack);
                int time = 0;
                int interval = 100;
                while(!callBack.isFinished()) {
                    Thread.sleep(interval);
                    time += interval;
                    if(time > TIME_OUT) {
                        return FAILURE;
                    }
                }
                if(callBack.isSuccess()){
                    return  SUCCESS;
                };
//                URL url = new URL(RequestURL);
//                conn = (HttpURLConnection) url.openConnection();
////                RequestURL = RequestURL + "?user_id=" + user_id + "&offset=" + offset + "&tunnelName=" + tunnelName + "&processName=" + processName + "&key=" + key + "&uploadtime=" + uploadtime + "&isUpload=" + isUpload + "&remarks=" + remarks + "&savetime=" + savetime;
//                conn = (HttpURLConnection) new URL(RequestURL).openConnection();
//                conn.setReadTimeout(TIME_OUT);
//                conn.setConnectTimeout(TIME_OUT);
//                conn.setDoInput(true);  //允许输入流
//                conn.setDoOutput(true); //允许输出流
//                conn.setUseCaches(false);  //不允许使用缓存
//
//                conn.setRequestMethod("POST");  //请求方式
//                conn.setRequestProperty("Charset", CHARSET);  //设置编码
//                conn.setRequestProperty("connection", "keep-alive");
//                conn.setRequestProperty("Content-Type", "multipart/form-data" + ";boundary=" + BOUNDARY);
//
//                OutputStream outputSteam = conn.getOutputStream();
//                DataOutputStream dos = new DataOutputStream(outputSteam);
//                //上传参数
//                dos.writeBytes( getStrParams(strParams).toString() );
//                dos.flush();
//
//                StringBuffer sb = new StringBuffer();
//                sb.append(PREFIX);
//                sb.append(BOUNDARY);
//                sb.append(LINE_END);
//                /**
//                 * 这里重点注意：
//                 * name里面的值为服务器端需要key   只有这个key 才可以得到对应的文件
//                 * filename是文件的名字，包含后缀名的   比如:abc.png
//                 */
//
//                Log.i("file.getName()",file.getName());
//                sb.append("Content-Disposition: form-data; name=\"imageFile\"; filename=\"" + file.getName() + "\"" + LINE_END);
//                sb.append("Content-Type: application/octet-stream; charset=" + CHARSET + LINE_END);
//                sb.append(LINE_END);
//                dos.write(sb.toString().getBytes());
//                InputStream is = new FileInputStream(file);
//                byte[] bytes = new byte[1024];
//                int len = 0;
//                while ((len = is.read(bytes)) != -1) {
//                    dos.write(bytes, 0, len);
//                }
//                is.close();
//                dos.write(LINE_END.getBytes());
//                byte[] end_data = (PREFIX + BOUNDARY + PREFIX + LINE_END).getBytes();
//                dos.write(end_data);
//                dos.flush();
//                dos.close();
//                /**
//                 * 获取响应码  200=成功
//                 * 当响应成功，获取响应的流
//                 */
//                int res = conn.getResponseCode();
//                Log.e("response code", "response code:" + res);
//                if (res == 200) {
//                    return SUCCESS;
//                }
            }
            else if (file == null || file.getName().equals("")) {
                RequestURL = RequestURL.replace("ImgServlet", "ImgServlet_Blank");
                Map<String, String> params = new TreeMap<String, String>();
                params.put("user_id", user_id);
                params.put("offset", offset);
                params.put("tunnelName", tunnelName);
                params.put("processName", processName);
                params.put("key", key);
                params.put("uploadtime",uploadtime);
                params.put("isUpload", Integer.toString(isUpload));
                params.put("remarks", remarks);
                params.put("savetime", savetime);
                params.put("oldRock", oldRock);
                params.put("newRock", newRock);
                /**
                 * 获取响应码  200=成功
                 * 当响应成功，获取响应的流
                 */
                int res = sendPost(RequestURL, params);
                Log.e("response code", "response code:" + res);
                if (res == 200) {
                    return SUCCESS;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }finally {
            if(null != conn) {
                conn.disconnect();
            }
        }
        return FAILURE;
    }

    /**
     * 发送POST请求
     *
     * @param url
     *            目的地址
     * @param parameters
     *            请求参数，Map类型。
     * @return 远程响应结果
     */
    public static int sendPost(String url, Map<String, String> parameters) {
        String result = "";// 返回的结果
        BufferedReader in = null;// 读取响应输入流
        PrintWriter out = null;
        StringBuffer sb = new StringBuffer();// 处理请求参数
        String params = "";// 编码之后的参数
        int code = -1;
        try {
            // 编码请求参数
            if (parameters.size() == 1) {
                for (String name : parameters.keySet()) {
                    if(null == name || parameters.get(name) ==null) {
                        continue;
                    }
                    sb.append(name).append("=").append(
                            java.net.URLEncoder.encode(parameters.get(name),
                                    "UTF-8"));
                }
                params = sb.toString();
            } else {
                for (String name : parameters.keySet()) {
                    if(null == name || parameters.get(name) ==null) {
                        continue;
                    }
                    sb.append(name).append("=").append(
                            java.net.URLEncoder.encode(parameters.get(name),
                                    "UTF-8")).append("&");
                }
                String temp_params = sb.toString();
                params = temp_params.substring(0, temp_params.length() - 1);
            }
            // 创建URL对象
            java.net.URL connURL = new java.net.URL(url);
            // 打开URL连接
            java.net.HttpURLConnection httpConn = (java.net.HttpURLConnection) connURL
                    .openConnection();
            // 设置通用属性
            httpConn.setRequestProperty("Accept", "*/*");
            httpConn.setRequestProperty("Connection", "Keep-Alive");
            httpConn.setRequestProperty("User-Agent",
                    "Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 6.1)");
            // 设置POST方式
            httpConn.setDoInput(true);
            httpConn.setDoOutput(true);
            // 获取HttpURLConnection对象对应的输出流
            out = new PrintWriter(httpConn.getOutputStream());
            // 发送请求参数
            out.write(params);
            // flush输出流的缓冲
            out.flush();
            // 定义BufferedReader输入流来读取URL的响应，设置编码方式
            in = new BufferedReader(new InputStreamReader(httpConn
                    .getInputStream(), "UTF-8"));
            String line;

            code = httpConn.getResponseCode();
            // 读取返回的内容
            while ((line = in.readLine()) != null) {
                result += line;
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (out != null) {
                    out.close();
                }
                if (in != null) {
                    in.close();
                }
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        }
        return code;
    }
}
