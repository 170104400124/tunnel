package tunnel.adapter;

import java.util.List;

import net.tsz.afinal.FinalBitmap;
import tunnel.model.Const;
import tunnel.model.ImageModel;

import com.jie.cameraimage.R;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.ImageView;

/**
 * @ClassName: MainGridViewAdapter
 * @Description: GridView适配器
 * @Date 2016年10月28日
 * @author jie
 */
public class MainGridViewAdapter extends BaseAdapter implements Const {

	private List<ImageModel> list;
	private int checkBoxState;
	private LayoutInflater layoutInflater;
	private FinalBitmap finalBitmap;
	
	
	
	public MainGridViewAdapter(List<ImageModel> list, Context context, int checkBoxState) {
		this.list = list;
		this.checkBoxState = checkBoxState;
		layoutInflater = LayoutInflater.from(context);
		finalBitmap = FinalBitmap.create(context);
	}
	
	@Override
	public int getCount() {
		return list.size();
	}

	@Override
	public Object getItem(int position) {
		return list.get(position);
	}

	@Override
	public long getItemId(int position) {
		return position;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		ImageModel imageModel = list.get(position);
		
		convertView = layoutInflater.inflate(R.layout.main_girdview_item, parent, false);
		ImageView imageView = (ImageView) convertView.findViewById(R.id.mainGridViewItem_image_imageView);
		CheckBox stateView = (CheckBox) convertView.findViewById(R.id.mainGridViewItem_state_checkBox);
		
		String path = imageModel.getImagePath(); // 图片文件保存路径
		boolean state = imageModel.isImageState(); // 图片选择状态
		int spareImg = imageModel.getSpareImage(); // 备用显示图片
		if ((null == path || path.equals("")) && spareImg != 0) {
			imageView.setImageResource(spareImg);
		} else {
			finalBitmap.display(imageView, path);
			stateView.setChecked(state);
		}
		
		stateView.setVisibility(checkBoxState); // 设置控件显示状态， 首页不显示，图片多选页显示
		
		return convertView;
	}

}
