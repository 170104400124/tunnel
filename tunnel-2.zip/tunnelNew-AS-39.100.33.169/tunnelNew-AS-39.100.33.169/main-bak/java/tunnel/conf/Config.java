package tunnel.conf;

import android.os.Build;

public class Config {
    public static final String IP = "39.100.33.169";
//    public static final String IP = "192.168.1.6";
    public static final String Port = "8080";

    public static final String IpPort = IP + ":" + Port;
    public static final String HttpIpPort = "http://" + IP + ":" + Port;

    public static final String mUpdateUrl = HttpIpPort + "/appupdate/update.jsp";
    public static final String ServerURL= HttpIpPort + "/tunnel/ImgServlet";

    // 权限设置版本
    public static final int PERMISSION_VERSION = Build.VERSION_CODES.LOLLIPOP_MR1;
    // 拍照
    public static final int IMAGE_VERSION = Build.VERSION_CODES.LOLLIPOP_MR1;
}
