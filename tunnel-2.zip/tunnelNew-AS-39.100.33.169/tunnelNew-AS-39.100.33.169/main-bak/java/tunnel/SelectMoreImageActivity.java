package tunnel;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import com.jie.cameraimage.R;
import tunnel.adapter.MainGridViewAdapter;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Environment;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import tunnel.model.Const;
import tunnel.model.ImageModel;
import android.widget.GridView;
import android.widget.Toast;

/**
 * @ClassName: SelectMoreImageActivity
 * @Description: 相册多选Activity
 * @Date 2016年10月28日
 * @author jie
 */
public class SelectMoreImageActivity extends Activity implements Const, OnClickListener, OnItemClickListener {

	private GridView imageGridView;
	
	private int imageCount = 0; // 已在上传列表中的图片数量
	
    private List<ImageModel> imageModelList; // 当前页显示的List
    private MainGridViewAdapter adapter;
    private Intent intent;
    private ArrayList<String> returnPathList; // 返回前一页时传送的list
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.select_more_image);
		
		initView();
		initData();
		
	}

	private void initView() {
		imageGridView = (GridView) findViewById(R.id.selectMoreImage_data_gridView);
		imageGridView.setOnItemClickListener(this);
		findViewById(R.id.selectMoreImage_goback_button).setOnClickListener(this);
		findViewById(R.id.selectMoreImage_ok_button).setOnClickListener(this);
	}

	private void initData() {
		
		intent = getIntent();
		imageCount = intent.getExtras().getInt("imageCount"); // 获取前页待上传数量
		returnPathList = intent.getExtras().getStringArrayList("photoArrayList"); // 获取前页待上传路径集合,存入待返回的集合
		
		// TODO 存在问题:没有兼容所有手机的相册存储路径，测试在畅享5手机上该界面为空白，红米2A则可以显示
		//             此问题我暂时还没细查，可以让用户单选或者拍照。
		// 获取默认相机的存储路径
		String DCIMPath = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM).toString();
		String cameraPath = DCIMPath + File.separator + "Camera";
		
		// 获取默认相机路径下所有图片文件名
		List<String> allImageFormCamera = getImageFileName(cameraPath);
		imageModelList = new ArrayList<ImageModel>();
		ImageModel imageModel;
		for (String string : allImageFormCamera) {
			imageModel = new ImageModel();
			imageModel.setImagePath(string);
			imageModel.setImageState(false);
			imageModelList.add(imageModel);
		}
		
		List<String> equalsList = new ArrayList<String>(); // 相同数据（之前选择过的数据）
		// 遍历传入的路径，若路径完全相同，则为之前选择过的，将对象的选中状态设为true
		for (String intentStr : returnPathList) {
			for (int i = 0; i < imageModelList.size(); i++) {
				ImageModel imageModel2 = imageModelList.get(i);
				if (imageModel2.getImagePath().equals(intentStr)) {
					imageModel2.setImageState(true);
					imageModelList.set(i, imageModel2);
					equalsList.add(intentStr);
				}
			}
		}
		returnPathList.removeAll(equalsList); // 移除返回List中处理过的相同值
		
		adapter = new MainGridViewAdapter(imageModelList, this, View.VISIBLE);
		imageGridView.setAdapter(adapter);
	}

	/**
	 * 获取指定目录下所有指定类型的文件
	 * @param filePath 指定路径
	 */
	private List<String> getImageFileName(String filePath) {
		List<String> fileList = new ArrayList<String>();
		File file = new File(filePath);
		File[] subFile = file.listFiles();
		
		for (int i = 0; i < subFile.length; i++) {
			// 判断是否为文件夹
			if (!subFile[i].isDirectory()) {
				String fileName = subFile[i].getName();
				String LowerFileName = fileName.trim().toLowerCase(Locale.ENGLISH);
				if (LowerFileName.endsWith(".jpg") || LowerFileName.endsWith(".jpeg") || LowerFileName.endsWith(".png")) {
					fileList.add(filePath + File.separator + fileName);
				}
			}
		}
		return fileList;
	}
	
	@Override
	public void onClick(View view) {
		switch (view.getId()) {
		case R.id.selectMoreImage_ok_button:
//			returnPathList.removeAll(returnPathList);
			for (ImageModel imageModel : imageModelList) { // 遍历当前界面imageModelList
				if (imageModel.isImageState()) { // 如果选择状态是true
					returnPathList.add(imageModel.getImagePath()); // 则将路径添加至返回时传送的list
				}
			}
			
			// 设置intent传送参数，返回前一页
			intent = new Intent();
			intent.putStringArrayListExtra("returnPathList", returnPathList);
			setResult(Activity.RESULT_OK, intent);
			finish();
			
			break;
		}
	}

	@Override
	public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
		ImageModel imageModel = imageModelList.get(position);
		if (imageModel.isImageState()) {
			imageModel.setImageState(false);
			imageCount -= 1;
		} else if (imageCount < MAX_IMAGECOUNT) {
			imageModel.setImageState(true);
			imageCount += 1;
		} else {
			Toast.makeText(this, "单次最多上传" + MAX_IMAGECOUNT + "张图片", Toast.LENGTH_SHORT).show();
		}
		imageModelList.set(position, imageModel);
		adapter.notifyDataSetChanged();
	}

}