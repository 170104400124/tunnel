package tunnel;


import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.util.Log;
import android.widget.AdapterView.OnItemSelectedListener;
import tunnel.JDBC.DBOpenHelper;

import java.util.ArrayList;
import java.util.List;

import com.jie.cameraimage.R;
import com.tunnel.dao.android.DutyImp;
import com.tunnel.model.DutyData;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.*;

public class MeActivity extends Activity {

	private TextView txname;
	private TextView txposition;
	private Spinner spntunnel;
//	private Spinner spnposition;
	private TextView phone;
	private String pos;
	private List<CharSequence> posList = null;
	ArrayAdapter<CharSequence> posAdapter = null;
	DBOpenHelper dbHelper = new DBOpenHelper(MeActivity.this);
	RadioButton btnHome;
	RadioButton btnLocal;
	RadioButton btnUpload;
	RadioButton btnMe;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_me);
		initView();
		initData();
	}
	
	private void initView() {
		txname = (TextView) findViewById(R.id.me_name);
		txposition = (TextView) findViewById(R.id.me_position);
		spntunnel = (Spinner) findViewById(R.id.me_spntunnel);
		//spnposition = (Spinner) findViewById(R.id.me_spnposition);
		phone = (TextView) findViewById(R.id.me_phone);
		btnHome = (RadioButton) findViewById(R.id.radio_button0);
		btnLocal = (RadioButton) findViewById(R.id.radio_button1);
		btnUpload = (RadioButton) findViewById(R.id.radio_button2);
		btnMe = (RadioButton) findViewById(R.id.radio_button3);
		btnHome.setOnClickListener(new View.OnClickListener() {
			
			public void onClick(View v) {
				Intent intent = new Intent(MeActivity.this, HomeActivity.class);
				startActivity(intent);
			}
		});
		btnLocal.setOnClickListener(new View.OnClickListener() {
			
			public void onClick(View v) {
				Intent intent = new Intent(MeActivity.this, LocalActivity.class);
				startActivity(intent);
			}
		});
		btnUpload.setOnClickListener(new View.OnClickListener() {
			
			public void onClick(View v) {
				Intent intent = new Intent(MeActivity.this, NoUploadActivity.class);
				startActivity(intent);
			}
		});
	}
	
	private void initData() {
		SharedPreferences sp = getSharedPreferences("data", Context.MODE_PRIVATE);
		String user_id = sp.getString("user_id", "");
		txname.setText(user_id);
		String position = sp.getString("position", "");
		txposition.setText(position);
		
		
//		spnposition.setOnItemSelectedListener(new OnItemSelectedListener() {
//			@Override
//			public void onNothingSelected(AdapterView<?> parent) {
//				// TODO Auto-generated method stub
//			}
//			@Override
//			public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
//				//拿到被选择项的值
//				//pos = (String) spnposition.getSelectedItem();
//				pos=parent.getItemAtPosition(position).toString();
//		        Toast.makeText(MeActivity.this, "您选中的职位是" + pos, Toast.LENGTH_SHORT).show();
//			}
//		});
		
		posList = new ArrayList<CharSequence>();

		DutyImp dutyImp = new DutyImp(MeActivity.this);
		List<DutyData> dutyList = dutyImp.getDutyList(user_id);
		for(DutyData dd : dutyList) {
			posList.add(dd.getTunnel_id());
		}
		posAdapter = new ArrayAdapter<CharSequence>(this,android.R.layout.simple_spinner_item,posList);
		posAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		spntunnel.setAdapter(posAdapter);

		// 检查版本号
		checkVersion(MeActivity.this);
	}

	public void checkVersion(Context context) {
		// 检查版本号
		try {
			PackageManager pm = context.getPackageManager();
			PackageInfo packageInfo = null;
			packageInfo = pm.getPackageInfo(context.getPackageName(), 0);
			String version = packageInfo.versionName;
			String versionCode = packageInfo.versionCode+"";

			Toast.makeText(MeActivity.this, version, Toast.LENGTH_SHORT).show();
			Toast.makeText(MeActivity.this, versionCode, Toast.LENGTH_SHORT).show();
		} catch (PackageManager.NameNotFoundException e) {
			Log.e("版本显示错误", e.getMessage());
		}

	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.me, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
	
	public void queryTunnel(String user_id) {
		
	}
}
