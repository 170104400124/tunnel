package tunnel;

import java.util.ArrayList;
import java.util.List;

import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;

import com.jie.cameraimage.R;
import com.tunnel.dao.android.DutyImp;
import com.tunnel.dao.android.ProcessConst;
import com.tunnel.model.DutyData;
import com.vector.update_app.UpdateAppBean;
import com.vector.update_app.UpdateAppManager;
import com.vector.update_app.UpdateCallback;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.*;
import android.widget.AdapterView.OnItemSelectedListener;
import tunnel.JDBC.DBOpenHelper;
import tunnel.design.ActivityRunningConfig;
import tunnel.design.DesignInfo_II;
import tunnel.design.DesignInfo_III;
import tunnel.design.DesignInfo_IV;
import tunnel.design.DesignInfo_V;
import tunnel.design.DesignInfo_V_plus;
import tunnel.update.UpdateAppHttpUtil;
import tunnel.update.UpdateHelper;

import com.beardedhen.androidbootstrap.BootstrapButton;

public class HomeActivity extends FragmentActivity implements ViewPager.OnPageChangeListener{

	BootstrapButton btnV_;
	BootstrapButton btnV;
	BootstrapButton btnIV;
	BootstrapButton btnIII;
	BootstrapButton btnII;
	BootstrapButton btnApply;
	Spinner spnPlace;
	RadioButton btnHome;
	RadioButton btnLocal;
	RadioButton btnUpload;
	RadioButton btnMe;
	private List<CharSequence> posList = null;
	ArrayAdapter<CharSequence> posAdapter = null;
	DBOpenHelper dbHelper = new DBOpenHelper(HomeActivity.this);
    String footage_id = null;
    //保存用户曾经点击的负责隧道
	String place;
	
	/*
	 * 添加轮播图
	 */
	private ViewPager viewPager;
    private int[] imageResIds;
    private ArrayList<ImageView> imageViewList;
    private LinearLayout ll_point_container;
    private String[] contentDescs;
    private TextView tv_desc;
    private int previousSelectedPosition = 0;
    boolean isRunning = false;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_home);
		
		btnV_ = (BootstrapButton) findViewById(R.id.btnV_);
		btnV = (BootstrapButton) findViewById(R.id.btnV);
		btnIV = (BootstrapButton) findViewById(R.id.btnIV);
		btnIII = (BootstrapButton) findViewById(R.id.btnIII);
		btnII = (BootstrapButton) findViewById(R.id.btnII);
		btnApply = (BootstrapButton) findViewById(R.id.btnApply);
		spnPlace = (Spinner) findViewById(R.id.spnPlace);
		btnHome = (RadioButton) findViewById(R.id.radio_button0);
		btnLocal = (RadioButton) findViewById(R.id.radio_button1);
		btnUpload = (RadioButton) findViewById(R.id.radio_button2);
		btnMe = (RadioButton) findViewById(R.id.radio_button3);
		
		SharedPreferences sp = getSharedPreferences("data", Context.MODE_PRIVATE);
		String user_id = sp.getString("user_id", "");
		place = sp.getString("place", "");

		DutyImp dutyImp = new DutyImp(HomeActivity.this);
		List<DutyData> dutyList = dutyImp.getDutyList(user_id);

		posList = new ArrayList<CharSequence>();
		if(null != place && !place.isEmpty()) {
			for(DutyData dd : dutyList) {
				if(place.equals(dd.getTunnel_id())) {
					posList.add(dd.getTunnel_id());
					break;
				}
			}
			for(DutyData dd : dutyList) {
				if(place.equals(dd.getTunnel_id())) continue;
					posList.add(dd.getTunnel_id());
			}
		} else {
			for(DutyData dd : dutyList) {
				posList.add(dd.getTunnel_id());
			}
		}

		posAdapter = new ArrayAdapter<CharSequence>(this,android.R.layout.simple_spinner_item,posList);
		posAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		spnPlace.setAdapter(posAdapter);

		spnPlace.setOnItemSelectedListener(new OnItemSelectedListener() {
		    public void onItemSelected(AdapterView<?> parent, View view,
		            int position, long id) {
		        String str=parent.getItemAtPosition(position).toString();
		        SharedPreferences sp = getSharedPreferences("data", Context.MODE_PRIVATE);
		        SharedPreferences.Editor editor = sp.edit();
		        editor.putString("place", str);
		        editor.commit();
		        Toast.makeText(HomeActivity.this, "你点击的是:"+str, 2000).show();
		    }
		    public void onNothingSelected(AdapterView<?> parent) {
		        // TODO Auto-generated method stub
		    }
		});

		btnLocal.setOnClickListener(new View.OnClickListener() {
			
			public void onClick(View v) {
				Intent intent = new Intent(HomeActivity.this, LocalActivity.class);
				startActivity(intent);
			}
		});
		btnUpload.setOnClickListener(new View.OnClickListener() {
			
			public void onClick(View v) {
				Intent intent = new Intent(HomeActivity.this, NoUploadActivity.class);
				startActivity(intent);
			}
		});
		btnMe.setOnClickListener(new View.OnClickListener() {
			
			public void onClick(View v) {
				Intent intent = new Intent(HomeActivity.this, MeActivity.class);
				startActivity(intent);
			}
		});
		
		btnV_.setOnClickListener(new View.OnClickListener() {
			
			public void onClick(View v) {
				// V+ 按钮被选中
				Intent intent = new Intent(HomeActivity.this, VActivity.class);
				intent.putExtra("tunnel", ProcessConst.V_PLUS_ROCK_GRADE);
				intent.putExtra("rock_grade", ProcessConst.V_PLUS_ROCK_GRADE);
                intent.putExtra("footage_id", footage_id);

				// 设置按钮路径-- Level_0
				ActivityRunningConfig.getInstance().setButtonPathLevel_0(DesignInfo_V_plus.class.toString());
				ActivityRunningConfig.getInstance().setDesignInfo(new DesignInfo_V_plus());

				startActivity(intent);
			}
		});

		btnV.setOnClickListener(new View.OnClickListener() {

			public void onClick(View v) {
				// V 按钮被选中
				Intent intent = new Intent(HomeActivity.this, VActivity.class);
				intent.putExtra("tunnel", ProcessConst.V_ROCK_GRADE);
				intent.putExtra("rock_grade", ProcessConst.V_ROCK_GRADE);
                intent.putExtra("footage_id", footage_id);

				// 设置按钮路径-- Level_0
				ActivityRunningConfig.getInstance().setButtonPathLevel_0(DesignInfo_V.class.toString());
				ActivityRunningConfig.getInstance().setDesignInfo(new DesignInfo_V());

				startActivity(intent);
			}
		});
		
		btnIV.setOnClickListener(new View.OnClickListener() {

			public void onClick(View v) {
				// IV 按钮被选中
				Intent intent = new Intent(HomeActivity.this, IVActivity.class);
				intent.putExtra("tunnel", ProcessConst.IV_ROCK_GRADE);
				intent.putExtra("rock_grade", ProcessConst.IV_ROCK_GRADE);
                intent.putExtra("footage_id", footage_id);

				// 设置按钮路径-- Level_0
				ActivityRunningConfig.getInstance().setButtonPathLevel_0(DesignInfo_IV.class.toString());
				ActivityRunningConfig.getInstance().setDesignInfo(new DesignInfo_IV());

				startActivity(intent);
			}
		});
	
		btnIII.setOnClickListener(new View.OnClickListener() {

			public void onClick(View v) {
				// III 按钮被选中
				Intent intent = new Intent(HomeActivity.this, IIIActivity.class);
				intent.putExtra("tunnel", ProcessConst.III_ROCK_GRADE);
				intent.putExtra("rock_grade", ProcessConst.III_ROCK_GRADE);
                intent.putExtra("footage_id", footage_id);

				// 设置按钮路径-- Level_0
				ActivityRunningConfig.getInstance().setButtonPathLevel_0(DesignInfo_III.class.toString());
				ActivityRunningConfig.getInstance().setDesignInfo(new DesignInfo_III());

				startActivity(intent);
			}
		});
		
		btnII.setOnClickListener(new View.OnClickListener() {

			public void onClick(View v) {
				// II 按钮被选中
				Intent intent = new Intent(HomeActivity.this, IIActivity.class);
				intent.putExtra("tunnel", ProcessConst.II_ROCK_GRADE);
				intent.putExtra("rock_grade", ProcessConst.II_ROCK_GRADE);
                intent.putExtra("footage_id", footage_id);

				// 设置按钮路径-- Level_0
				ActivityRunningConfig.getInstance().setButtonPathLevel_0(DesignInfo_II.class.toString());
				ActivityRunningConfig.getInstance().setDesignInfo(new DesignInfo_II());

				startActivity(intent);
			}
		});

		btnApply.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent intent = new Intent(HomeActivity.this, RockChangeActivity.class);

				// 通过rock_grade/subprocess 传递主流程=掌子面, 子流程=围岩变更
				intent.putExtra("rock_grade", ProcessConst.ZHANG_ZI_MIAN);
				intent.putExtra("subprocess", ProcessConst.SUB_WEI_YAN_BIAN_GENG);

				intent.putExtra("process", ProcessConst.SUB_WEI_YAN_BIAN_GENG);

				startActivity(intent);
			}
		});
		
		/*
		 * 轮播图
		 */
		// 初始化布局 View视图
        initViews();
 
        // Model数据
        initData();
 
        // Controller 控制器
        initAdapter();
 
        // 开启轮询
        new Thread() {
            public void run() {
                isRunning = true;
                while (isRunning) {
                    try {
                        Thread.sleep(2000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    // 往下跳一位
                    runOnUiThread(new Runnable() {
 
                        @Override
                        public void run() {
                            System.out.println("设置当前位置: " + viewPager.getCurrentItem());
                            viewPager.setCurrentItem(viewPager.getCurrentItem() + 1);
                        }
                    });
                }
            }
 
            ;
        }.start();


		checkUpdate();
	}


//    {
//        "update": "Yes",
//            "new_version": "2.0",
//            "apk_file_url": "http://192.168.1.4:8080/app.20190518.apk",
//            "update_log": "test",
//            "target_size": "5M",
//            "new_md5":"A818AD325EACC199BC62C552A32C35F2",
//            "constraint": false
//    }
//	String mUpdateUrl = "http://192.168.1.4:8080/update.jsp";
    String mUpdateUrl = "http://121.43.185.110:8080/appupdate/update.jsp";

	private void checkUpdate() {
		UpdateHelper updater = new UpdateHelper(HomeActivity.this);
		updater.checkUpdate();
	}

	@Override
    protected void onDestroy() {
        super.onDestroy();
        isRunning = false;
    }
 
    private void initViews() {
        viewPager = (ViewPager) findViewById(R.id.viewpager);
        viewPager.setOnPageChangeListener(this);// 设置页面更新监听
//		viewPager.setOffscreenPageLimit(1);// 左右各保留几个对象
        ll_point_container = (LinearLayout) findViewById(R.id.ll_point_container);
 
        tv_desc = (TextView) findViewById(R.id.tv_desc);
 
    }
 
    /**
     * 初始化要显示的数据
     */
    private void initData() {
        // 图片资源id数组
        imageResIds = new int[]{R.drawable.a, R.drawable.b, R.drawable.c, R.drawable.d, R.drawable.e};
 
        // 文本描述
        contentDescs = new String[]{
                "",
                "",
                "",
                "",
                ""
        };
 
        // 初始化要展示的5个ImageView
        imageViewList = new ArrayList<ImageView>();
 
        ImageView imageView;
        View pointView;
        LinearLayout.LayoutParams layoutParams;
        for (int i = 0; i < imageResIds.length; i++) {
            // 初始化要显示的图片对象
            imageView = new ImageView(this);
            imageView.setBackgroundResource(imageResIds[i]);
            imageViewList.add(imageView);
 
            // 加小白点, 指示器
            pointView = new View(this);
            pointView.setBackgroundResource(R.drawable.selector_bg_point);
            layoutParams = new LinearLayout.LayoutParams(5, 5);
            if (i != 0)
                layoutParams.leftMargin = 10;
            // 设置默认所有都不可用
            pointView.setEnabled(false);
            ll_point_container.addView(pointView, layoutParams);
        }
    }
 
    private void initAdapter() {
        ll_point_container.getChildAt(0).setEnabled(true);
        tv_desc.setText(contentDescs[0]);
        previousSelectedPosition = 0;
 
        // 设置适配器
        viewPager.setAdapter(new MyAdapter());
 
        // 默认设置到中间的某个位置
        int pos = Integer.MAX_VALUE / 2 - (Integer.MAX_VALUE / 2 % imageViewList.size());
        // 2147483647 / 2 = 1073741823 - (1073741823 % 5)
        viewPager.setCurrentItem(5000000); // 设置到某个位置
    }
 
    class MyAdapter extends PagerAdapter {
 
        @Override
        public int getCount() {
            return Integer.MAX_VALUE;
        }
 
        // 3. 指定复用的判断逻辑, 固定写法
        @Override
        public boolean isViewFromObject(View view, Object object) {
//			System.out.println("isViewFromObject: "+(view == object));
            // 当划到新的条目, 又返回来, view是否可以被复用.
            // 返回判断规则
            return view == object;
        }
 
        // 1. 返回要显示的条目内容, 创建条目
        @Override
        public Object instantiateItem(ViewGroup container, int position) {
            System.out.println("instantiateItem初始化: " + position);
            // container: 容器: ViewPager
            // position: 当前要显示条目的位置 0 -> 4
 
//			newPosition = position % 5
            int newPosition = position % imageViewList.size();
 
            ImageView imageView = imageViewList.get(newPosition);
            // a. 把View对象添加到container中
            container.addView(imageView);
            // b. 把View对象返回给框架, 适配器
            return imageView; // 必须重写, 否则报异常
        }
 
        // 2. 销毁条目
        @Override
        public void destroyItem(ViewGroup container, int position, Object object) {
            // object 要销毁的对象
            System.out.println("destroyItem销毁: " + position);
            container.removeView((View) object);
        }
    }
 
    @Override
    public void onPageScrolled(int position, float positionOffset,
                               int positionOffsetPixels) {
        // 滚动时调用
    }
 
    @Override
    public void onPageSelected(int position) {
        // 新的条目被选中时调用
        System.out.println("onPageSelected: " + position);
        int newPosition = position % imageViewList.size();
 
        //设置文本
        tv_desc.setText(contentDescs[newPosition]);
 
//		for (int i = 0; i < ll_point_container.getChildCount(); i++) {
//			View childAt = ll_point_container.getChildAt(position);
//			childAt.setEnabled(position == i);
//		}
        // 把之前的禁用, 把最新的启用, 更新指示器
        ll_point_container.getChildAt(previousSelectedPosition).setEnabled(false);
        ll_point_container.getChildAt(newPosition).setEnabled(true);
 
        // 记录之前的位置
        previousSelectedPosition = newPosition;
 
    }
 
    @Override
    public void onPageScrollStateChanged(int state) {
        // 滚动状态变化时调用
    }

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.home, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}

}
