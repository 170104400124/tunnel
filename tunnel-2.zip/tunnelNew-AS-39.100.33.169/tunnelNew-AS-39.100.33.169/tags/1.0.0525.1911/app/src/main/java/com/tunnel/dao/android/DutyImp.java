package com.tunnel.dao.android;

import android.content.Context;

import com.tunnel.model.DutyData;
import com.tunnel.model.ProcessData;

import java.util.List;

/**
 * Created by Leon on 2019/5/6.
 */

public class DutyImp {


    Context context = null;
    public DutyImp(Context context) {
        this.context = context;
    }

    public List<DutyData> getDutyList(String userId) {
        String sql = "select * from duty where user_id = '" + userId + "'";
        List<DutyData> list = AndroidUtils.query2JavaBeans(sql, context, DutyData.class);

        return list;
    }

}
