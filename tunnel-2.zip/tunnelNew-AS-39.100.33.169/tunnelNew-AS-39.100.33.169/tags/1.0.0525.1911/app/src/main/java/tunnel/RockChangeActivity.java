package tunnel;

import com.beardedhen.androidbootstrap.BootstrapButton;
import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;

import com.jie.cameraimage.BuildConfig;
import com.jie.cameraimage.R;
import com.tunnel.dao.android.DutyImp;
import com.tunnel.dao.android.LogImp;
import com.tunnel.dao.android.PictureImp;
import com.tunnel.dao.android.ProcessConst;
import com.tunnel.model.DutyData;
import com.tunnel.model.LogData;
import com.tunnel.model.PictureData;
import com.tunnel.model.ProcessData;

import tunnel.JDBC.DBOpenHelper;
import tunnel.adapter.MainGridViewAdapter;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.AssetManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.provider.MediaStore;
import android.support.v4.app.ActivityCompat;
import android.text.Editable;
import android.text.TextWatcher;
import android.text.format.Time;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.AdapterView.OnItemLongClickListener;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import net.tsz.afinal.FinalHttp;
import net.tsz.afinal.http.AjaxCallBack;
import net.tsz.afinal.http.AjaxParams;

import tunnel.design.ActivityRunningConfig;
import tunnel.model.Const;
import tunnel.model.ImageModel;
import tunnel.pic.CameraUtils;
import tunnel.pic.PermissionUtil;
import tunnel.pic.PicHelper;
import tunnel.service.NetWorkTask;
import tunnel.service.UploadUtil;
import tunnel.design.DesignInfo;
import tunnel.design.DesignInfo_V_plus;
import tunnel.design.ReflectUtil;
import tunnel.model.Const;
import tunnel.model.ImageModel;
import tunnel.service.NetWorkTask;
/**
 * @ClassName: MainActivity
 * @Description: 程序主Activity
 * @Date 2016年10月28日
 * @author jie
 */
public class RockChangeActivity extends Activity implements Const, OnClickListener, OnItemClickListener, OnItemLongClickListener {

	private TextView countTextView;
	private EditText inputEditText;
	private GridView imageGridView;

	private TextView place;
	private BootstrapButton saveLocal;
	private BootstrapButton uploadServer;
	private ImageView showImg;
	//	private EditText txOffset;
	private String offset;
	private TextView V_maoganDemand;
	private String remarks;
	private String tunnelName;
	private String tunnelId;
	private String processName;
	private String processId;

	private String savetime;
	private String uploadtime;
	private TextView demand;
	// 外观照片提示
	private TextView V_outlook;
	private TextView tvPlace;
	private TextView tvProcess;

	private List<ImageModel> imageList;
	private MainGridViewAdapter adapter;
	private List<CharSequence> posList = null;
	ArrayAdapter<CharSequence> posAdapter = null;
	private Spinner oldRock;
	private Spinner newRock;

	private Intent intent; // 页面跳转（拍照，相册选图）
	private String photoFileName; // 图片文件名
	private String photoAbsolutePath; // 图片存储的绝对路径
	private String local_explanation;//本地记录传来的备注
	private String firstKey;//本地记录传来的照片的key值
	private String local_old_rock;
	private String local_new_rock;
	private boolean isSave;//判断是否保存过本地
	private String[] localPhotos = new String[20];//保存初始照片的id
	private int count;//计算初始照片的数量

	private Button delete3;

    private ImageView imageView;//点击查看大图

	private Context context;
	String path;
	String key;
	DBOpenHelper dbHelper = new DBOpenHelper(RockChangeActivity.this);

	String user_id;
	String rock_grade = null;
	String subprocess = null;
	ProcessData pd = null;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_rock_change);
		imageList = new ArrayList<ImageModel>();
		Intent intent = getIntent();
		tunnelName = intent.getStringExtra("tunnel");
		processName = intent.getStringExtra("process");

		rock_grade = intent.getStringExtra("rock_grade");
		subprocess = intent.getStringExtra("subprocess");
//		ProcessConst pc = new ProcessConst();
//		pd = pc.getProcessData(rock_grade, subprocess);
		//获取本地记录传来的信息
		local_explanation = intent.getStringExtra("explanation");
		firstKey = intent.getStringExtra("key");
		local_old_rock = intent.getStringExtra("old_rock");
		local_new_rock = intent.getStringExtra("new_rock");

		ProcessConst pc = new ProcessConst();
		pd = pc.getProcessData(rock_grade, subprocess);

		processId = pd.getProcess_id();

		Toast.makeText(this, processId, Toast.LENGTH_SHORT).show();
		initView();
		initData();
	}

	private void initView() {
//		findViewById(R.id.main_update_textView).setOnClickListener(this);
		findViewById(R.id.saveLocal).setOnClickListener(this);
		findViewById(R.id.uploadServer).setOnClickListener(this);
		findViewById(R.id.back).setOnClickListener(this);
		findViewById(R.id.delete).setOnClickListener(this);
		countTextView = (TextView) findViewById(R.id.main_count_textView);
		inputEditText = (EditText) findViewById(R.id.main_input_editText);
		V_maoganDemand = (TextView) findViewById(R.id.V_maoganDemand);
		inputEditText.addTextChangedListener(watcher);
		imageGridView = (GridView) findViewById(R.id.main_data_gridView);
		imageGridView.setOnItemClickListener(this);
		imageGridView.setOnItemLongClickListener(this);
		demand = (TextView) findViewById(R.id.V_txDemand);
		place = (TextView) findViewById(R.id.V_txPlace);
//		txOffset = (EditText) findViewById(R.id.txOffset);
		findViewById(R.id.radio_button0).setOnClickListener(this);
		findViewById(R.id.radio_button1).setOnClickListener(this);
		findViewById(R.id.radio_button2).setOnClickListener(this);
		findViewById(R.id.radio_button3).setOnClickListener(this);

        imageView = (ImageView) findViewById(R.id.rock_large_image);
        imageView.setVisibility(View.INVISIBLE);

		oldRock = (Spinner) findViewById(R.id.spnOldRock);
		newRock = (Spinner) findViewById(R.id.spnNewRock);

		saveLocal = (BootstrapButton) findViewById(R.id.saveLocal);
		uploadServer = (BootstrapButton) findViewById(R.id.uploadServer);

//		// 给定设计要求级别，给定字段名，就能提取对应的设计要求
//		String diJson = getIntent().getStringExtra("design_info");
//		Gson gson = new Gson();
//		DesignInfo di = gson.fromJson(diJson, DesignInfo.class);

		DesignInfo di = ActivityRunningConfig.getInstance().getDesignInfo();
		String level_0 = ActivityRunningConfig.getInstance().getButtonPathLevel_0();
		String level_1 = ActivityRunningConfig.getInstance().getButtonPathLevel_1();

		V_outlook = (TextView) findViewById(R.id.main_grid_showimage_label);
		V_outlook.setText("外观照片");
		tvPlace = (TextView) findViewById(R.id.place);
		tvProcess = (TextView) findViewById(R.id.editText2);
	}

	private void initData() {
		SharedPreferences sp = getSharedPreferences("data", Context.MODE_PRIVATE);
		user_id = sp.getString("user_id", "");
		String strPlace = sp.getString("place", "");
		key = user_id;
		tunnelId = strPlace;

		if(null != firstKey && !firstKey.isEmpty()) {
			isSave = true;
			SQLiteDatabase db = dbHelper.getReadableDatabase();
			Cursor cursor = db.rawQuery("select distinct address from picture where key = ?",new String[]{firstKey});
			count = 0;
			while (cursor.moveToNext()) {
				ImageModel imageModel = new ImageModel();
				int nameColumnIndex = cursor.getColumnIndex("address");
				String address = cursor.getString(nameColumnIndex);
				imageModel.setImagePath(address);
				localPhotos[count++] = address;
				imageList.add(imageModel);
			}
		}
		ImageModel imageModel = new ImageModel();
		imageModel.setSpareImage(R.drawable.addimage);
		imageList.add(imageModel);
		adapter = new MainGridViewAdapter(imageList, this, View.GONE);
		imageGridView.setAdapter(adapter);

		tvPlace.setText(strPlace);
//		tvProcess.setText(processName);
		if(null != local_explanation && !local_explanation.isEmpty()) {
			inputEditText.setText(local_explanation);
		}
		Toast.makeText(this, local_old_rock, Toast.LENGTH_SHORT).show();
		Toast.makeText(this, local_new_rock, Toast.LENGTH_SHORT).show();
		if(null != local_old_rock && !local_old_rock.isEmpty()) {
			if(local_old_rock.equals("V+")) oldRock.setSelection(0,true);
			else if(local_old_rock.equals("V")) oldRock.setSelection(1,true);
			else if(local_old_rock.equals("IV")) oldRock.setSelection(2,true);
			else if(local_old_rock.equals("III")) oldRock.setSelection(3,true);
			else if(local_old_rock.equals("II")) oldRock.setSelection(4,true);
		}

		if(null != local_new_rock && !local_new_rock.isEmpty()) {
			if(local_new_rock.equals("V+")) newRock.setSelection(0,true);
			else if(local_new_rock.equals("V")) newRock.setSelection(1,true);
			else if(local_new_rock.equals("IV")) newRock.setSelection(2,true);
			else if(local_new_rock.equals("III")) newRock.setSelection(3,true);
			else if(local_new_rock.equals("II")) newRock.setSelection(4,true);
		}


		oldRock.setOnItemSelectedListener(new OnItemSelectedListener() {
			@Override
			public void onNothingSelected(AdapterView<?> parent) {
				// TODO Auto-generated method stub
			}
			@Override
			public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
				//拿到被选择项的值
				//pos = (String) spnposition.getSelectedItem();
				String rock=parent.getItemAtPosition(position).toString();
				Toast.makeText(RockChangeActivity.this, "原设计围岩等级" + rock, Toast.LENGTH_SHORT).show();
			}
		});

		newRock.setOnItemSelectedListener(new OnItemSelectedListener() {
			@Override
			public void onNothingSelected(AdapterView<?> parent) {
				// TODO Auto-generated method stub
			}
			@Override
			public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
				//拿到被选择项的值
				//pos = (String) spnposition.getSelectedItem();
				String rock=parent.getItemAtPosition(position).toString();
				Toast.makeText(RockChangeActivity.this, "变更围岩等级" + rock, Toast.LENGTH_SHORT).show();
			}
		});
	}

	@Override
	public void onClick(View view) {
		switch (view.getId()) {
//		case R.id.main_update_textView:
//			// TODO --------- File Upload Start ---------
//			FinalHttp finalHttp = new FinalHttp();
//			AjaxParams params = new AjaxParams();
//			try {
//				for (int i = 0; i < imageList.size(); i++) {
//					params.put("profile_picture" + i, new File(imageList.get(i).getImagePath()));
//				}
//				params.put("picture_count", imageList.size() + "");
//			} catch (FileNotFoundException e) {
//				e.printStackTrace();
//			}
//
//			finalHttp.post("www.webURL.com/...", params, new AjaxCallBack<Object>() {
//				@Override
//				public void onSuccess(Object t) {
//					// TODO 上传文件成功候处理事件
//					super.onSuccess(t);
//				}
//				@Override
//				public void onFailure(Throwable t, int errorNo, String strMsg) {
//					// TODO 上传失败时所作的逻辑处理
//					super.onFailure(t, errorNo, strMsg);
//				}
//			});
//			// TODO --------- File Upload End ---------
//			Toast.makeText(this, "发表功能按需完善！", Toast.LENGTH_SHORT).show();
//			break;
//
			case R.id.saveLocal:
				saveImage();
				break;
			case R.id.uploadServer:
				uploadImage();
				break;
			case R.id.radio_button0:
				Intent intent = new Intent(RockChangeActivity.this, HomeActivity.class);
				startActivity(intent);
				break;
			case R.id.radio_button1:
				Intent intent1 = new Intent(RockChangeActivity.this, LocalActivity.class);
				startActivity(intent1);
				break;
			case R.id.radio_button2:
				Intent intent2 = new Intent(RockChangeActivity.this, NoUploadActivity.class);
				startActivity(intent2);
				break;
			case R.id.radio_button3:
				Intent intent3 = new Intent(RockChangeActivity.this, MeActivity.class);
				startActivity(intent3);
				break;
			case R.id.back:
				RockChangeActivity.this.finish();
				break;
			case R.id.delete:
				delete();
				break;
		}
	}


	@Override
	public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
		// 获取点击的对象
		ImageModel imageModel = imageList.get(position);
		String pathStr = imageModel.getImagePath();
		int spareImage = imageModel.getSpareImage();

        if(!pathStr.equals("")) {
            Bitmap bitmap = BitmapFactory.decodeFile(pathStr);//从路径加载出图片bitmap
            imageView.setVisibility(View.VISIBLE);
            imageView.setImageBitmap(bitmap);//ImageView显示图片
            imageView.setOnClickListener(
                    new OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            view.setVisibility(View.INVISIBLE);
                        }
                    });
        }

		if (pathStr.equals("") && spareImage != 0) { // 点击的是添加照片的对象
			final String[] items = { "拍照", "相册选择(单选)", "相册选择(多选)" };
			new AlertDialog.Builder(this)
					.setTitle("请选择获取图片方式")
					.setItems(items, new DialogInterface.OnClickListener() {
						@Override
						public void onClick(DialogInterface dialog, int which) {

							imageList.remove(imageList.size() - 1); // 现将加号移除（有加号才能显示此按钮）

							switch (which) {
								case 0:
									// 调用相机拍照并保存拍照文件到指定目录
									callCameraTakePhoto();
									break;
								case 1:
									// 图片单选，直接跳转至系统图片库
									intent = new Intent(Intent.ACTION_PICK, android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
									startActivityForResult(intent, SELECTIMAGE_ONE);
									break;
								case 2:
									// 移除加号，剩下的路径传至第二界面
									// 跳转至图片多选页面SelectMoreImageActivity
									intent = new Intent(RockChangeActivity.this, SelectMoreImageActivity.class);
									// 设置传递参数
									ArrayList<String> photoArrayList = new ArrayList<String>();
									for (ImageModel imageModel : imageList) {
										photoArrayList.add(imageModel.getImagePath());
									}
									intent.putExtra("imageCount", photoArrayList.size()); // 当前已选择的数量
									intent.putStringArrayListExtra("photoArrayList", photoArrayList); // 当前已选择的路径
									startActivityForResult(intent, SELECTIMAGE_MORE); // 跳转到第二个页面
									break;
							}
						}
					})
					.setNegativeButton("取消", new DialogInterface.OnClickListener() {
						@Override
						public void onClick(DialogInterface dialog, int which) {
							dialog.dismiss();
						}
					}).show();
		}
	}

	/**
	 * 调用相机拍照并存储照片
	 */
	private void callCameraTakePhoto() {
		// 启动相机并拍照
		jump2Camera();
	}

	private PermissionUtil permissionUtil = new PermissionUtil();

	public void jump2Camera() {
		if (permissionUtil.checkMarshMellowPermission()) {
			if (permissionUtil.verifyPermissions(RockChangeActivity.this, permissionUtil.getCameraPermissions())) {
				CameraUtils.takePhoto(RockChangeActivity.this, BuildConfig.APPLICATION_ID, CALL_CAMERA);
			} else{
				ActivityCompat.requestPermissions(RockChangeActivity.this, permissionUtil.getCameraPermissions(), CALL_CAMERA);
			}
		} else {
			CameraUtils.takePhoto(RockChangeActivity.this, BuildConfig.APPLICATION_ID, CALL_CAMERA);
//				PicFileUtils.startActionCapture(this,file,CALL_CAMERA);
		}
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		super.onActivityResult(requestCode, resultCode, data);
		if (resultCode == Activity.RESULT_OK) {
			switch (requestCode) {
				case CALL_CAMERA:
					photoAbsolutePath = CameraUtils.photoFile.getAbsolutePath();
					Activity ac = RockChangeActivity.this;

					PicHelper helper = new PicHelper();
					// 带时间戳的完整图片
					List<String> waterMark = new ArrayList<String>();
					String dateTime = helper.getDateTime();
					waterMark.add(dateTime);
					waterMark.add(tunnelId);
					//				waterMark.add(rock_grade+"|"+tvProcess.getText().toString());
					waterMark.add(user_id);

					String tsPicFullPath = helper.addTimestamp2Photo(data, ac, photoAbsolutePath, waterMark);
				{
					ImageModel imageModel = new ImageModel();
					imageModel.setImagePath(tsPicFullPath);
					imageList.add(imageModel);
				}
				break;
				case SELECTIMAGE_ONE:
					// 调用系统图库单选
					// 思路：将加号移除--调用图库选图片--获取回文数据--将回文数据添加至集合--在onRestart中判断是否添加加号并刷新adapter
					if (data != null) {
						// 获取相册选择结果（保存路径）

						Uri selectedImage = data.getData();
						String[] filePathColumn = { MediaStore.Images.Media.DATA };
						Cursor cursor = getContentResolver().query(selectedImage, filePathColumn, null, null, null);
						cursor.moveToFirst();

						int columnIndex = cursor.getColumnIndex(filePathColumn[0]);
						final String picturePath = cursor.getString(columnIndex);

						// 创建对象并添加至集合
						ImageModel imageModel = new ImageModel();
						imageModel.setImagePath(picturePath);
						imageList.add(imageModel);

						//saveImage(picturePath);
					}
					break;
				case SELECTIMAGE_MORE:
					// 调用图库多选
					// 思路：先将加号移除--调用图库选图片--获取回文数据--将回文数据添加至集合--在onRestart中判断是否添加加号并刷新adapter
					if (data != null) {
						// 如果回文不为空，获取回传的List值
						ArrayList<String> returnPathList = data.getStringArrayListExtra("returnPathList");
						imageList.removeAll(imageList); // 清空当前显示的List

						// 创建对象并添加至本界面的List集合
						ImageModel imageModel;
						for (String string : returnPathList) {
							imageModel = new ImageModel();
							imageModel.setImagePath(string);
							imageList.add(imageModel);
						}

					} else {
						Toast.makeText(this, "data为空！", Toast.LENGTH_SHORT).show();
						ImageModel model = new ImageModel();
						model.setSpareImage(R.drawable.addimage);
						imageList.add(model);
						adapter.notifyDataSetChanged(); // 通知adapter刷新
					}
					break;
			}
		}
	}

	@Override
	public boolean onItemLongClick(AdapterView<?> parent, View view, final int position, long id) {
		ImageModel imageModel = imageList.get(position);
		String pathStr = imageModel.getImagePath();
		int spareImage = imageModel.getSpareImage();
		if (!pathStr.equals("") && spareImage == 0) {
			// 图片（非添加标志图）长按事件处理
			new AlertDialog.Builder(this).setTitle("操作提示")
					.setMessage("长按删除该图片（原相册中的图片不会删除），是否删除？")
					.setPositiveButton("删除", new DialogInterface.OnClickListener() {
						@Override
						public void onClick(DialogInterface dialog, int which) {
							for (int i = 0; i < imageList.size(); i++) {
								String pathStr = imageList.get(i).getImagePath();
								if (!pathStr.equals("") && i == imageList.size() - 1) {
									ImageModel imageModel = new ImageModel();
									imageModel.setSpareImage(R.drawable.addimage);
									imageList.add(imageModel);
								}
							}
							imageList.remove(position);
							adapter.notifyDataSetChanged();
						}
					})
					.setNegativeButton("取消", null).show();
		} else {
			Toast.makeText(this, "点选的是添加图片", Toast.LENGTH_SHORT).show();
		}
		return true;
	}

	/**
	 * 监控文字变化
	 */
	TextWatcher watcher = new TextWatcher() {
		@Override
		public void onTextChanged(CharSequence s, int start, int before, int count) {
		}
		@Override
		public void beforeTextChanged(CharSequence s, int start, int count, int after) {
		}
		@Override
		public void afterTextChanged(Editable s) {
			// 输入时提示剩余可输入字符长度
			countTextView.setText(500 - inputEditText.getText().toString().length() + "");
		}
	};

	@Override
	protected void onRestart() {
		super.onRestart();
		// 如果list元素数量没到上传最大值，则添加加号图片
		// 刷新adapter写与此主要防止用户直接按返回键，导致加号显示与否无法判断
		if (imageList.size() < MAX_IMAGECOUNT) {
			ImageModel model = new ImageModel();
			model.setSpareImage(R.drawable.addimage);
			imageList.add(model);
		}
		adapter.notifyDataSetChanged(); // 通知adapter刷新
	}

	public void saveImage(){
		//获取当前时间
		Date currentDate = new Date();
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");// HH:mm:ss

		savetime = simpleDateFormat.format(currentDate);
		//offset = txOffset.getText().toString().trim();
		remarks = inputEditText.getText().toString().trim();
		String url = null;
		//插入Log表的信息
		LogData logData = new LogData();
		logData.setExplanation(remarks);
		logData.setUser_id(user_id);
		//logData.setTunnel_id(tunnelName);
		logData.setTunnel_id(tunnelId);
		logData.setProcess_id(pd.getProcess_id());
		logData.setSave_time(currentDate);
		logData.setOldRock(oldRock.getSelectedItem().toString());
		logData.setNewRock(newRock.getSelectedItem().toString());
		key = user_id + savetime;
		//      logData.setReport_footage(offset);
		logData.setIsUpload(0);
		//判断是否上传过
		if(null != firstKey && !firstKey.isEmpty()) {
			SQLiteDatabase db = dbHelper.getWritableDatabase();
			String sql = "select * from log where isUpload=? and key = ?";//从哪一个位置    请求多少条
			Cursor cursor = db.rawQuery(sql, new String[]{"1", firstKey});
			if (cursor.moveToNext()) {
				int nameColumnIndex = cursor.getColumnIndex("key");
				key = cursor.getString(nameColumnIndex);
				logData.setIsUpload(1);
			}
		}
		logData.setKey(key);
		if(!isSave) {
			new LogImp(RockChangeActivity.this).insert(logData);
			isSave = true;
			firstKey = key;
		} else {
			new LogImp(RockChangeActivity.this).update(logData, firstKey);
		}
		boolean isLocal = false;
		//循环插入图片
		for(ImageModel img : imageList){
			isLocal = false;
			url = img.getImagePath();
			for(int i = 0; i < count; i++) {
				if(localPhotos[i].equals(url)) {
					isLocal = true;
					break;
				}
			}
			if(isLocal) continue;
			if(url.equals("")) continue;
			//byte[] picture = bitmabToBytes(context, url);//图片转为二进制
			PictureData data = new PictureData();
//			if(null != firstKey && !firstKey.isEmpty()) data.setKey(firstKey);
// 			else
			data.setKey(firstKey);
			data.setAddress(url);
			//data.setPicture(picture);
			new PictureImp(RockChangeActivity.this).insert(data);
		}
		if(imageList.size() == 1) {
			Toast.makeText(this, "请先拍摄照片再保存本地", Toast.LENGTH_SHORT).show();
			return;
		}
		Toast.makeText(this, "信息已保存本地", Toast.LENGTH_SHORT).show();
	}

	//线程上传图片
	private void uploadImage() {
		Date currentDate = new Date();
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");// HH:mm:ss
		//获取当前时间
		uploadtime = simpleDateFormat.format(currentDate);
		String isUpload = "1";
		if(key.equals(user_id)) {
			Toast.makeText(this, "请先将信息保存本地再上传", Toast.LENGTH_SHORT).show();
			return;
		}
		for(ImageModel img : imageList) {
			NetWorkTask networkTask = new NetWorkTask();
			String imagePath = img.getImagePath();
//        	 Log.i("start upload", "start upload");
//             Log.i("start upload_path", "imagePath" + imagePath);
//             Log.i("offset", offset);
			networkTask.setContext(RockChangeActivity.this);
			networkTask.execute(imagePath, user_id, "", tunnelName, processName, firstKey, uploadtime, isUpload ,remarks, savetime);
		}
//        if(NetWorkTask.upload.equals("1")){
//        	SQLiteDatabase db = dbHelper.getReadableDatabase(); 
//        	ContentValues cv = new ContentValues();
//         	cv.put("isUpload","1");
//         	String whereCaluse = "key=?";
//         	String whereArgs[] = new String[]{key};
//         	db.update("log", cv, whereCaluse, whereArgs);
//         	db.close() ;
//         	Toast.makeText(this, "图片上传成功", Toast.LENGTH_SHORT).show();
//        }
//        Toast.makeText(this, "上传失败", Toast.LENGTH_SHORT).show();
	}

	private void readImage(){
		byte[] imgData = null;
		Log.e("pic", "读取照片");
		SQLiteDatabase db = dbHelper.getWritableDatabase();
		String sql = "select * from tunnel, picture where tunnel.user_id=picture.key;";
		Cursor cur=db.rawQuery(sql, null);
		if(cur.moveToFirst()){
			//将Blob数据转化为字节数组
			imgData=cur.getBlob(cur.getColumnIndex("picture"));
		}

		if (imgData!=null) {
			//将字节数组转化为位图
			Bitmap imagebitmap = BitmapFactory.decodeByteArray(imgData, 0, imgData.length);
			//将位图显示为图片
			//showImg.setImageBitmap(imagebitmap);
			ByteArrayInputStream stream = new ByteArrayInputStream(imgData);
			showImg.setImageDrawable(Drawable.createFromStream(stream, "img"));
		}else {
			showImg.setBackgroundResource(android.R.drawable.menuitem_background);
		}

	}

	//图片转为二进制数据
	public byte[] bitmabToBytes(Context context, String url){
		//将图片转化为位图
		Bitmap bitmap = BitmapFactory.decodeFile(url);
		int size = bitmap.getWidth() * bitmap.getHeight() * 4;
		ByteArrayOutputStream baos=new ByteArrayOutputStream(size);
		//设置位图的压缩格式，质量为100%，并放入字节数组输出流中
		int options = 100;
		/* options表示 如果不压缩是100，表示压缩率为0。如果是70，就表示压缩率是70，表示压缩30%; */
		bitmap.compress(Bitmap.CompressFormat.JPEG, 30, baos);
//       while(baos.toByteArray().length / 1024 > 100) {
//    	   // 循环判断如果压缩后图片是否大于100kb继续压缩
//           baos.reset();
//           options -= 10;
//           // 这里压缩options%，把压缩后的数据存放到baos中
//           bitmap.compress(Bitmap.CompressFormat.JPEG, options, baos);
//       }
		//将字节数组输出流转化为字节数组byte[]
		byte[] imagedata=baos.toByteArray();
		return imagedata;
	}

	//删除此条记录
	public void delete() {
		if(null == firstKey ||  firstKey.equals("")) {
			Toast.makeText(this, "该记录未保存，无法删除", Toast.LENGTH_SHORT).show();
			return;
		}
		final AlertDialog.Builder normalDialog =
				new AlertDialog.Builder(RockChangeActivity.this);
		normalDialog.setTitle("隧道施工系统");
		normalDialog.setMessage("删除本地记录（若记录已成功上传，服务器中记录不会删除），是否删除?");
		normalDialog.setPositiveButton("确定",
				new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface dialog, int which) {
						SQLiteDatabase db = dbHelper.getWritableDatabase();
						String whereCaluse = "key=?";
						String whereArgs[] = new String[]{String.valueOf(firstKey)};
						db.delete("picture",whereCaluse ,whereArgs);
						db.delete("log",whereCaluse ,whereArgs);
						Intent intent = new Intent(RockChangeActivity.this, LocalActivity.class);
						startActivityForResult(intent, 1);
					}
				});
		normalDialog.setNegativeButton("取消",
				new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface dialog, int which) {
						return;
					}
				});
		// 显示
		normalDialog.show();
	}

}
