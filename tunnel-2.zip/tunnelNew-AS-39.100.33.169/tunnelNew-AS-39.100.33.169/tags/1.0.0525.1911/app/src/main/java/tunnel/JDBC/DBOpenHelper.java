package tunnel.JDBC;

import java.util.ArrayList;
import java.util.List;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;
import tunnel.model.*;
import tunnel.service.NetWorkTask;
/**
 * 默认就在数据库里创建4张表
 * 
 *
 */
public class DBOpenHelper extends SQLiteOpenHelper {
    private static final String name = "tunnel_safety.db";//数据库名称
    private static final int version = 15;//数据库版本

    public DBOpenHelper(Context context) {
        super(context, name, null, version);
    }

	@Override
    public void onCreate(SQLiteDatabase db) {
		//Log.e("DBOpenHelper", "DBOpenHelperDBOpenHelperDBOpenHelperDBOpenHelperDBOpenHelperDBOpenHelperDBOpenHelperDBOpenHelper");
		db.execSQL("create table  adjustment_grade  ( " +
				"   tunnel_id varchar(30) , " +
				"   user_id varchar(30), " +
				"   process_id varchar(30) , " +
				"   'key'  varchar(50), " +
				"   modify_footage  varchar(30) , " +
				"   description  varchar(255)," +
				"	id Integer PRIMARY KEY  AUTOINCREMENT )"
		);
		db.execSQL("create table  design_footage  ( " +
				"   tunnel_id varchar(30) , " +
				"   tunnel_starting  varchar(20) , " +
				"   tunnel_end  varchar(20) , " +
				"   tunnel_grade  varchar(10)," +
				"	isFinish  varchar(10), " +
				"   footage_id VARCHAR(50) PRIMARY KEY )"
		);
		db.execSQL("create table  picture  ( " +
						"  'key' varchar(255) , " +
//        		"   picture blob ," +
						"	address varchar(255)," +
						"   id Integer PRIMARY KEY  AUTOINCREMENT )"
		);
		db.execSQL("create table  duty  ( " +
				"   id Integer PRIMARY KEY, " +
				"   user_id varchar(30)," +
				" 	tunnel_id varchar(11) )"
		);
		db.execSQL("create table  log  ( " +
				"   user_id  varchar(11) , " +
				"   tunnel_id  varchar(11) , " +
				"   process_id  varchar(11) , " +
				"   footage_id  varchar(11) , " +
				"   'key' varchar(255), " +
				"   zuankongLength varchar(11) ," +
				"   'offset' varchar(11) ," +
				"   report_footage varchar(11) ," +
				"   sum_footage varchar(11) ," +
				"   save_time  datetime , " +
				"   upload_time  datetime , " +
				"   explanation  varchar(255)," +
				"	isUpload integer ," +

				"	old_rock varchar(11) ," +    // 旧围岩等级
				"	new_rock varchar(11) ," +    // 新围岩等级

				" 	id Integer PRIMARY KEY  AUTOINCREMENT )"
		);
		db.execSQL("create table  process  ( " +
				" 	id Integer PRIMARY KEY  AUTOINCREMENT ," +
				"   process_id varchar(255)  , " +
				"   rock_grade  varchar(255) , " +
				"   subprocess  varchar(255) , " +
				"   lowprocess  varchar(255) , " +
				"   requirement  varchar(255) )"
		);
		db.execSQL("create table  tunnel  ( " +
						" 	id Integer PRIMARY KEY  AUTOINCREMENT ," +
						"   tunnel_id  varchar(11) , " +
//        		"   user_id  varchar(255) , " +
						"   tunnel_section  varchar(255) , " +
						"   tunnel_name  varchar(255) , " +
						"   tunnel_subface  varchar(255) , " +
//        		"   key varchar(255), " +
						"   remarks  varchar(255) )"
		);
		db.execSQL("create table  user  ( " +
				"   user_name  varchar(25) PRIMARY KEY , " +
				"   user_id  varchar(11) , " +
				"   password  varchar(25) , " +
				"   position  varchar(25), " +
				"   phone varchar(25)," +
				"   access  varchar(255) )"
		);

		//插入用户数据
		db.execSQL("INSERT INTO user VALUES ('测试一', '1', '1', '隧道长', null, null)");
		db.execSQL("INSERT INTO user VALUES ('测试二', '2', '2', '技术员', null, null)");
		db.execSQL("INSERT INTO user VALUES ('艾友兴', 'aiyouxing', 'aiyouxing', '安全员', null, null)");
		db.execSQL("INSERT INTO user VALUES ('毕建军', 'bijianjun', 'bijianjun', '安全员', null, null)");
		db.execSQL("INSERT INTO user VALUES ('陈豪', 'chenhao', 'chenhao', '质量员', null, null)");
		db.execSQL("INSERT INTO user VALUES ('丁涛', 'dingtao', 'dingtao', '技术员', null, null)");
		db.execSQL("INSERT INTO user VALUES ('葛建强', 'gejianqiang', 'gejianqiang', '安全员', null, null)");
		db.execSQL("INSERT INTO user VALUES ('郭宇轩', 'guoyuxuan', 'guoyuxuan', '隧道长', null, null)");
		db.execSQL("INSERT INTO user VALUES ('韩波', 'hanbo', 'hanbo', '隧道长', null, null)");
		db.execSQL("INSERT INTO user VALUES ('姜广荣', 'jiangguangrong', 'jiangguangrong', '质量员', null, null)");
		db.execSQL("INSERT INTO user VALUES ('李林勇', 'lilinyong', 'lilinyong', '隧道长', null, null)");
		db.execSQL("INSERT INTO user VALUES ('李沛炬', 'lipeiju', 'lipeiju', '质量员', null, null)");
		db.execSQL("INSERT INTO user VALUES ('李帅', 'lishuai', 'lishuai', '技术员', null, null)");
		db.execSQL("INSERT INTO user VALUES ('刘亮', 'liuliang', 'liuliang', '安全员', null, null)");
		db.execSQL("INSERT INTO user VALUES ('刘庆涛', 'liuqingtao', 'liuqingtao', '隧道长', null, null)");
		db.execSQL("INSERT INTO user VALUES ('刘田军', 'liutianjun', 'liutianjun', '质量员', null, null)");
		db.execSQL("INSERT INTO user VALUES ('路大刚', 'ludagang', 'ludagang', '技术员', null, null)");
		db.execSQL("INSERT INTO user VALUES ('吕建民', 'lvjianmin', 'lvjianmin', '质量员', null, null)");
		db.execSQL("INSERT INTO user VALUES ('秦宇峰', 'qinyufeng', 'qinyufeng', '安全员', null, null)");
		db.execSQL("INSERT INTO user VALUES ('盛林', 'shenglin', 'shenglin', '安全员', null, null)");
		db.execSQL("INSERT INTO user VALUES ('苏本庆', 'subenqing', 'subenqing', '隧道长', null, null)");
		db.execSQL("INSERT INTO user VALUES ('苏军', 'sujun', 'sujun', '技术员', null, null)");
		db.execSQL("INSERT INTO user VALUES ('孙继华', 'sunjihua', 'sunjihua', '安全员', null, null)");
		db.execSQL("INSERT INTO user VALUES ('孙金贵', 'sunjingui', 'sunjingui', '安全员', null, null)");
		db.execSQL("INSERT INTO user VALUES ('涂纪权', 'tujiquan', 'tujiquan', '隧道长', null, null)");
		db.execSQL("INSERT INTO user VALUES ('王圣光', 'wangshengguang', 'wangshengguang', '质量员', null, null)");
		db.execSQL("INSERT INTO user VALUES ('王学海', 'wangxuehai', 'wangxuehai', '技术员', null, null)");
		db.execSQL("INSERT INTO user VALUES ('王云涛', 'wangyuntao', 'wangyuntao', '安全员',null, null)");
		db.execSQL("INSERT INTO user VALUES ('魏银国', 'weiyinguo', 'weiyinguo', '隧道长', null, null)");
		db.execSQL("INSERT INTO user VALUES ('徐跃进', 'xuyuejin', 'xuyuejin', '质量员', null, null)");
		db.execSQL("INSERT INTO user VALUES ('余至明', 'yuzhiming', 'yuzhiming', '隧道长', null, null)");
		db.execSQL("INSERT INTO user VALUES ('曾祥明', 'zengxiangming', 'zengxiangming', '隧道长', null, null)");
		db.execSQL("INSERT INTO user VALUES ('张虎', 'zhanghu', 'zhanghu', '技术员', null, null)");
		db.execSQL("INSERT INTO user VALUES ('张雷', 'zhanglei', 'zhanglei', '隧道长', null, null)");
		db.execSQL("INSERT INTO user VALUES ('张敏', 'zhangmin', 'zhangmin', '隧道长', null, null)");
		db.execSQL("INSERT INTO user VALUES ('张宁利', 'zhangningli', 'zhangningli', '技术员', null, null)");
		db.execSQL("INSERT INTO user VALUES ('张庆', 'zhangqing', 'zhangqing', '技术员', null, null)");
		db.execSQL("INSERT INTO user VALUES ('张亚飞', 'zhangyafei', 'zhangyafei', '质量员', null, null)");
		db.execSQL("INSERT INTO user VALUES ('张旸', 'zhangyang', 'zhangyang', '安全员', null, null)");
		db.execSQL("INSERT INTO user VALUES ('赵充华', 'zhaochonghua', 'zhaochonghua', '技术员', null, null)");
		db.execSQL("INSERT INTO user VALUES ('赵军', 'zhaojun', 'zhaojun', '质量员', null, null)");
		db.execSQL("INSERT INTO user VALUES ('赵望', 'zhaowang', 'zhaowang', '技术员', null, null)");
		db.execSQL("INSERT INTO user VALUES ('赵晓雷', 'zhaoxiaolei', 'zhaoxiaolei', '技术员', null, null)");
		db.execSQL("INSERT INTO user VALUES ('朱大刚', 'zhudagang', 'zhudagang', '质量员', null, null)");

		//插入用户负责隧道数据
		db.execSQL("INSERT INTO duty VALUES (1, 'zhangmin', '柯树下隧道进口')");
		db.execSQL("INSERT INTO duty VALUES (2, 'wangyuntao', '柯树下隧道进口')");
		db.execSQL("INSERT INTO duty VALUES (3, 'liutianjun', '柯树下隧道进口')");
		db.execSQL("INSERT INTO duty VALUES (9, 'zhaowang', '柯树下隧道进口')");
		db.execSQL("INSERT INTO duty VALUES (10, 'zhangmin', '柯树下隧道出口')");
		db.execSQL("INSERT INTO duty VALUES (11, 'wangyuntao', '柯树下隧道出口')");
		db.execSQL("INSERT INTO duty VALUES (12, 'zhaojun', '柯树下隧道出口')");
		db.execSQL("INSERT INTO duty VALUES (13, 'zhaowang', '柯树下隧道出口')");
		db.execSQL("INSERT INTO duty VALUES (14, 'liuqingtao', '梯子岭隧道进口')");
		db.execSQL("INSERT INTO duty VALUES (15, 'sunjingui', '梯子岭隧道进口')");
		db.execSQL("INSERT INTO duty VALUES (16, 'xuyuejin', '梯子岭隧道进口')");
		db.execSQL("INSERT INTO duty VALUES (17, 'zhanghu', '梯子岭隧道进口')");
		db.execSQL("INSERT INTO duty VALUES (18, 'guoyuxuan', '梯子岭隧道出口')");
		db.execSQL("INSERT INTO duty VALUES (20, 'gejianqiang', '梯子岭隧道出口')");
		db.execSQL("INSERT INTO duty VALUES (21, 'jiangguangrong', '梯子岭隧道出口')");
		db.execSQL("INSERT INTO duty VALUES (22, 'zhangqing', '梯子岭隧道出口')");
		db.execSQL("INSERT INTO duty VALUES (23, 'lilinyong', '排子隧道进口')");
		db.execSQL("INSERT INTO duty VALUES (24, 'gejianqiang', '排子隧道进口')");
		db.execSQL("INSERT INTO duty VALUES (25, 'jiangguangrong', '排子隧道进口')");
		db.execSQL("INSERT INTO duty VALUES (26, 'wangxuehai', '排子隧道进口')");
		db.execSQL("INSERT INTO duty VALUES (27, 'tujiquan', '排子隧道出口')");
		db.execSQL("INSERT INTO duty VALUES (28, 'bijianjun', '排子隧道出口')");
		db.execSQL("INSERT INTO duty VALUES (29, 'lvjianmin', '排子隧道出口')");
		db.execSQL("INSERT INTO duty VALUES (30, 'sujun', '排子隧道出口')");
		db.execSQL("INSERT INTO duty VALUES (31, 'tujiquan', '勾鼻墩1号隧道进口')");
		db.execSQL("INSERT INTO duty VALUES (32, 'bijianjun', '勾鼻墩1号隧道进口')");
		db.execSQL("INSERT INTO duty VALUES (33, 'lvjianmin', '勾鼻墩1号隧道进口')");
		db.execSQL("INSERT INTO duty VALUES (34, 'sujun', '勾鼻墩1号隧道进口')");
		db.execSQL("INSERT INTO duty VALUES (35, 'hanbo', '勾鼻墩2号隧道出口')");
		db.execSQL("INSERT INTO duty VALUES (36, 'liuliang', '勾鼻墩2号隧道出口')");
		db.execSQL("INSERT INTO duty VALUES (37, 'wangshengguang', '勾鼻墩2号隧道出口')");
		db.execSQL("INSERT INTO duty VALUES (38, '1', '排子隧道进口')");
		db.execSQL("INSERT INTO duty VALUES (39, '1', '排子隧道出口')");
		db.execSQL("INSERT INTO duty VALUES (40, '1', '梯子岭隧道进口')");
		db.execSQL("INSERT INTO duty VALUES (41, '2', '乌石咀隧道进口')");
		db.execSQL("INSERT INTO duty VALUES (42, 'zengxiangming', '乌石咀隧道进口')");
		db.execSQL("INSERT INTO duty VALUES (43, 'shenglin', '乌石咀隧道进口')");
		db.execSQL("INSERT INTO duty VALUES (44, 'lipeiju', '乌石咀隧道进口')");
		db.execSQL("INSERT INTO duty VALUES (45 , 'zhaochonghua', '乌石咀隧道进口')");
		db.execSQL("INSERT INTO duty VALUES (46 , 'weiyinguo', '乌石咀隧道出口')");
		db.execSQL("INSERT INTO duty VALUES (47, 'zhangyang', '乌石咀隧道进口')");
		db.execSQL("INSERT INTO duty VALUES (48, 'zhudagang', '乌石咀隧道进口')");
		db.execSQL("INSERT INTO duty VALUES (49, 'lishuai', '乌石咀隧道进口')");
		db.execSQL("INSERT INTO duty VALUES (50 , 'yuzhiming', '郑家2号隧道进口')");
		db.execSQL("INSERT INTO duty VALUES (51, 'sunjihua', '郑家2号隧道进口')");
		db.execSQL("INSERT INTO duty VALUES (52, 'zhangyafei', '郑家2号隧道进口')");
		db.execSQL("INSERT INTO duty VALUES (53, 'zhangningli', '郑家2号隧道进口')");
		db.execSQL("INSERT INTO duty VALUES (54, 'subenqing', '郑家2号隧道出口')");
		db.execSQL("INSERT INTO duty VALUES (55, 'qinyufeng', '郑家2号隧道出口')");
		db.execSQL("INSERT INTO duty VALUES (56, 'zhudagang', '郑家2号隧道出口')");
		db.execSQL("INSERT INTO duty VALUES (57, 'dingtao', '郑家2号隧道出口')");
		db.execSQL("INSERT INTO duty VALUES (58, 'zhanglei', '桃坪隧道出口')");
		db.execSQL("INSERT INTO duty VALUES (59, 'aiyouxing', '桃坪隧道出口')");
		db.execSQL("INSERT INTO duty VALUES (60, 'chenhao', '桃坪隧道出口')");
		db.execSQL("INSERT INTO duty VALUES (61, 'ludagang', '桃坪隧道出口')");

		//插入隧道信息
		db.execSQL("INSERT INTO tunnel VALUES (1, '桃坪隧道出口', '隧道一分部', '桃坪隧道', '出口', null)");
		db.execSQL("INSERT INTO tunnel VALUES (2, '乌石咀隧道进口', '隧道一分部', '乌石咀隧道', '进口', null)");
		db.execSQL("INSERT INTO tunnel VALUES (3, '乌石咀隧道出口', '隧道一分部', '乌石咀隧道', '出口', null)");
		db.execSQL("INSERT INTO tunnel VALUES (4, '郑家1号隧道出口', '隧道一分部', '郑家1号隧道', '出口', null)");
		db.execSQL("INSERT INTO tunnel VALUES (5, '郑家2号隧道进口', '隧道一分部', '郑家2号隧道', '进口', null)");
		db.execSQL("INSERT INTO tunnel VALUES (6, '郑家2号隧道出口', '隧道一分部', '郑家2号隧道', '出口', null)");
		db.execSQL("INSERT INTO tunnel VALUES (7, '梯子岭隧道出口', '隧道二分部', '梯子岭隧道', '出口', null)");
		db.execSQL("INSERT INTO tunnel VALUES (8, '排子隧道进口', '隧道二分部', '排子隧道', '进口', null)");
		db.execSQL("INSERT INTO tunnel VALUES (9, '勾鼻墩1号隧道进口', '隧道二分部', '勾鼻墩1号隧道', '进口', null)");
		db.execSQL("INSERT INTO tunnel VALUES (10, '勾鼻墩1号隧道出口', '隧道二分部', '勾鼻墩1号隧道', '出口', null)");
		db.execSQL("INSERT INTO tunnel VALUES (11, '勾鼻墩2号隧道进口', '隧道二分部', '勾鼻墩2号隧道', '进口', null)");
		db.execSQL("INSERT INTO tunnel VALUES (12, '柯树下隧道进口', '隧道二分部', '柯树下隧道', '进口', null)");
		db.execSQL("INSERT INTO tunnel VALUES (13, '树下隧道出口', '隧道二分部', '树下隧道', '出口', null)");
		db.execSQL("INSERT INTO tunnel VALUES (14, '梯子岭隧道进口', '隧道二分部', '梯子岭隧道', '进口', null)");


		//根据进出口方向插入隧道标段数据
		db.execSQL("INSERT INTO design_footage VALUES ('乌石咀隧道出口', '0', '20.2', 'V+', '0', '乌石咀隧道出口0')");
		db.execSQL("INSERT INTO design_footage VALUES ('乌石咀隧道出口', '1017.1', '1184.2', 'IV', '0', '乌石咀隧道出口1017.1')");
		db.execSQL("INSERT INTO design_footage VALUES ('乌石咀隧道出口', '1184.2', '1739.3', 'II', '0', '乌石咀隧道出口1184.2')");
		db.execSQL("INSERT INTO design_footage VALUES ('乌石咀隧道出口', '153.1', '295.2', 'IV', '0', '乌石咀隧道出口153.1')");
		db.execSQL("INSERT INTO design_footage VALUES ('乌石咀隧道出口', '1739.3', '1880.6', 'IV', '0', '乌石咀隧道出口1739.3')");
		db.execSQL("INSERT INTO design_footage VALUES ('乌石咀隧道出口', '1880.6', '2092', 'II', '0', '乌石咀隧道出口1880.6')");
		db.execSQL("INSERT INTO design_footage VALUES ('乌石咀隧道出口', '20.2', '153.1', 'III', '0', '乌石咀隧道出口20.2')");
		db.execSQL("INSERT INTO design_footage VALUES ('乌石咀隧道出口', '2092', '2303.3', 'IV', '0', '乌石咀隧道出口2092')");
		db.execSQL("INSERT INTO design_footage VALUES ('乌石咀隧道出口', '2303.3', '2325.6', 'V+', '0', '乌石咀隧道出口2303.3')");
		db.execSQL("INSERT INTO design_footage VALUES ('乌石咀隧道出口', '295.2', '1017.1', 'II', '0', '乌石咀隧道出口295.1')");
		db.execSQL("INSERT INTO design_footage VALUES ('乌石咀隧道进口', '1145.7', '1312.8', 'IV', '0', '乌石咀隧道进口1145.7')");
		db.execSQL("INSERT INTO design_footage VALUES ('乌石咀隧道进口', '1312.8', '2034.7', 'II', '0', '乌石咀隧道进口1312.8')");
		db.execSQL("INSERT INTO design_footage VALUES ('乌石咀隧道进口', '2034.7', '2176.8', 'IV', '0', '乌石咀隧道进口2034.7')");
		db.execSQL("INSERT INTO design_footage VALUES ('乌石咀隧道进口', '2176.8', '2309.7', 'III', '0', '乌石咀隧道进口2176.8')");
		db.execSQL("INSERT INTO design_footage VALUES ('乌石咀隧道进口', '2309.7', '2329.9', 'V+', '0', '乌石咀隧道进口2309.7')");
		db.execSQL("INSERT INTO design_footage VALUES ('乌石咀隧道进口', '237.9', '449.3', 'II', '0', '乌石咀隧道进口237.9')");
		db.execSQL("INSERT INTO design_footage VALUES ('乌石咀隧道进口', '26.6', '237.9', 'IV', '0', '乌石咀隧道进口26.6')");
		db.execSQL("INSERT INTO design_footage VALUES ('乌石咀隧道进口', '4.3', '26.6', 'V+', '0', '乌石咀隧道进口4.3')");
		db.execSQL("INSERT INTO design_footage VALUES ('乌石咀隧道进口', '449.3', '590.6', 'IV', '0', '乌石咀隧道进口449.3')");
		db.execSQL("INSERT INTO design_footage VALUES ('乌石咀隧道进口', '590.6', '1145.7', 'II', '0', '乌石咀隧道进口590.6')");
		db.execSQL("INSERT INTO design_footage VALUES ('勾鼻墩1号隧道出口', '0', '13.5', 'V+', '0', '勾鼻墩1号隧道出口0')");
		db.execSQL("INSERT INTO design_footage VALUES ('勾鼻墩1号隧道出口', '13.5', '411.8', 'IV', '0', '勾鼻墩1号隧道出口13.5')");
		db.execSQL("INSERT INTO design_footage VALUES ('勾鼻墩1号隧道出口', '411.8', '452.1', 'V+', '0', '勾鼻墩1号隧道出口411.8')");
		db.execSQL("INSERT INTO design_footage VALUES ('勾鼻墩1号隧道进口', '16.9', '57.2', 'V+', '0', '勾鼻墩1号隧道进口16.9')");
		db.execSQL("INSERT INTO design_footage VALUES ('勾鼻墩1号隧道进口', '455.5', '469', 'V+', '0', '勾鼻墩1号隧道进口455.5')");
		db.execSQL("INSERT INTO design_footage VALUES ('勾鼻墩1号隧道进口', '57.2', '455.5', 'IV', '0', '勾鼻墩1号隧道进口57.2')");
		db.execSQL("INSERT INTO design_footage VALUES ('勾鼻墩2号隧道出口', '104.6', '151.7', 'V+', '0', '勾鼻墩2号隧道出口104.6')");
		db.execSQL("INSERT INTO design_footage VALUES ('勾鼻墩2号隧道出口', '151.7', '275.5', 'V', '0', '勾鼻墩2号隧道出口151.7')");
		db.execSQL("INSERT INTO design_footage VALUES ('勾鼻墩2号隧道出口', '2.5', '30', 'V+', '0', '勾鼻墩2号隧道出口2.5')");
		db.execSQL("INSERT INTO design_footage VALUES ('勾鼻墩2号隧道出口', '275.5', '439.6', 'IV', '0', '勾鼻墩2号隧道出口275.5')");
		db.execSQL("INSERT INTO design_footage VALUES ('勾鼻墩2号隧道出口', '30', '104.6', 'V', '0', '勾鼻墩2号隧道出口30')");
		db.execSQL("INSERT INTO design_footage VALUES ('勾鼻墩2号隧道出口', '439.6', '527.7', 'V', '0', '勾鼻墩2号隧道出口439.6')");
		db.execSQL("INSERT INTO design_footage VALUES ('勾鼻墩2号隧道出口', '527.7', '564.2', 'V+', '0', '勾鼻墩2号隧道出口527.7')");
		db.execSQL("INSERT INTO design_footage VALUES ('勾鼻墩2号隧道出口', '599.8', '759.2', 'IV', '0', '勾鼻墩2号隧道出口599.8')");
		db.execSQL("INSERT INTO design_footage VALUES ('勾鼻墩2号隧道出口', '759.2', '804.8', 'V+', '0', '勾鼻墩2号隧道出口759.2')");
		db.execSQL("INSERT INTO design_footage VALUES ('勾鼻墩2号隧道进口', '248.2', '284.7', 'V+', '0', '勾鼻墩2号隧道进口248.2')");
		db.execSQL("INSERT INTO design_footage VALUES ('勾鼻墩2号隧道进口', '284.7', '372.8', 'V', '0', '勾鼻墩2号隧道进口284.7')");
		db.execSQL("INSERT INTO design_footage VALUES ('勾鼻墩2号隧道进口', '372.8', '536.9', 'IV', '0', '勾鼻墩2号隧道进口372.8')");
		db.execSQL("INSERT INTO design_footage VALUES ('勾鼻墩2号隧道进口', '53.2', '212.6', 'IV', '0', '勾鼻墩2号隧道进口53.2')");
		db.execSQL("INSERT INTO design_footage VALUES ('勾鼻墩2号隧道进口', '536.9', '660.7', 'V', '0', '勾鼻墩2号隧道进口536.9')");
		db.execSQL("INSERT INTO design_footage VALUES ('勾鼻墩2号隧道进口', '660.7', '707.8', 'V+', '0', '勾鼻墩2号隧道进口660.7')");
		db.execSQL("INSERT INTO design_footage VALUES ('勾鼻墩2号隧道进口', '7.6', '53.2', 'V+', '0', '勾鼻墩2号隧道进口7.6')");
		db.execSQL("INSERT INTO design_footage VALUES ('勾鼻墩2号隧道进口', '707.8', '782.4', 'V', '0', '勾鼻墩2号隧道进口707.8')");
		db.execSQL("INSERT INTO design_footage VALUES ('勾鼻墩2号隧道进口', '782.4', '809.9', 'V+', '0', '勾鼻墩2号隧道进口782.4')");
		db.execSQL("INSERT INTO design_footage VALUES ('排子隧道出口', '363.8', '750.7', 'IV', '0', '排子隧道出口363.8')");
		db.execSQL("INSERT INTO design_footage VALUES ('排子隧道出口', '4.6', '43.4', 'V+', '0', '排子隧道出口4.6')");
		db.execSQL("INSERT INTO design_footage VALUES ('排子隧道出口', '43.4', '363.8', 'V', '0', '排子隧道出口43.4')");
		db.execSQL("INSERT INTO design_footage VALUES ('排子隧道出口', '750.7', '777.6', 'V+', '0', '排子隧道出口750.7')");
		db.execSQL("INSERT INTO design_footage VALUES ('排子隧道进口', '31.9', '418.8', 'IV', '0', '排子隧道进口31.9')");
		db.execSQL("INSERT INTO design_footage VALUES ('排子隧道进口', '418.8', '739.2', 'V', '0', '排子隧道进口418.8')");
		db.execSQL("INSERT INTO design_footage VALUES ('排子隧道进口', '5', '31.9', 'V+', '0', '排子隧道进口5')");
		db.execSQL("INSERT INTO design_footage VALUES ('排子隧道进口', '739.2', '778', 'V+', '0', '排子隧道进口739.2')");
		db.execSQL("INSERT INTO design_footage VALUES ('柯树下隧道出口', '1018.9', '1102.7', 'IV', '0', '柯树下隧道出口1018.9')");
		db.execSQL("INSERT INTO design_footage VALUES ('柯树下隧道出口', '1102.7', '1136.1', 'V', '0', '柯树下隧道出口1102.7')");
		db.execSQL("INSERT INTO design_footage VALUES ('柯树下隧道出口', '1136.1', '1166.1', 'V+', '0', '柯树下隧道出口1136.1')");
		db.execSQL("INSERT INTO design_footage VALUES ('柯树下隧道出口', '172.2', '388.8', 'III', '0', '柯树下隧道出口172.2')");
		db.execSQL("INSERT INTO design_footage VALUES ('柯树下隧道出口', '35', '74.5', 'V', '0', '柯树下隧道出口35')");
		db.execSQL("INSERT INTO design_footage VALUES ('柯树下隧道出口', '388.8', '672.7', 'IV', '0', '柯树下隧道出口388.8')");
		db.execSQL("INSERT INTO design_footage VALUES ('柯树下隧道出口', '6', '35', 'V+', '0', '柯树下隧道出口6')");
		db.execSQL("INSERT INTO design_footage VALUES ('柯树下隧道出口', '672.7', '865.8', 'V', '0', '柯树下隧道出口672.7')");
		db.execSQL("INSERT INTO design_footage VALUES ('柯树下隧道出口', '74.5', '172.2', 'IV', '0', '柯树下隧道出口74.5')");
		db.execSQL("INSERT INTO design_footage VALUES ('柯树下隧道出口', '865.8', '1018.9', 'III', '0', '柯树下隧道出口865.8')");
		db.execSQL("INSERT INTO design_footage VALUES ('柯树下隧道进口', '1012', '1109.7', 'IV', '0', '柯树下隧道进口1012')");
		db.execSQL("INSERT INTO design_footage VALUES ('柯树下隧道进口', '1109.7', '1149.2', 'V', '0', '柯树下隧道进口1109.7')");
		db.execSQL("INSERT INTO design_footage VALUES ('柯树下隧道进口', '1149.2', '1178.2', 'V+', '0', '柯树下隧道进口1149.2')");
		db.execSQL("INSERT INTO design_footage VALUES ('柯树下隧道进口', '165.3', '318.4', 'III', '0', '柯树下隧道进口165.3')");
		db.execSQL("INSERT INTO design_footage VALUES ('柯树下隧道进口', '18.1', '48.1', 'V+', '0', '柯树下隧道进口18.1')");
		db.execSQL("INSERT INTO design_footage VALUES ('柯树下隧道进口', '318.4', '511.5', 'V', '0', '柯树下隧道进口318.4')");
		db.execSQL("INSERT INTO design_footage VALUES ('柯树下隧道进口', '48.1', '81.5', 'V', '0', '柯树下隧道进口48.1')");
		db.execSQL("INSERT INTO design_footage VALUES ('柯树下隧道进口', '511.5', '795.4', 'IV', '0', '柯树下隧道进口511.5')");
		db.execSQL("INSERT INTO design_footage VALUES ('柯树下隧道进口', '795.4', '1012', 'III', '0', '柯树下隧道进口795.4')");
		db.execSQL("INSERT INTO design_footage VALUES ('柯树下隧道进口', '81.5', '165.3', 'IV', '0', '柯树下隧道进口81.5')");
		db.execSQL("INSERT INTO design_footage VALUES ('桃坪隧道出口', '1074', '1125.4', 'V', '0', '桃坪隧道出口1074')");
		db.execSQL("INSERT INTO design_footage VALUES ('桃坪隧道出口', '1125.4', '1142.4', 'V+', '0', '桃坪隧道出口1125.4')");
		db.execSQL("INSERT INTO design_footage VALUES ('桃坪隧道出口', '280.6', '606.4', 'IV', '0', '桃坪隧道出口280.6')");
		db.execSQL("INSERT INTO design_footage VALUES ('桃坪隧道出口', '32.3', '280.6', 'II', '0', '桃坪隧道出口32.3')");
		db.execSQL("INSERT INTO design_footage VALUES ('桃坪隧道出口', '5', '32.3', 'V+', '0', '桃坪隧道出口5')");
		db.execSQL("INSERT INTO design_footage VALUES ('桃坪隧道出口', '606.4', '701.2', 'III', '0', '桃坪隧道出口606.4')");
		db.execSQL("INSERT INTO design_footage VALUES ('桃坪隧道出口', '701.2', '1074', 'IV', '0', '桃坪隧道出口701.2')");
		db.execSQL("INSERT INTO design_footage VALUES ('桃坪隧道进口', '11.3', '28.3', 'V+', '0', '桃坪隧道进口11.3')");
		db.execSQL("INSERT INTO design_footage VALUES ('桃坪隧道进口', '1121.4', '1148.7', 'V+', '0', '桃坪隧道进口1121.4')");
		db.execSQL("INSERT INTO design_footage VALUES ('桃坪隧道进口', '28.3', '79.7', 'V', '0', '桃坪隧道进口28.3')");
		db.execSQL("INSERT INTO design_footage VALUES ('桃坪隧道进口', '452.5', '547.3', 'III', '0', '桃坪隧道进口452.5')");
		db.execSQL("INSERT INTO design_footage VALUES ('桃坪隧道进口', '547.3', '873.1', 'IV', '0', '桃坪隧道进口547.3')");
		db.execSQL("INSERT INTO design_footage VALUES ('桃坪隧道进口', '79.7', '452.5', 'IV', '0', '桃坪隧道进口79.7')");
		db.execSQL("INSERT INTO design_footage VALUES ('桃坪隧道进口', '873.1', '1121.4', 'II', '0', '桃坪隧道进口873.1')");
		db.execSQL("INSERT INTO design_footage VALUES ('梯子岭隧道出口', '1258.7', '1464.5', 'V', '0', '梯子岭隧道出口1258.7')");
		db.execSQL("INSERT INTO design_footage VALUES ('梯子岭隧道出口', '132.4', '176.6', 'IV', '0', '梯子岭隧道出口132.4')");
		db.execSQL("INSERT INTO design_footage VALUES ('梯子岭隧道出口', '1464.5', '1728.9', 'IV', '0', '梯子岭隧道出口1464.5')");
		db.execSQL("INSERT INTO design_footage VALUES ('梯子岭隧道出口', '1728.9', '1790.5', 'V', '0', '梯子岭隧道出口1728.9')");
		db.execSQL("INSERT INTO design_footage VALUES ('梯子岭隧道出口', '176.6', '268.1', 'V', '0', '梯子岭隧道出口176.6')");
		db.execSQL("INSERT INTO design_footage VALUES ('梯子岭隧道出口', '1790.5', '1848.9', 'IV', '0', '梯子岭隧道出口1790.5')");
		db.execSQL("INSERT INTO design_footage VALUES ('梯子岭隧道出口', '1848.9', '1897.6', 'V', '0', '梯子岭隧道出口1848.9')");
		db.execSQL("INSERT INTO design_footage VALUES ('梯子岭隧道出口', '1897.6', '1919.6', 'V+', '0', '梯子岭隧道出口1897.6')");
		db.execSQL("INSERT INTO design_footage VALUES ('梯子岭隧道出口', '268.1', '599.6', 'IV', '0', '梯子岭隧道出口268.1')");
		db.execSQL("INSERT INTO design_footage VALUES ('梯子岭隧道出口', '27.2', '132.4', 'V', '0', '梯子岭隧道出口27.2')");
		db.execSQL("INSERT INTO design_footage VALUES ('梯子岭隧道出口', '3', '27.2', 'V+', '0', '梯子岭隧道出口3')");
		db.execSQL("INSERT INTO design_footage VALUES ('梯子岭隧道出口', '599.6', '756.9', 'V', '0', '梯子岭隧道出口599.6')");
		db.execSQL("INSERT INTO design_footage VALUES ('梯子岭隧道出口', '756.9', '857.6', 'IV', '0', '梯子岭隧道出口756.9')");
		db.execSQL("INSERT INTO design_footage VALUES ('梯子岭隧道出口', '857.6', '904.8', 'V', '0', '梯子岭隧道出口857.6')");
		db.execSQL("INSERT INTO design_footage VALUES ('梯子岭隧道出口', '904.8', '1258.7', 'IV', '0', '梯子岭隧道出口904.8')");
		db.execSQL("INSERT INTO design_footage VALUES ('梯子岭隧道进口', '1020.3', '1067.5', 'V', '0', '梯子岭隧道进口1020.3')");
		db.execSQL("INSERT INTO design_footage VALUES ('梯子岭隧道进口', '1067.5', '1168.2', 'IV', '0', '梯子岭隧道进口1067.5')");
		db.execSQL("INSERT INTO design_footage VALUES ('梯子岭隧道进口', '1168.2', '1325.5', 'V', '0', '梯子岭隧道进口1168.2')");
		db.execSQL("INSERT INTO design_footage VALUES ('梯子岭隧道进口', '1325.5', '1657', 'IV', '0', '梯子岭隧道进口1325.5')");
		db.execSQL("INSERT INTO design_footage VALUES ('梯子岭隧道进口', '134.6', '196.2', 'V', '0', '梯子岭隧道进口134.6')");
		db.execSQL("INSERT INTO design_footage VALUES ('梯子岭隧道进口', '1657', '1748.5', 'V', '0', '梯子岭隧道进口1657')");
		db.execSQL("INSERT INTO design_footage VALUES ('梯子岭隧道进口', '1748.5', '1792.7', 'IV', '0', '梯子岭隧道进口1748.5')");
		db.execSQL("INSERT INTO design_footage VALUES ('梯子岭隧道进口', '1792.7', '1848.9', 'V', '0', '梯子岭隧道进口1792.7')");
		db.execSQL("INSERT INTO design_footage VALUES ('梯子岭隧道进口', '1897.7', '1922.1', 'V+', '0', '梯子岭隧道进口1897.7')");
		db.execSQL("INSERT INTO design_footage VALUES ('梯子岭隧道进口', '196.2', '460.6', 'IV', '0', '梯子岭隧道进口196.2')");
		db.execSQL("INSERT INTO design_footage VALUES ('梯子岭隧道进口', '27.5', '76.2', 'V', '0', '梯子岭隧道进口27.5')");
		db.execSQL("INSERT INTO design_footage VALUES ('梯子岭隧道进口', '460.6', '666.4', 'V', '0', '梯子岭隧道进口460.6')");
		db.execSQL("INSERT INTO design_footage VALUES ('梯子岭隧道进口', '5.5', '27.5', 'V+', '0', '梯子岭隧道进口5.5')");
		db.execSQL("INSERT INTO design_footage VALUES ('梯子岭隧道进口', '666.4', '1020.3', 'IV', '0', '梯子岭隧道进口666.4')");
		db.execSQL("INSERT INTO design_footage VALUES ('梯子岭隧道进口', '76.2', '134.6', 'IV', '0', '梯子岭隧道进口76.2')");
		db.execSQL("INSERT INTO design_footage VALUES ('郑家1号隧道出口', '0', '17.9', 'V+', '0', '郑家1号隧道出口0')");
		db.execSQL("INSERT INTO design_footage VALUES ('郑家1号隧道出口', '122.2', '178.6', 'IV', '0', '郑家1号隧道出口122.2')");
		db.execSQL("INSERT INTO design_footage VALUES ('郑家1号隧道出口', '17.9', '122.2', 'III', '0', '郑家1号隧道出口17.9')");
		db.execSQL("INSERT INTO design_footage VALUES ('郑家1号隧道进口', '-1.5', '54.9', 'IV', '0', '郑家1号隧道进口-1.5')");
		db.execSQL("INSERT INTO design_footage VALUES ('郑家1号隧道进口', '159.2', '177.1', 'V+', '0', '郑家1号隧道进口159.2')");
		db.execSQL("INSERT INTO design_footage VALUES ('郑家1号隧道进口', '54.9', '159.2', 'III', '0', '郑家1号隧道进口54.9')");
		db.execSQL("INSERT INTO design_footage VALUES ('郑家2号隧道出口', '1089.3', '1139.3', 'V', '0', '郑家2号隧道出口1089.3')");
		db.execSQL("INSERT INTO design_footage VALUES ('郑家2号隧道出口', '1139.3', '1323.7', 'III', '0', '郑家2号隧道出口1139.3')");
		db.execSQL("INSERT INTO design_footage VALUES ('郑家2号隧道出口', '1323.7', '1344.1', 'V+', '0', '郑家2号隧道出口1323.7')");
		db.execSQL("INSERT INTO design_footage VALUES ('郑家2号隧道出口', '238', '380.2', 'V', '0', '郑家2号隧道出口238')");
		db.execSQL("INSERT INTO design_footage VALUES ('郑家2号隧道出口', '34.5', '76', 'III', '0', '郑家2号隧道出口34.5')");
		db.execSQL("INSERT INTO design_footage VALUES ('郑家2号隧道出口', '380.2', '905.5', 'III', '0', '郑家2号隧道出口380.2')");
		db.execSQL("INSERT INTO design_footage VALUES ('郑家2号隧道出口', '4.9', '34.5', 'V+', '0', '郑家2号隧道出口4.9')");
		db.execSQL("INSERT INTO design_footage VALUES ('郑家2号隧道出口', '76', '238', 'IV', '0', '郑家2号隧道出口76')");
		db.execSQL("INSERT INTO design_footage VALUES ('郑家2号隧道出口', '905.5', '981.7', 'V', '0', '郑家2号隧道出口905.5')");
		db.execSQL("INSERT INTO design_footage VALUES ('郑家2号隧道出口', '981.7', '1089.3', 'III', '0', '郑家2号隧道出口981.7')");
		db.execSQL("INSERT INTO design_footage VALUES ('郑家2号隧道进口', '1110.2', '1272.2', 'IV', '0', '郑家2号隧道进口1110.2')");
		db.execSQL("INSERT INTO design_footage VALUES ('郑家2号隧道进口', '1272.2', '1313.7', 'III', '0', '郑家2号隧道进口1272.2')");
		db.execSQL("INSERT INTO design_footage VALUES ('郑家2号隧道进口', '1313.7', '1343.3', 'V+', '0', '郑家2号隧道进口1313.7')");
		db.execSQL("INSERT INTO design_footage VALUES ('郑家2号隧道进口', '208.9', '258.9', 'V', '0', '郑家2号隧道进口208.9')");
		db.execSQL("INSERT INTO design_footage VALUES ('郑家2号隧道进口', '24.5', '208.9', 'III', '0', '郑家2号隧道进口24.5')");
		db.execSQL("INSERT INTO design_footage VALUES ('郑家2号隧道进口', '258.9', '366.5', 'III', '0', '郑家2号隧道进口258.9')");
		db.execSQL("INSERT INTO design_footage VALUES ('郑家2号隧道进口', '366.5', '442.7', 'V', '0', '郑家2号隧道进口366.5')");
		db.execSQL("INSERT INTO design_footage VALUES ('郑家2号隧道进口', '4.1', '24.5', 'V+', '0', '郑家2号隧道进口4.1')");
		db.execSQL("INSERT INTO design_footage VALUES ('郑家2号隧道进口', '442.7', '968', 'III', '0', '郑家2号隧道进口442.7')");
		db.execSQL("INSERT INTO design_footage VALUES ('郑家2号隧道进口', '968', '1110.2', 'V', '0', '郑家2号隧道进口968')");


		//插入流程数据
		db.execSQL("INSERT INTO process VALUES (1, 'V+小导管安装', 'V+', '小导管安装', null, 'Ø42X3无缝钢管，长4m，间距400mm，角度10~20度。')");
		db.execSQL("INSERT INTO process VALUES (2, 'V+小导管注浆', 'V+', '小导管注浆', null, '注浆压力1.0~1.5MPa，可根据实测隧道水压等情况适当调整。')");
		db.execSQL("INSERT INTO process VALUES (3, 'V+管棚成品', 'V+', '管棚成品', null, 'Ø89X4.5无缝钢管，钢管外插角2度。')");
		db.execSQL("INSERT INTO process VALUES (4, 'V+管棚注浆', 'V+', '管棚注浆', null, '注浆压力0.3~0.7MPa，可根据实际情况适当调整。')");
		db.execSQL("INSERT INTO process VALUES (5, 'V+超前钻孔', 'V+', '超前钻孔', null, '3孔偏角超前钻探法，超前探测20m，探孔分布在两边底部和拱顶，若发现涌水，需施做中间的4个探水孔；利用炮眼加深超前钻探6m。')");
		db.execSQL("INSERT INTO process VALUES (6, 'V+支立钢拱架', 'V+', '支立钢拱架', null, '采用12工字钢，间距1m/榀，可根据围岩破碎及沉降情况加密至0.6~0.8m/榀。工字钢架纵向筋为Ø18，间距0.8m。锁脚锚杆长度2m。')");
		db.execSQL("INSERT INTO process VALUES (7, 'V+锚杆', 'V+', '锚杆', null, 'Ø 22锚杆，长度2.5m，间距1.0m，呈梅花型布置。')");
		db.execSQL("INSERT INTO process VALUES (8, 'V+挂网', 'V+', '挂网', null, '直径6钢筋，网格尺寸为20cm×20cm；锚杆垫板采用Q235B钢，厚度6mm，M16螺母紧固至洞壁。')");
		db.execSQL("INSERT INTO process VALUES (9, 'V+锚喷', 'V+', '锚喷', null, '喷射C25混凝土，厚度150mm。')");
		db.execSQL("INSERT INTO process VALUES (10, 'V+进尺数', 'V+', '进尺数', null, '')");

		db.execSQL("INSERT INTO process VALUES (11, 'V小导管安装', 'V', '小导管安装', null, 'Ø42X3无缝钢管，长4m，间距400mm，角度10~20度。')");
		db.execSQL("INSERT INTO process VALUES (12, 'V小导管注浆', 'V', '小导管注浆', null, '注浆压力1.0~1.5MPa，可根据实测隧道水压等情况适当调整。')");
		db.execSQL("INSERT INTO process VALUES (13, 'V管棚成品', 'V', '管棚成品', null, 'Ø89X4.5无缝钢管，钢管外插角2度。')");
		db.execSQL("INSERT INTO process VALUES (14, 'V管棚注浆', 'V', '管棚注浆', null, '注浆压力0.3~0.7MPa，可根据实际情况适当调整。')");
		db.execSQL("INSERT INTO process VALUES (15, 'V超前钻孔', 'V', '超前钻孔', null, '3孔偏角超前钻探法，超前探测20m，探孔分布在两边底部和拱顶，若发现涌水，需施做中间的4个探水孔；利用炮眼加深超前钻探6m。')");
		db.execSQL("INSERT INTO process VALUES (16, 'V支立钢拱架', 'V', '支立钢拱架', null, '采用10工字钢，间距1m/榀，可根据围岩破碎及沉降情况加密至0.6~0.8m/榀。工字钢架纵向筋为Ø18，间距0.8m。锁脚锚杆长度2m。')");
		db.execSQL("INSERT INTO process VALUES (17, 'V锚杆', 'V', '锚杆', null, 'Ø 22锚杆，长度2.5m，间距1.0m，呈梅花型布置；')");
		db.execSQL("INSERT INTO process VALUES (18, 'V挂网', 'V', '挂网', null, '直径6钢筋，网格尺寸为20cm×20cm；锚杆垫板采用Q235B钢，厚度6mm，M16螺母紧固至洞壁。')");
		db.execSQL("INSERT INTO process VALUES (19, 'V锚喷', 'V', '锚喷', null, '喷射C25混凝土，厚度150mm。')");
		db.execSQL("INSERT INTO process VALUES (20, 'V进尺数', 'V', '进尺数', null, '')");

		db.execSQL("INSERT INTO process VALUES (21, 'IV小导管安装', 'IV', '小导管安装', null, '无')");
		db.execSQL("INSERT INTO process VALUES (22, 'IV小导管注浆', 'IV', '小导管注浆', null, '无')");
		db.execSQL("INSERT INTO process VALUES (23, 'IV管棚成品', 'IV', '管棚成品', null, '无')");
		db.execSQL("INSERT INTO process VALUES (24, 'IV管棚注浆', 'IV', '管棚注浆', null, '无')");
		db.execSQL("INSERT INTO process VALUES (25, 'IV超前钻孔', 'IV', '超前钻孔', null, '3孔偏角超前钻探法，超前探测20m，探孔分布在两边底部和拱顶，若发现涌水，需施做中间的4个探水孔；利用炮眼加深超前钻探6m。')");
		db.execSQL("INSERT INTO process VALUES (26, 'IV支立钢拱架', 'IV', '支立钢拱架', null, '采用10工字钢，间距1m/榀，可根据围岩破碎及沉降情况加密至0.6~0.8m/榀。工字钢架纵向筋为Ø18，间距0.8m。锁脚锚杆长度2m。')");
		db.execSQL("INSERT INTO process VALUES (27, 'IV锚杆', 'IV', '锚杆', null, 'Ø 22锚杆，长度2.0m，间距1.2m，呈梅花型布置；')");
		db.execSQL("INSERT INTO process VALUES (28, 'IV挂网', 'IV', '挂网', null, '直径6钢筋，网格尺寸为25cm×25cm；锚杆垫板采用Q235B钢，厚度6mm，M16螺母紧固至洞壁。')");
		db.execSQL("INSERT INTO process VALUES (29, 'IV锚喷', 'IV', '锚喷', null, '喷射C25混凝土，厚度100mm。')");
		db.execSQL("INSERT INTO process VALUES (30, 'IV进尺数', 'IV', '进尺数', null, '')");

		db.execSQL("INSERT INTO process VALUES (31, 'III小导管安装', 'III', '小导管安装', null, '无')");
		db.execSQL("INSERT INTO process VALUES (32, 'III小导管注浆', 'III', '小导管注浆', null, '无')");
		db.execSQL("INSERT INTO process VALUES (33, 'III管棚成品', 'III', '管棚成品', null, '无')");
		db.execSQL("INSERT INTO process VALUES (34, 'III管棚注浆', 'III', '管棚注浆', null, '无')");
		db.execSQL("INSERT INTO process VALUES (35, 'III超前钻孔', 'III', '超前钻孔', null, '3孔偏角超前钻探法，超前探测20m，探孔分布在两边底部和拱顶，若发现涌水，需施做中间的4个探水孔；利用炮眼加深超前钻探6m。')");
		db.execSQL("INSERT INTO process VALUES (36, 'III支立钢拱架', 'III', '支立钢拱架', null, '无')");
		db.execSQL("INSERT INTO process VALUES (37, 'III锚杆', 'III', '锚杆', null, 'Ø 22锚杆，长度2.0m，环向间距1.2m，纵向间距1.5m；')");
		db.execSQL("INSERT INTO process VALUES (38, 'III挂网', 'III', '挂网', null, '直径6钢筋，网格尺寸为25cm×25cm；锚杆垫板采用Q235B钢，厚度6mm，M16螺母紧固至洞壁。')");
		db.execSQL("INSERT INTO process VALUES (39, 'III锚喷', 'III', '锚喷', null, '喷射C25混凝土，厚度100mm。')");
		db.execSQL("INSERT INTO process VALUES (40, 'III进尺数', 'III', '进尺数', null, '')");

		db.execSQL("INSERT INTO process VALUES (41, 'II小导管安装', 'II', '小导管安装', null, '无')");
		db.execSQL("INSERT INTO process VALUES (42, 'II小导管注浆', 'II', '小导管注浆', null, '无')");
		db.execSQL("INSERT INTO process VALUES (43, 'II管棚成品', 'II', '管棚成品', null, '无')");
		db.execSQL("INSERT INTO process VALUES (44, 'II管棚注浆', 'II', '管棚注浆', null, '无')");
		db.execSQL("INSERT INTO process VALUES (45, 'II超前钻孔', 'II', '超前钻孔', null, '无')");
		db.execSQL("INSERT INTO process VALUES (46, 'II支立钢拱架', 'II', '支立钢拱架', null, '局部破碎段、渗流较大地段设锚杆、钢筋网，参照Ⅲ级围岩支护设置。（采用12工字钢，间距1m/榀，可根据围岩破碎及沉降情况加密至0.6~0.8m/榀。工字钢架纵向筋为Ø18，间距0.8m。锁脚锚杆长度2m。')");
		db.execSQL("INSERT INTO process VALUES (47, 'II锚杆', 'II', '锚杆', null, '局部破碎段、渗流较大地段设锚杆、钢筋网，参照Ⅲ级围岩支护设置。（Ø 22锚杆，长度2.0m，环向间距1.2m，纵向间距1.5m；')");
		db.execSQL("INSERT INTO process VALUES (48, 'II挂网', 'II', '挂网', null, '局部破碎段、渗流较大地段设锚杆、钢筋网，参照Ⅲ级围岩支护设置。（直径6钢筋，网格尺寸为25cm×25cm；锚杆垫板采用Q235B钢，厚度6mm，M16螺母紧固至洞壁。')");
		db.execSQL("INSERT INTO process VALUES (49, 'II锚喷', 'II', '锚喷', null, '喷射C25混凝土厚度80mm，局部破碎段、渗流较大地段设锚杆、钢筋网，参照Ⅲ级围岩支护设置。')");
		db.execSQL("INSERT INTO process VALUES (50, 'II进尺数', 'II', '进尺数', null, '')");

		db.execSQL("INSERT INTO process VALUES (51, '掌子面围岩变更', '掌子面', '围岩变更', null, '')");

		db.execSQL("INSERT INTO process VALUES (61, 'V+管棚安装', 'V+', '管棚安装', null, '无。')");
		db.execSQL("INSERT INTO process VALUES (62, 'V管棚安装', 'V', '管棚安装', null, '无。')");
		db.execSQL("INSERT INTO process VALUES (63, 'IV管棚安装', 'IV', '管棚安装', null, '无。')");
		db.execSQL("INSERT INTO process VALUES (64, 'III管棚安装', 'III', '管棚安装', null, '无。')");
		db.execSQL("INSERT INTO process VALUES (65, 'II管棚安装', 'II', '管棚安装', null, '无。')");

        System.out.println("数据库创建成功");
    }

  
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
//        Log.e("DBOpenHelper", "onUpgradeonUpgradeonUpgradeonUpgradeonUpgradeonUpgradeonUpgradeonUpgrade");
        db.execSQL("DROP TABLE IF EXISTS adjustment_grade");
        db.execSQL("DROP TABLE IF EXISTS design_footage");
        db.execSQL("DROP TABLE IF EXISTS duty");
        db.execSQL("DROP TABLE IF EXISTS log");
        db.execSQL("DROP TABLE IF EXISTS process");
        db.execSQL("DROP TABLE IF EXISTS tunnel");
        db.execSQL("DROP TABLE IF EXISTS user");
        db.execSQL("DROP TABLE IF EXISTS picture");
        onCreate(db);
        
    }
    
	public void insertOrUpdateDateBatch(List<String> sqls) {
		SQLiteDatabase db = getWritableDatabase();
		db.beginTransaction();
		try {
			for (String sql : sqls) {
				db.execSQL(sql);
		}
		// 设置事务标志为成功，当结束事务时就会提交事务
		db.setTransactionSuccessful();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
		// 结束事务
			db.endTransaction();
			db.close();
		}
	}



}