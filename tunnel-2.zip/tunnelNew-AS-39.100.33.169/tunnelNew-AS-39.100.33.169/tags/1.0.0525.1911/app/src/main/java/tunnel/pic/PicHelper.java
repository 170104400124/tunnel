package tunnel.pic;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.media.ExifInterface;
import android.net.Uri;
import android.os.Build;
import android.text.TextPaint;
import android.text.TextUtils;
import android.util.Log;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * Created by Leon on 2019/5/11.
 */
public class PicHelper {
	public static String PHOTO_FILE_PATH = null;
	public PicHelper() {
		PicFileUtils.init();
		PHOTO_FILE_PATH = PicFileUtils.getFileDir() + File.separator;
	}

	public String addTimestamp2Photo(Intent data, Activity ac, String photoAbsolutePath, List<String> waterMark) {
		SharedPreferences sp = ac.getSharedPreferences("data", Context.MODE_PRIVATE);
		String user_id = sp.getString("user_id", "");
		String dateTime = this.getDateTime();
		// 带时间戳的照片，保存路径
		String tsPicFullPath = null;

//		if(null != data) {
//			// 获得的缩略图
//			try {
//				Bitmap bitmap = (Bitmap)data.getExtras().get("data");
//				Bitmap tsBitmap = this.addTimestampOnPic(ac, bitmap, waterMark);
//				// 带时间戳的照片，保存路径
//				tsPicFullPath = this.getPicAbsolutePath(dateTime+"_ts");
//				// 输出带时间戳的照片
//				this.outputBitmap(tsBitmap, tsPicFullPath, 100);
//			} catch (FileNotFoundException e) {
//				Log.e("照片存储失败", e.getMessage());
//			}
//		}

		// 调用相机拍照
		// 思路：将加号移除--调用拍照返回数据--将数据添加至集合--在onRestart中判断是否添加加号并刷新adapter
//		if (data == null)
		{
			try {
				Bitmap tsBitmap = null;
				// 带时间戳的照片
				tsBitmap = this.addTimestampOnPic(ac, Uri.fromFile(new File(photoAbsolutePath)), waterMark);
				// 带时间戳的照片，保存路径
				tsPicFullPath = this.getPicAbsolutePath(dateTime+"_ts");
				// 输出带时间戳的照片
				this.outputBitmap(tsBitmap, tsPicFullPath, 100);
				tsBitmap.recycle();
				System.gc();
			} catch (Exception e) {
				Log.e("照片存储失败", e.getMessage());
			}
		}
		return tsPicFullPath;
	}

	/**
	 * 查询指定路径文件是否存在，若不存在就直接创建
	 * @param path 指定路径
	 */
	private void mkdir(String path) {
		File d = new File(path + File.separator);
		if (!d.exists()) {
			d.mkdirs();
		}
	}

	/**
	 * 获得照片保存的绝对路径
	 * @param fileName
	 * @return
     */
	public String getPicAbsolutePath(String fileName) {
		//		路径规则：SD卡路径（内部存储）/packageName/no_upload_media/yyyyMMddHHmmss.jpg
		String photoName = fileName + ".jpg"; // 初始化图片文件名
		String savePath = PHOTO_FILE_PATH + File.separator + photoName; // 初始化文件夹位置
		Log.e("path", savePath);

		mkdir(PHOTO_FILE_PATH); // 查询并创建文件夹
		return savePath;
	}
	public String getDateTime() {
		Date currentDate = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd_HH-mm-ss", Locale.CHINESE);
		String current_datetime = sdf.format(currentDate); // 初始化当前时间值

		return current_datetime;
	}

	/**
	 * 以最省内存的方式读取本地资源的图片
	 *@param fileName
	 * @return
	 */
	public Bitmap readBitMap(String fileName) throws FileNotFoundException {

		BitmapFactory.Options opt = new BitmapFactory.Options();
		opt.inPreferredConfig = Bitmap.Config.ARGB_8888;
		opt.inPurgeable = true;
		opt.inInputShareable = true;
//获取资源图片
		File file = new File(fileName);
		InputStream is = new FileInputStream(file);
		Bitmap  bt = BitmapFactory.decodeStream(is,null,opt);
		return bt;

//		int degree = this.readPictureDegree(fileName);
//
//		Matrix matrix = new Matrix();
//		matrix.postRotate(+degree);
//		int width = bt.getWidth();
//		int height = bt.getHeight();
//		Bitmap good = Bitmap.createBitmap(bt, 0, 0, width, height, matrix, true);
//		bt.recycle();
//		System.gc();
//
//		this.outputBitmap(good, fileName+".bt.jpg", 100);
//		return good;
	}
	/**
	 * 给照片添加时间戳水印
	 * @param context
	 * @throws FileNotFoundException
     */
	public Bitmap addTimestampOnPic(Activity context, String photoAbsolutePath, List<String> waterMark) throws FileNotFoundException {
		int photoRotate = this.getBitmapDegree(photoAbsolutePath);
		Log.i("图片", photoRotate+"");
		Bitmap rawBitmap = this.readBitMap(photoAbsolutePath);

		Bitmap dest = this.addTimestampOnPic(context, rawBitmap, waterMark);
		rawBitmap.recycle();
		System.gc();
		return dest;
	}

	public Bitmap addTimestampOnPic(Activity context, Uri uri, List<String> waterMark) throws IOException {
		Bitmap photoBmp = this.getBitmapFormUri(context, uri);
		int degree = getBitmapDegree(new File(uri.getPath()).getAbsolutePath());
		/**
		 * 把图片旋转为正的方向
		 */
		Bitmap fixedBitmap = rotateBitmapByDegree(photoBmp, degree);
//		photoBmp.recycle();
//		System.gc();

		Bitmap dest = this.addTimestampOnPic(context, fixedBitmap, waterMark);
		fixedBitmap.recycle();
		System.gc();

		return dest;
	}

	/**
	 * 将图片按照某个角度进行旋转
	 *
	 * @param bm     需要旋转的图片
	 * @param degree 旋转角度
	 * @return 旋转后的图片
	 */
	public static Bitmap rotateBitmapByDegree(Bitmap bm, int degree) {
		Bitmap returnBm = null;

		// 根据旋转角度，生成旋转矩阵
		Matrix matrix = new Matrix();
		matrix.postRotate(degree);
		try {
			// 将原始图片按照旋转矩阵进行旋转，并得到新的图片
			returnBm = Bitmap.createBitmap(bm, 0, 0, bm.getWidth(), bm.getHeight(), matrix, true);
		} catch (OutOfMemoryError e) {
		}
		if (returnBm == null) {
			returnBm = bm;
		}
		if (bm != returnBm) {
			bm.recycle();
		}
		return returnBm;
	}

	/**
	 * 读取图片的旋转的角度
	 *
	 * @param path 图片绝对路径
	 * @return 图片的旋转角度
	 */
	public static int getBitmapDegree(String path) {
		int degree = 0;
		try {
			// 从指定路径下读取图片，并获取其EXIF信息
			ExifInterface exifInterface = new ExifInterface(path);
			// 获取图片的旋转信息
			int orientation = exifInterface.getAttributeInt(ExifInterface.TAG_ORIENTATION,
					ExifInterface.ORIENTATION_NORMAL);
			switch (orientation) {
				case ExifInterface.ORIENTATION_ROTATE_90:
					degree = 90;
					break;
				case ExifInterface.ORIENTATION_ROTATE_180:
					degree = 180;
					break;
				case ExifInterface.ORIENTATION_ROTATE_270:
					degree = 270;
					break;
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		return degree;
	}


	/**
	 * 通过uri获取图片并进行压缩
	 *
	 * @param uri
	 */
	public Bitmap getBitmapFormUri(Activity ac, Uri uri) throws FileNotFoundException, IOException {
		InputStream input = ac.getContentResolver().openInputStream(uri);
		BitmapFactory.Options onlyBoundsOptions = new BitmapFactory.Options();
		onlyBoundsOptions.inJustDecodeBounds = true;
		onlyBoundsOptions.inDither = true;//optional
		onlyBoundsOptions.inPreferredConfig = Bitmap.Config.ARGB_8888;//optional
		BitmapFactory.decodeStream(input, null, onlyBoundsOptions);
		input.close();
		int originalWidth = onlyBoundsOptions.outWidth;
		int originalHeight = onlyBoundsOptions.outHeight;
		if ((originalWidth == -1) || (originalHeight == -1))
			return null;
		//图片分辨率以480x800为标准
		float hh = 800f;//这里设置高度为800f
		float ww = 480f;//这里设置宽度为480f
		//缩放比。由于是固定比例缩放，只用高或者宽其中一个数据进行计算即可
		int be = 1;//be=1表示不缩放
		if (originalWidth > originalHeight && originalWidth > ww) {//如果宽度大的话根据宽度固定大小缩放
			be = (int) (originalWidth / ww);
		} else if (originalWidth < originalHeight && originalHeight > hh) {//如果高度高的话根据宽度固定大小缩放
			be = (int) (originalHeight / hh);
		}
		if (be <= 0)
			be = 1;
		//比例压缩
		BitmapFactory.Options bitmapOptions = new BitmapFactory.Options();
		bitmapOptions.inSampleSize = be;//设置缩放比例
		bitmapOptions.inDither = true;//optional
		bitmapOptions.inPreferredConfig = Bitmap.Config.ARGB_8888;//optional
		input = ac.getContentResolver().openInputStream(uri);
		Bitmap bitmap = BitmapFactory.decodeStream(input, null, bitmapOptions);
		input.close();

		return compressImage(bitmap);//再进行质量压缩
	}

	/**
	 * 质量压缩方法
	 *
	 * @param image
	 * @return
	 */
	public static Bitmap compressImage(Bitmap image) {

		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		image.compress(Bitmap.CompressFormat.JPEG, 100, baos);//质量压缩方法，这里100表示不压缩，把压缩后的数据存放到baos中
		int options = 100;
		while (baos.toByteArray().length / 1024 > 100) {  //循环判断如果压缩后图片是否大于100kb,大于继续压缩
			baos.reset();//重置baos即清空baos
			//第一个参数 ：图片格式 ，第二个参数： 图片质量，100为最高，0为最差  ，第三个参数：保存压缩后的数据的流
			image.compress(Bitmap.CompressFormat.JPEG, options, baos);//这里压缩options%，把压缩后的数据存放到baos中
			options -= 10;//每次都减少10
		}
		ByteArrayInputStream isBm = new ByteArrayInputStream(baos.toByteArray());//把压缩后的数据baos存放到ByteArrayInputStream中
		Bitmap bitmap = BitmapFactory.decodeStream(isBm, null, null);//把ByteArrayInputStream数据生成图片
		return bitmap;
	}

	/**
	 * 给照片添加时间戳水印
	 * @param context
	 * @throws FileNotFoundException
	 */
	public Bitmap addTimestampOnPic(Activity context, Bitmap rawBitmap , List<String> waterMark) throws FileNotFoundException {
		int photoRotate = 0;
		Bitmap dest = this.drawTextOnBitmap(context, rawBitmap, photoRotate, waterMark);
		return dest;
	}

	public void outputBitmap(Bitmap bitmap, String tsPicFullPath, int percent) throws FileNotFoundException {
		bitmap.compress(Bitmap.CompressFormat.JPEG, percent, new FileOutputStream(new File(tsPicFullPath)));
	}

//	public void outputBitmap(Bitmap bitmap, String tsPicFullPath) throws FileNotFoundException {
//		bitmap.compress(Bitmap.CompressFormat.JPEG, 50, new FileOutputStream(new File(tsPicFullPath)));
//	}

	private Rect getTextRect(String text, Activity activity, int textSize) {
		if (TextUtils.isEmpty(text) || TextUtils.isEmpty(text.trim())) {
			return null;
		}
		TextPaint textPaint = new TextPaint();
		textPaint.setTextSize(textSize);
		Rect rect = new Rect();
		textPaint.getTextBounds(text, 0, text.length(), rect);

		return rect;
	}
	/**
     * 在原bitmap上添加文字水印
     * @param acitvity
     * @param srcBitmap 原图片
     * @param text 索要添加的文字
     * @return
     */
    public Bitmap drawTextOnBitmap(Activity acitvity, Bitmap srcBitmap, int photoRotate, List<String> text) {
		if (srcBitmap == null) {
			return srcBitmap;
		}
		if (null == text || text.size() == 0) {
			return srcBitmap;
		}

		// 定义矩阵对象
		Matrix matrix = new Matrix();
		// 向左旋转（逆时针旋转）45度，参数为正则向右旋转（顺时针旋转）
//		matrix.postRotate(photoRotate);
		matrix.postRotate(0);

		Bitmap mutableBitmap = null;
		Canvas canvas = null;
		if(Build.VERSION.SDK_INT >= 23) {
			/**
			 * android 高版本(6.0/6.0+):
			 * 1. 如果分次create bitmap，recycle 老的bitmap，会报错bitmap已经回收；
			 * 2. 直接new Canvas(bitmap) 会报错immutable bitmap，必须调用copy才能修改；
			 * 3. copy以后，内存不会溢出。
			 */
			mutableBitmap = Bitmap.createBitmap(srcBitmap, 0, 0, srcBitmap.getWidth(), srcBitmap.getHeight(),
					matrix, true).copy(Bitmap.Config.ARGB_8888, true);

		}else{
			/**
			 * android 低版本(4.x):
			 * 1. 如果分次create bitmap，不recycle老的bitmap，会直接报错OOM；
			 * 2. Bitmap.createBitmap.copy操作，会直接报错OOM；
			 * 3. 改成每次创建新的bitmap，recycle 旧的，并且及时gc，OOM错误消失；
			 */
			Bitmap newBmp = Bitmap.createBitmap(srcBitmap, 0, 0, srcBitmap.getWidth(), srcBitmap.getHeight(),
					matrix, true);
			srcBitmap.recycle();
			System.gc();

			mutableBitmap = newBmp.copy(Bitmap.Config.ARGB_8888, true);
			newBmp.recycle();
			System.gc();
		}
		canvas = new Canvas(mutableBitmap);
//        canvas.drawBitmap(newBmp, 0, 0, null);
//		canvas.rotate(photoRotate);
		Paint paint = new Paint();
		paint.setColor(Color.RED);
		canvas.drawLine(0, 0, mutableBitmap.getWidth(), mutableBitmap.getHeight(), paint);

		String familyName = "宋体";
		Typeface font = Typeface.create(familyName, Typeface.NORMAL);
		TextPaint textPaint = new TextPaint();
		textPaint.setAntiAlias(true);
		textPaint.setColor(Color.RED);
		textPaint.setTypeface(font);

		int textSize = mutableBitmap.getHeight()/20;
		textPaint.setTextSize(textSize);

//		int y = 500;
//		int x = 500;
		int margin = 5;

		int srcWidth = mutableBitmap.getWidth();
		int srcHeight = mutableBitmap.getHeight();
		int y = srcHeight - margin;
		for (int index = 0; index < text.size(); index++) {
			Rect textRect = getTextRect(text.get(index), acitvity, textSize);
//			int y = srcHeight - (textRect.height()+margin)*(text.size() - index) - margin;
			y = y - textRect.height() - margin;
			int x = margin;
			canvas.drawText(text.get(index), x, y, textPaint);
		}

		canvas.save(Canvas.ALL_SAVE_FLAG);// 保存
		canvas.restore();// 存储
		return mutableBitmap;
	}
}
