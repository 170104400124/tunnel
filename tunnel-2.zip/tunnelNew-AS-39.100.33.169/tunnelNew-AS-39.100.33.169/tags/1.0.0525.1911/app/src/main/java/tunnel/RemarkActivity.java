package tunnel;

import com.beardedhen.androidbootstrap.BootstrapButton;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

import com.jie.cameraimage.R;
import com.jie.cameraimage.R.id;
import com.jie.cameraimage.R.layout;
import com.jie.cameraimage.R.menu;
import com.tunnel.dao.android.LogImp;
import com.tunnel.dao.android.ProcessConst;
import com.tunnel.model.LogData;
import com.tunnel.model.ProcessData;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.AdapterView.OnItemLongClickListener;
import tunnel.JDBC.DBOpenHelper;
import tunnel.adapter.MainGridViewAdapter;
import tunnel.design.ActivityRunningConfig;
import tunnel.design.DesignInfo;
import tunnel.design.ReflectUtil;
import tunnel.model.Const;
import tunnel.model.ImageModel;
import tunnel.service.NetWorkTask;

public class RemarkActivity extends Activity implements Const, OnClickListener, OnItemClickListener, OnItemLongClickListener {

	private String remarks;
	private String savetime;
	private String uploadtime;
	private String offset;
	private BootstrapButton saveLocal;
	private BootstrapButton uploadServer;

	private EditText txOffset;
	private TextView countTextView;
	private EditText inputEditText;
	private TextView tvPlace;
	private TextView tvRockGrade;

    private boolean isSave;//判断是否保存过本地
    private String firstKey;//首次保存的key值,本地记录传来的key值

	private String tunnelName;
	private String tunnelId;
	private String processName;

	DBOpenHelper dbHelper = new DBOpenHelper(RemarkActivity.this);
	String user_id;
	String key;
	String rock_grade = null;
	String subprocess = null;
	//String footage_id = null;
	ProcessData pd = null;
	//本地记录查看的信息
	private String local_offset;
	private String local_remarks;

    String local_explanation;
    private String processId;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_remark);

        isSave = false;

        Intent intent = getIntent();
        tunnelName = intent.getStringExtra("tunnel");
        processName = intent.getStringExtra("process");

        rock_grade = intent.getStringExtra("rock_grade");
        subprocess = intent.getStringExtra("subprocess");
        //获取本地记录传来的信息
        local_explanation = intent.getStringExtra("explanation");
        firstKey = intent.getStringExtra("key");

        ProcessConst pc = new ProcessConst();
        pd = pc.getProcessData(rock_grade, subprocess);

        processId = pd.getProcess_id();

		initView();
		initData();
	}
	
	private void initView() {
//		findViewById(R.id.main_update_textView).setOnClickListener(this);
		findViewById(R.id.saveLocal).setOnClickListener(this);
		findViewById(R.id.uploadServer).setOnClickListener(this);
		findViewById(R.id.back).setOnClickListener(this);

		txOffset = (EditText) findViewById(R.id.txOffset);
		countTextView = (TextView) findViewById(R.id.main_count_textView);
		saveLocal = (BootstrapButton) findViewById(R.id.saveLocal);
		uploadServer = (BootstrapButton) findViewById(R.id.uploadServer);
		inputEditText = (EditText) findViewById(R.id.main_input_editText);

		tvPlace = (TextView) findViewById(id.place);
		tvRockGrade = (TextView) findViewById(id.rock_grade);

		inputEditText.addTextChangedListener(watcher);
		findViewById(R.id.radio_button0).setOnClickListener(this);
		findViewById(R.id.radio_button1).setOnClickListener(this);
		findViewById(R.id.radio_button2).setOnClickListener(this);
		findViewById(R.id.radio_button3).setOnClickListener(this);
		findViewById(R.id.delete).setOnClickListener(this);
	}

	private void initData() {
		SharedPreferences sp = getSharedPreferences("data", Context.MODE_PRIVATE);
		user_id = sp.getString("user_id", "");
		String txPlace = sp.getString("place", "");
		String strPlace = sp.getString("place", "");
		tunnelId = strPlace;

		key = user_id;

		Intent intent = getIntent();
		tunnelName = intent.getStringExtra("tunnel");
		processName = intent.getStringExtra("process");
		rock_grade = intent.getStringExtra("rock_grade");
		subprocess = intent.getStringExtra("subprocess");
		local_offset = intent.getStringExtra("offset");
		local_remarks = intent.getStringExtra("explanation");
		//footage_id = intent.getStringExtra("footage_id");

		//查询是否为同一个footage
//		String tunnel_grade = null;
//		SQLiteDatabase db = dbHelper.getReadableDatabase();
//		Cursor cursor =	db.rawQuery("select tunnel_grade from design_footage where footage_id = ?",new String[]{footage_id});
//		while(cursor.moveToNext()) {
//			int nameColumnIndex = cursor.getColumnIndex("tunnel_grade");
//			tunnel_grade = cursor.getString(nameColumnIndex);
//		}
//		//将原有的footage_id对应的isFinish设置为1
//		if(!rock_grade.equals(tunnel_grade)) {
//			cursor = db.rawQuery("select tunnel_grade from design_footage where footage_id = ?",new String[]{footage_id});
//			ContentValues cv=new ContentValues();
//			cv.put("isFinish", 1);
//			String whereCaluse = "footage_id=?";
//			String whereArgs[] = new String[]{String.valueOf(footage_id)};
//			db.update("design_footage", cv, whereCaluse, whereArgs);
//			//获取新的footage_id
//			cursor = db.rawQuery("select footage_id from design_footage where isFinish = ? and tunnel_id = ?",new String[]{"0",txPlace});
//			while(cursor.moveToNext()) {
//				int nameColumnIndex = cursor.getColumnIndex("footage_id");
//				footage_id = cursor.getString(nameColumnIndex);
//				if(!footage_id.equals("")) break;
//			}
//		}


		tvPlace.setText(strPlace);
		tvRockGrade.setText(rock_grade);

		if(null != local_remarks && !local_remarks.isEmpty()) {
			inputEditText.setText(local_remarks);
		}
		if(null != local_offset && !local_offset.isEmpty()) {
			txOffset.setText(local_offset);
		}

		ProcessConst pc = new ProcessConst();
		pd = pc.getProcessData(rock_grade, subprocess);

		if(null != firstKey && !firstKey.isEmpty()) {
			isSave = true;
		}
	}

	@Override
	public void onClick(View view) {
		switch (view.getId()) {
		case R.id.saveLocal:
			saveImage();
			break;
		case R.id.uploadServer:
			uploadImage();
			break;
		case R.id.radio_button0:
 			Intent intent = new Intent(RemarkActivity.this, HomeActivity.class);
			startActivity(intent);
			break;
 		case R.id.radio_button1:
 			Intent intent1 = new Intent(RemarkActivity.this, LocalActivity.class);
			startActivity(intent1);
			break;
 		case R.id.radio_button2:
 			Intent intent2 = new Intent(RemarkActivity.this, NoUploadActivity.class);
			startActivity(intent2);
			break;
 		case R.id.radio_button3:
 			Intent intent3 = new Intent(RemarkActivity.this, MeActivity.class);
			startActivity(intent3);
			break;
		case R.id.back:
			RemarkActivity.this.finish();
			break;
		case R.id.delete:
			delete();
		}
	}
	
	
	
	/**
	 * 监控文字变化
	 */
	TextWatcher watcher = new TextWatcher() {
		@Override
		public void onTextChanged(CharSequence s, int start, int before, int count) {
		}
		@Override
		public void beforeTextChanged(CharSequence s, int start, int count, int after) {
		}
		@Override
		public void afterTextChanged(Editable s) {
			// 输入时提示剩余可输入字符长度
			countTextView.setText(500 - inputEditText.getText().toString().length() + "");
		}
	};
	
	public void saveImage(){
		Date currentDate = new Date();
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");// HH:mm:ss
		//获取当前时间
		savetime = simpleDateFormat.format(currentDate);
		offset = txOffset.getText().toString().trim();
		remarks = inputEditText.getText().toString().trim();
		key = user_id + savetime;

		//插入Log表的信息
		LogData logData = new LogData();
		logData.setExplanation(remarks);
		logData.setUser_id(user_id);
		//logData.setFootage_id(footage_id);
		//logData.setTunnel_id(tunnelName);
		logData.setTunnel_id(tunnelId);

//		if(null != pd) {
			logData.setProcess_id(pd.getProcess_id());
//		}else{
//			logData.setProcess_id(rock_grade+ processName);
//		}

		logData.setSave_time(currentDate);
		key = user_id + savetime;
		//logData.setOffset(offset);
		logData.setReport_footage(offset);
		logData.setIsUpload(0);
		//判断是否上传过
		if(null != firstKey && !firstKey.isEmpty()) {
			SQLiteDatabase db = dbHelper.getWritableDatabase();
			String sql = "select * from log where isUpload=? and key = ?";//从哪一个位置    请求多少条
			Cursor cursor = db.rawQuery(sql, new String[]{"1", firstKey});
			if (cursor.moveToNext()) {
				int nameColumnIndex = cursor.getColumnIndex("key");
				key = cursor.getString(nameColumnIndex);
				logData.setIsUpload(1);
			}
		}
		logData.setKey(key);
//		new LogImp(RemarkActivity.this).insertRemark(logData);
        if(!isSave) {
            new LogImp(RemarkActivity.this).insert(logData);
            isSave = true;
            firstKey = key;
        } else {
            new LogImp(RemarkActivity.this).update(logData, firstKey);
        }

		Toast.makeText(this, "信息已保存本地", Toast.LENGTH_SHORT).show();
    }

	//线程上传图片
    private void uploadImage() {
    	Date currentDate = new Date();
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");// HH:mm:ss
		//获取当前时间
		uploadtime = simpleDateFormat.format(currentDate);
    	String isUpload = "1";
    	if(key.equals(user_id)) {
    		Toast.makeText(this, "请先将信息保存本地再上传", Toast.LENGTH_SHORT).show();
    		return;
    	}
        NetWorkTask networkTask = new NetWorkTask();
    	networkTask.setContext(RemarkActivity.this);
        networkTask.execute("", user_id, offset,tunnelId, processId, firstKey, uploadtime, isUpload ,remarks, savetime);
    }
	
	@Override
	public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
		// TODO Auto-generated method stub
		
	}


	public void delete() {
		if(null == firstKey ||  firstKey.equals("")) {
			Toast.makeText(this, "该记录未保存，无法删除", Toast.LENGTH_SHORT).show();
			return;
		}
		final AlertDialog.Builder normalDialog =
				new AlertDialog.Builder(RemarkActivity.this);
		normalDialog.setTitle("隧道施工系统");
		normalDialog.setMessage("删除本地记录（若记录已成功上传，服务器中记录不会删除），是否删除?");
		normalDialog.setPositiveButton("确定",
				new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface dialog, int which) {
						SQLiteDatabase db = dbHelper.getWritableDatabase();
						String whereCaluse = "key=?";
						String whereArgs[] = new String[]{String.valueOf(firstKey)};
						db.delete("log",whereCaluse ,whereArgs);
						Intent intent = new Intent(RemarkActivity.this, LocalActivity.class);
						startActivityForResult(intent, 1);
					}
				});
		normalDialog.setNegativeButton("取消",
				new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface dialog, int which) {
						return;
					}
				});
		// 显示
		normalDialog.show();
	}
}