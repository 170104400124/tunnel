package tunnel.service;

import java.io.File;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.widget.Toast;
import tunnel.MainActivity;
import tunnel.JDBC.DBOpenHelper;
import tunnel.NoUploadActivity;

public class NetWorkTask extends AsyncTask<String, Integer, String> {
	// 这里就是JavaWeb服务器地址，servlet
	    //private final String ServerURL="http://192.168.1.102:8080/tunnel/ImgServlet";
	 //private final String ServerURL="http://172.27.62.201:8080/tunnel/ImgServlet";
	//private final String ServerURL="http://172.27.61.131:8080/tunnel/ImgServlet";
	private final String ServerURL="http://121.43.185.110:8080/tunnel/ImgServlet";
	//验证是否返回200，"1"代表SUCCESS,上传成功,"0"代表未上传成功
	public String upload = "0";
	public NetWorkTask() {
		super();
	}
	@Override
	    protected void onPreExecute() {
	    	super.onPreExecute();
	    }

	Activity context = null;
	Handler handler = null;

	public void setContext(Activity context) {
		this.context = context;
	}

	public void setHandler(Handler h) {
		this.handler = h;
	}

	String[] inner_params = null;
	    @Override
	    protected String doInBackground(String... params) {
			inner_params = params;
//	        return doPost(params[0]);
	        String uri = (params[0]);
	        if(null == uri) {
				Log.i("uri", uri);
			}else {
				Log.i("uri", uri);
			}
	        System.out.println("url!!!!!!!!" + uri);
	        String user_id = (params[1]);
	        String offset = (params[2]);
	        String tunnelName = (params[3]);
	        String processName = (params[4]);
	        String key = (params[5]);
	        String uploadtime = (params[6]);
	        int isUpload =  Integer.parseInt(params[7]);
	        String remarks = (params[8]);
	        String savetime = (params[9]);
	        if(null == uri || uri.trim().length()==0) {
	        	upload = UploadUtil.uploadFile(null, user_id, offset, tunnelName, processName, key, uploadtime, isUpload ,remarks, savetime, ServerURL);
	        	return upload;
	        }
	        Uri u=Uri.parse((String) uri);
	        File file = new File(u.getPath());
	        upload = UploadUtil.uploadFile(file, user_id,offset, tunnelName, processName, key, uploadtime, isUpload ,remarks, savetime, ServerURL);
	        return upload;
	    }
	    @Override
	    protected void onPostExecute(String result) {
	        if (UploadUtil.SUCCESS.equalsIgnoreCase(result)) {
				DBOpenHelper dbHelper = new DBOpenHelper(this.context);
				SQLiteDatabase db = dbHelper.getReadableDatabase();
				db = dbHelper.getReadableDatabase();
				ContentValues cv = new ContentValues();
				cv.put("isUpload","1");
				String whereCaluse = "key=?";
				String key = (this.inner_params[5]);
				String whereArgs[] = new String[]{key};
				db.update("log", cv, whereCaluse, whereArgs);
				db.close() ;
				Toast.makeText(this.context, "信息上传成功",Toast.LENGTH_SHORT).show();

				if(null == handler) {
					Log.e("null == handler", "没法给Activity 发送刷新消息");
				}else {
					Message msg = new Message();
					msg.what = Integer.valueOf(UploadUtil.SUCCESS);
					handler.sendMessage(msg);
				}
				return;
	        } else {
	            Log.i("上传结果", "上传失败");
				Toast.makeText(this.context, "上传失败",Toast.LENGTH_SHORT).show();
	        }
	    }
	}
