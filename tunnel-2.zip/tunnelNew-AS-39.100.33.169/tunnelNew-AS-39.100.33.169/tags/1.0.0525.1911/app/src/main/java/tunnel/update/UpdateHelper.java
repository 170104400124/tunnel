package tunnel.update;

import android.app.Activity;
import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.util.Log;
import android.widget.Toast;

import com.vector.update_app.UpdateAppBean;
import com.vector.update_app.UpdateAppManager;
import com.vector.update_app.UpdateCallback;

public class UpdateHelper {
//    {
//        "update": "Yes",
//            "new_version": "2.0",
//            "apk_file_url": "http://192.168.1.4:8080/app.20190518.apk",
//            "update_log": "test",
//            "target_size": "5M",
//            "new_md5":"A818AD325EACC199BC62C552A32C35F2",
//            "constraint": false
//    }
//	String mUpdateUrl = "http://192.168.1.4:8080/update.jsp";
    String mUpdateUrl = "http://121.43.185.110:8080/appupdate/update.jsp";
    Activity context = null;
    public UpdateHelper(Activity act) {
        this.context = act;
    }
    public void checkUpdate() {
        new UpdateAppManager
                .Builder()
                //当前Activity
                .setActivity(context)
                //更新地址
                .setUpdateUrl(mUpdateUrl)
                //实现httpManager接口的对象
                .setHttpManager(new UpdateAppHttpUtil())
                .build()
                .checkNewApp(new UpdateCallback() {
                    protected void hasNewApp(UpdateAppBean updateApp, UpdateAppManager updateAppManager) {
                        // 这里检查版本，签名等信息，确认无误，再更新
                        String localVersionName = getLocalVersionName(context);
                        Toast.makeText(context, localVersionName, Toast.LENGTH_SHORT).show();
                        // 版本一致，跳过
                        if(localVersionName.equals(updateApp.getNewVersion())) {
                            return;
                        }
                        String[] localVs = localVersionName.split("\\.");
                        String[] serverVs = updateApp.getNewVersion().split("\\.");
                        if(localVs.length != serverVs.length){
                            // 版本号格式不一致，强制更新
                        }else {
                            boolean hasNewVersion = false;
                            for (int index = 0; index < localVs.length; index++) {
                                int li = Integer.valueOf(localVs[index]);
                                int si = Integer.valueOf(serverVs[index]);
                                if (li < si) {
                                    hasNewVersion = true;
                                    break;
                                }
                            }
                            if(!hasNewVersion) {
                                return;
                            }
                        }

                        // 服务器版本比本地新
                        updateAppManager.showDialogFragment();
                    }
                });
    }


    public String getLocalVersionName(Context context) {
        // 检查版本号
        try {
            PackageManager pm = context.getPackageManager();
            PackageInfo packageInfo = pm.getPackageInfo(context.getPackageName(), 0);
            String versionName = packageInfo.versionName;
            return versionName;
        } catch (PackageManager.NameNotFoundException e) {
            Log.e("版本显示错误", e.getMessage());
        }
        return null;
    }
}
