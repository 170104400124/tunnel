package com.tunnel.dao.android;

import com.tunnel.model.ProcessData;

import java.util.Map;
import java.util.TreeMap;

/**
 * process 相关常量
 * Created by Leon on 2019/5/6.
 */

public class ProcessConst {
    public static final String V_PLUS_ROCK_GRADE = "V+";
    public static final String V_ROCK_GRADE = "V";
    public static final String IV_ROCK_GRADE = "IV";
    public static final String III_ROCK_GRADE = "III";
    public static final String II_ROCK_GRADE = "II";
    public static final String ZHANG_ZI_MIAN = "掌子面";

    public static final String SUB_XIAO_DAO_GUAN_AN_ZHUANG = "小导管安装";
    public static final String SUB_XIAO_DAO_GUAN_ZHU_JIANG = "小导管注浆";
    public static final String SUB_GUAN_PENG_CHEN_PING = "管棚成品";
    public static final String SUB_GUAN_PENG_AN_ZHUANG = "管棚安装";
    public static final String SUB_GUAN_PENG_ZHU_JIANG = "管棚注浆";
    public static final String SUB_XIAO_CHAO_QIAN_ZUAN_TAN = "超前钻孔";
    public static final String SUB_XIAO_ZHI_LI_GANG_GONG_JIA = "支立钢拱架";
    public static final String SUB_XIAO_MAO_GAN = "锚杆";
    public static final String SUB_XIAO_GUA_WANG = "挂网";
    public static final String SUB_XIAO_MAO_PENG = "锚喷";
    public static final String SUB_ZONG_JIN_CHI_SHU = "进尺数";

    public static final String SUB_WEI_YAN_BIAN_GENG = "围岩变更";

    public boolean initData() {
        this.add2Index(ProcessConst.V_PLUS_ROCK_GRADE, ProcessConst.SUB_XIAO_DAO_GUAN_AN_ZHUANG, "Ø42X3无缝钢管，长4m，间距400mm，角度10~20度。");
        this.add2Index(ProcessConst.V_PLUS_ROCK_GRADE, ProcessConst.SUB_XIAO_DAO_GUAN_ZHU_JIANG, "注浆压力1.0~1.5MPa，可根据实测隧道水压等情况适当调整。");
        this.add2Index(ProcessConst.V_PLUS_ROCK_GRADE, ProcessConst.SUB_GUAN_PENG_CHEN_PING, "Ø89X4.5无缝钢管，钢管外插角2度。");
        this.add2Index(ProcessConst.V_PLUS_ROCK_GRADE, ProcessConst.SUB_GUAN_PENG_AN_ZHUANG, "无");
        this.add2Index(ProcessConst.V_PLUS_ROCK_GRADE, ProcessConst.SUB_GUAN_PENG_ZHU_JIANG, "注浆压力0.3~0.7MPa，可根据实际情况适当调整。");
        this.add2Index(ProcessConst.V_PLUS_ROCK_GRADE, ProcessConst.SUB_XIAO_CHAO_QIAN_ZUAN_TAN, "3孔偏角超前钻探法，超前探测20m，探孔分布在两边底部和拱顶，若发现涌水，需施做中间的4个探水孔；利用炮眼加深超前钻探6m。");
        this.add2Index(ProcessConst.V_PLUS_ROCK_GRADE, ProcessConst.SUB_XIAO_ZHI_LI_GANG_GONG_JIA, "采用12工字钢，间距1m/榀，可根据围岩破碎及沉降情况加密至0.6~0.8m/榀。工字钢架纵向筋为Ø18，间距0.8m。锁脚锚杆长度2m。");
        this.add2Index(ProcessConst.V_PLUS_ROCK_GRADE, ProcessConst.SUB_XIAO_MAO_GAN, "Ø 22锚杆，长度2.5m，间距1.0m，呈梅花型布置；");
        this.add2Index(ProcessConst.V_PLUS_ROCK_GRADE, ProcessConst.SUB_XIAO_GUA_WANG, "直径6钢筋，网格尺寸为20cm×20cm；锚杆垫板采用Q235B钢，厚度6mm，M16螺母紧固至洞壁。");
        this.add2Index(ProcessConst.V_PLUS_ROCK_GRADE, ProcessConst.SUB_XIAO_MAO_PENG, "喷射C25混凝土，厚度150mm。");
        this.add2Index(ProcessConst.V_PLUS_ROCK_GRADE, ProcessConst.SUB_ZONG_JIN_CHI_SHU, "");


        this.add2Index(ProcessConst.V_ROCK_GRADE, ProcessConst.SUB_XIAO_DAO_GUAN_AN_ZHUANG, "Ø42X3无缝钢管，长4m，间距400mm，角度10~20度。");
        this.add2Index(ProcessConst.V_ROCK_GRADE, ProcessConst.SUB_XIAO_DAO_GUAN_ZHU_JIANG, "注浆压力1.0~1.5MPa，可根据实测隧道水压等情况适当调整。");
        this.add2Index(ProcessConst.V_ROCK_GRADE, ProcessConst.SUB_GUAN_PENG_CHEN_PING, "Ø89X4.5无缝钢管，钢管外插角2度。");
        this.add2Index(ProcessConst.V_ROCK_GRADE, ProcessConst.SUB_GUAN_PENG_AN_ZHUANG, "无");
        this.add2Index(ProcessConst.V_ROCK_GRADE, ProcessConst.SUB_GUAN_PENG_ZHU_JIANG, "注浆压力0.3~0.7MPa，可根据实际情况适当调整。");
        this.add2Index(ProcessConst.V_ROCK_GRADE, ProcessConst.SUB_XIAO_CHAO_QIAN_ZUAN_TAN, "3孔偏角超前钻探法，超前探测20m，探孔分布在两边底部和拱顶，若发现涌水，需施做中间的4个探水孔；利用炮眼加深超前钻探6m。");
        this.add2Index(ProcessConst.V_ROCK_GRADE, ProcessConst.SUB_XIAO_ZHI_LI_GANG_GONG_JIA, "采用10工字钢，间距1m/榀，可根据围岩破碎及沉降情况加密至0.6~0.8m/榀。工字钢架纵向筋为Ø18，间距0.8m。锁脚锚杆长度2m。");
        this.add2Index(ProcessConst.V_ROCK_GRADE, ProcessConst.SUB_XIAO_MAO_GAN, "Ø 22锚杆，长度2.5m，间距1.0m，呈梅花型布置；");
        this.add2Index(ProcessConst.V_ROCK_GRADE, ProcessConst.SUB_XIAO_GUA_WANG, "直径6钢筋，网格尺寸为20cm×20cm；锚杆垫板采用Q235B钢，厚度6mm，M16螺母紧固至洞壁。");
        this.add2Index(ProcessConst.V_ROCK_GRADE, ProcessConst.SUB_XIAO_MAO_PENG, "喷射C25混凝土，厚度150mm。");
        this.add2Index(ProcessConst.V_ROCK_GRADE, ProcessConst.SUB_ZONG_JIN_CHI_SHU, "");

        this.add2Index(ProcessConst.IV_ROCK_GRADE, ProcessConst.SUB_XIAO_DAO_GUAN_AN_ZHUANG, "无");
        this.add2Index(ProcessConst.IV_ROCK_GRADE, ProcessConst.SUB_XIAO_DAO_GUAN_ZHU_JIANG, "无");
        this.add2Index(ProcessConst.IV_ROCK_GRADE, ProcessConst.SUB_GUAN_PENG_CHEN_PING, "无");
        this.add2Index(ProcessConst.IV_ROCK_GRADE, ProcessConst.SUB_GUAN_PENG_ZHU_JIANG, "无");
        this.add2Index(ProcessConst.IV_ROCK_GRADE, ProcessConst.SUB_XIAO_CHAO_QIAN_ZUAN_TAN, "3孔偏角超前钻探法，超前探测20m，探孔分布在两边底部和拱顶，若发现涌水，需施做中间的4个探水孔；利用炮眼加深超前钻探6m。");
        this.add2Index(ProcessConst.IV_ROCK_GRADE, ProcessConst.SUB_XIAO_ZHI_LI_GANG_GONG_JIA, "采用10工字钢，间距1m/榀，可根据围岩破碎及沉降情况加密至0.6~0.8m/榀。工字钢架纵向筋为Ø18，间距0.8m。锁脚锚杆长度2m。");
        this.add2Index(ProcessConst.IV_ROCK_GRADE, ProcessConst.SUB_XIAO_MAO_GAN, "Ø 22锚杆，长度2.0m，间距1.2m，呈梅花型布置；");
        this.add2Index(ProcessConst.IV_ROCK_GRADE, ProcessConst.SUB_XIAO_GUA_WANG, "直径6钢筋，网格尺寸为25cm×25cm；锚杆垫板采用Q235B钢，厚度6mm，M16螺母紧固至洞壁。");
        this.add2Index(ProcessConst.IV_ROCK_GRADE, ProcessConst.SUB_XIAO_MAO_PENG, "喷射C25混凝土，厚度100mm。");
        this.add2Index(ProcessConst.IV_ROCK_GRADE, ProcessConst.SUB_ZONG_JIN_CHI_SHU, "");

        this.add2Index(ProcessConst.III_ROCK_GRADE, ProcessConst.SUB_XIAO_DAO_GUAN_AN_ZHUANG, "无");
        this.add2Index(ProcessConst.III_ROCK_GRADE, ProcessConst.SUB_XIAO_DAO_GUAN_ZHU_JIANG, "无");
        this.add2Index(ProcessConst.III_ROCK_GRADE, ProcessConst.SUB_GUAN_PENG_CHEN_PING, "无");
        this.add2Index(ProcessConst.III_ROCK_GRADE, ProcessConst.SUB_GUAN_PENG_ZHU_JIANG, "无");
        this.add2Index(ProcessConst.III_ROCK_GRADE, ProcessConst.SUB_XIAO_CHAO_QIAN_ZUAN_TAN, "3孔偏角超前钻探法，超前探测20m，探孔分布在两边底部和拱顶，若发现涌水，需施做中间的4个探水孔；利用炮眼加深超前钻探6m。");
        this.add2Index(ProcessConst.III_ROCK_GRADE, ProcessConst.SUB_XIAO_ZHI_LI_GANG_GONG_JIA, "无");
        this.add2Index(ProcessConst.III_ROCK_GRADE, ProcessConst.SUB_XIAO_MAO_GAN, "Ø 22锚杆，长度2.0m，环向间距1.2m，纵向间距1.5m；");
        this.add2Index(ProcessConst.III_ROCK_GRADE, ProcessConst.SUB_XIAO_GUA_WANG, "直径6钢筋，网格尺寸为25cm×25cm；锚杆垫板采用Q235B钢，厚度6mm，M16螺母紧固至洞壁。");
        this.add2Index(ProcessConst.III_ROCK_GRADE, ProcessConst.SUB_XIAO_MAO_PENG, "喷射C25混凝土，厚度100mm。");
        this.add2Index(ProcessConst.III_ROCK_GRADE, ProcessConst.SUB_ZONG_JIN_CHI_SHU, "");

        this.add2Index(ProcessConst.II_ROCK_GRADE, ProcessConst.SUB_XIAO_DAO_GUAN_AN_ZHUANG, "无");
        this.add2Index(ProcessConst.II_ROCK_GRADE, ProcessConst.SUB_XIAO_DAO_GUAN_ZHU_JIANG, "无");
        this.add2Index(ProcessConst.II_ROCK_GRADE, ProcessConst.SUB_GUAN_PENG_CHEN_PING, "无");
        this.add2Index(ProcessConst.II_ROCK_GRADE, ProcessConst.SUB_GUAN_PENG_ZHU_JIANG, "无");
        this.add2Index(ProcessConst.II_ROCK_GRADE, ProcessConst.SUB_XIAO_CHAO_QIAN_ZUAN_TAN, "无");
        this.add2Index(ProcessConst.II_ROCK_GRADE, ProcessConst.SUB_XIAO_ZHI_LI_GANG_GONG_JIA, "局部破碎段、渗流较大地段设锚杆、钢筋网，参照Ⅲ级围岩支护设置。（采用12工字钢，间距1m/榀，可根据围岩破碎及沉降情况加密至0.6~0.8m/榀。工字钢架纵向筋为Ø18，间距0.8m。锁脚锚杆长度2m。）");
        this.add2Index(ProcessConst.II_ROCK_GRADE, ProcessConst.SUB_XIAO_MAO_GAN, "局部破碎段、渗流较大地段设锚杆、钢筋网，参照Ⅲ级围岩支护设置。（Ø 22锚杆，长度2.0m，环向间距1.2m，纵向间距1.5m；）");
        this.add2Index(ProcessConst.II_ROCK_GRADE, ProcessConst.SUB_XIAO_GUA_WANG, "局部破碎段、渗流较大地段设锚杆、钢筋网，参照Ⅲ级围岩支护设置。（直径6钢筋，网格尺寸为25cm×25cm；锚杆垫板采用Q235B钢，厚度6mm，M16螺母紧固至洞壁。）");
        this.add2Index(ProcessConst.II_ROCK_GRADE, ProcessConst.SUB_XIAO_MAO_PENG, "喷射C25混凝土厚度80mm，局部破碎段、渗流较大地段设锚杆、钢筋网，参照Ⅲ级围岩支护设置。");
        this.add2Index(ProcessConst.II_ROCK_GRADE, ProcessConst.SUB_ZONG_JIN_CHI_SHU, "");

        this.add2Index(ProcessConst.ZHANG_ZI_MIAN, ProcessConst.SUB_WEI_YAN_BIAN_GENG, "");
        return true;
    }

    Map<String, Map<String, ProcessData>> processMap = null;
    private void add2Index(String rockGrade, String subProcess, String requirement ) {
        Map<String, ProcessData> sub2Process = processMap.get(rockGrade);
        if(null == sub2Process) {
            sub2Process = new TreeMap<String, ProcessData>();
            this.processMap.put(rockGrade, sub2Process);
        }
        ProcessData data = sub2Process.get(subProcess);
        if(null == data) {
            data = new ProcessData();
            sub2Process.put(subProcess, data);
        }
        data.setRock_grade(rockGrade);
        data.setSubprocess(subProcess);
        data.setRequirement(requirement);

        String rawKey = data.getRock_grade() + data.getSubprocess();
        try{
            data.setProcess_id(getSign(rawKey.getBytes("UTF-8")));
        }catch (Exception e) {
            e.printStackTrace();
        }
    }

    public String getSign(byte[] rawKey) {
//		try{
//			messageDigest = MessageDigest.getInstance("MD5");
//			messageDigest.reset();
//			messageDigest.update(rawKey.getBytes("UTF-8"));
//		}catch (Exception e) {
//			e.printStackTrace();
//		}
        return new String(rawKey);
    }

    /**
     * 根据主流程/子流程，查询对应的ProcessData 对象
     * @param rockGrade
     * @param subProcess
     */
    public ProcessData getProcessData(String rockGrade, String subProcess) {
        if(null == processMap) {
            processMap = new TreeMap<String, Map<String, ProcessData>>();
            this.initData();
        }
        Map<String, ProcessData> sub2Process = processMap.get(rockGrade);
        if(null == sub2Process) {
            throw new RuntimeException("null == sub2Process");
        }
        ProcessData data = sub2Process.get(subProcess);
        if(null == data) {
            throw new RuntimeException("null == data");
        }
        return data;
    }
}
