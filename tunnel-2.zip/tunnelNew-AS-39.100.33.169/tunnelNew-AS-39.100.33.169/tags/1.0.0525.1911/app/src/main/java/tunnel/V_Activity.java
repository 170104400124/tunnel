package tunnel;

import com.beardedhen.androidbootstrap.BootstrapButton;
import com.google.gson.Gson;
import com.jie.cameraimage.R;
import com.tunnel.dao.android.ProcessConst;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.*;

import tunnel.JDBC.DBOpenHelper;
import tunnel.design.ActivityRunningConfig;
import tunnel.design.DesignInfo;
import tunnel.design.DesignInfo_V_plus;

public class V_Activity extends Activity {

    BootstrapButton xiaodaoguan;
    BootstrapButton daoguanzhujiang;
    BootstrapButton zuankong;
    BootstrapButton maopen;
    BootstrapButton maogan;
    BootstrapButton guanpengchengpin;
    BootstrapButton guanpenganzhuang;
    BootstrapButton guanpengzhujiang;
    BootstrapButton guanpeng;
    BootstrapButton daoguananzhuang;
    BootstrapButton guawang;
    BootstrapButton gongjia;
    BootstrapButton V_shuoming;
	Button back;
	RadioButton btnHome;
	RadioButton btnLocal;
	RadioButton btnUpload;
	RadioButton btnMe;
	TextView place;
    TextView tvRockGrade;
	String footage_id;
	DBOpenHelper dbHelper = new DBOpenHelper(V_Activity.this);


	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_v_);
		
        daoguanzhujiang = (BootstrapButton) findViewById(R.id.daoguanzhujiang);
        zuankong = (BootstrapButton) findViewById(R.id.zuankong);
        maopen = (BootstrapButton) findViewById(R.id.maopen);
        maogan = (BootstrapButton) findViewById(R.id.maogan);
        guanpengchengpin = (BootstrapButton) findViewById(R.id.guanpengchengpin);
        guanpenganzhuang = (BootstrapButton) findViewById(R.id.guanpenganzhuang);
        guanpengzhujiang = (BootstrapButton) findViewById(R.id.guanpengzhujiang);
        daoguananzhuang = (BootstrapButton) findViewById(R.id.daoguananzhuang);
		btnHome = (RadioButton) findViewById(R.id.radio_button0);
		btnLocal = (RadioButton) findViewById(R.id.radio_button1);
		btnUpload = (RadioButton) findViewById(R.id.radio_button2);
		btnMe = (RadioButton) findViewById(R.id.radio_button3);
		back = (Button) findViewById(R.id.back);
        guawang = (BootstrapButton) findViewById(R.id.guawang);
        gongjia = (BootstrapButton) findViewById(R.id.gongjia);
        V_shuoming = (BootstrapButton) findViewById(R.id.V_shuoming);
		place = (TextView) findViewById(R.id.place);
        tvRockGrade = (TextView) findViewById(R.id.rock_grade);
		
		SharedPreferences sp = getSharedPreferences("data", Context.MODE_PRIVATE);
		final String txPlace = sp.getString("place", "");

		
		// 首先获取到意图对象
		Intent intent = getIntent();

		// 获取到传递过来的姓名
		final String tunnel = intent.getStringExtra("tunnel");
		//查询应该填写进尺数的process_id
		SQLiteDatabase db = dbHelper.getReadableDatabase();
		Cursor cursor =	db.rawQuery("select footage_id from design_footage where isFinish = ? and tunnel_id = ?",new String[]{"0",txPlace});
		while(cursor.moveToNext()) {
			int nameColumnIndex = cursor.getColumnIndex("footage_id");
			footage_id = cursor.getString(nameColumnIndex);
			if(null != footage_id) break;
		}
		SharedPreferences.Editor editor = sp.edit();
		editor.putString("footage_id", footage_id);
		place.setText(txPlace);
		//footage_id = intent.getStringExtra("footage_id");

        tvRockGrade.setText(intent.getStringExtra("rock_grade"));
		// 获取到传递过来的图片
		//Bitmap bitmap = intent.getParcelableExtra("pic");
		
//		 zuankong.setOnClickListener(new View.OnClickListener() {
//				
//			 @Override
//				public void onClick(View v) {
//					// TODO Auto-generated method stub
//					Intent intent = new Intent(V_Activity.this, MainActivity.class);
//					DesignInfo di = new DesignInfo_V_plus();
//					Gson gson = new Gson();
//					String diJson = gson.toJson(di);
//					intent.putExtra("design_info", diJson);
//					intent.putExtra("tunnel", tunnel);
//					intent.putExtra("process", "超前钻孔");
//
//					// 设置按钮路径-- Level_1
//					ActivityRunningConfig.getInstance().setButtonPathLevel_1(DesignInfo.CHAO_QIAN_ZUAN_TAN);
//
//					//Intent intent = new Intent(V_Activity.this, V_zuankongActivity.class);
//					startActivityForResult(intent, 1);
//				}
//			});

		btnHome.setOnClickListener(new View.OnClickListener() {
			
			public void onClick(View v) {
				Intent intent = new Intent(V_Activity.this, HomeActivity.class);
				startActivity(intent);
			}
		});
		btnLocal.setOnClickListener(new View.OnClickListener() {
			
			public void onClick(View v) {
				Intent intent = new Intent(V_Activity.this, LocalActivity.class);
				startActivity(intent);
			}
		});
		btnUpload.setOnClickListener(new View.OnClickListener() {
			
			public void onClick(View v) {
				Intent intent = new Intent(V_Activity.this, NoUploadActivity.class);
				startActivity(intent);
			}
		});
		btnMe.setOnClickListener(new View.OnClickListener() {
			
			public void onClick(View v) {
				Intent intent = new Intent(V_Activity.this, MeActivity.class);
				startActivity(intent);
			}
		});

		 maopen.setOnClickListener(new View.OnClickListener() {
				
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					Intent intent = new Intent(V_Activity.this, MainActivity.class);
					DesignInfo di = new DesignInfo_V_plus();
					Gson gson = new Gson();
					String diJson = gson.toJson(di);
					intent.putExtra("design_info", diJson);
					intent.putExtra("tunnel", tunnel);
					intent.putExtra("process", "锚喷");

					String rock_grade = getIntent().getStringExtra("rock_grade");
					intent.putExtra("rock_grade", rock_grade);
					intent.putExtra("subprocess", ProcessConst.SUB_XIAO_MAO_PENG);

					// 设置按钮路径-- Level_1
					ActivityRunningConfig.getInstance().setButtonPathLevel_1(DesignInfo.MAO_PENG);

					//Intent intent = new Intent(V_Activity.this, V_zuankongActivity.class);
					startActivityForResult(intent, 1);
				}
			});
		 
		 daoguanzhujiang.setOnClickListener(new View.OnClickListener() {
				
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					Intent intent = new Intent(V_Activity.this, MainActivity.class);
					DesignInfo di = new DesignInfo_V_plus();
					Gson gson = new Gson();
					String diJson = gson.toJson(di);
					intent.putExtra("design_info", diJson);
					intent.putExtra("tunnel", tunnel);
					intent.putExtra("process", "小导管注浆");

					String rock_grade = getIntent().getStringExtra("rock_grade");
					intent.putExtra("rock_grade", rock_grade);
					intent.putExtra("subprocess", ProcessConst.SUB_XIAO_DAO_GUAN_ZHU_JIANG);

					// 设置按钮路径-- Level_1
					ActivityRunningConfig.getInstance().setButtonPathLevel_1(DesignInfo.XIAO_DAO_GUAN_ZHU_JIANG);

					//Intent intent = new Intent(V_Activity.this, V_zuankongActivity.class);
					startActivityForResult(intent, 1);
				}
			});
		 
		 daoguananzhuang.setOnClickListener(new View.OnClickListener() {
				
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					Intent intent = new Intent(V_Activity.this, MainActivity.class);
					DesignInfo di = new DesignInfo_V_plus();
					Gson gson = new Gson();
					String diJson = gson.toJson(di);
					intent.putExtra("design_info", diJson);
					intent.putExtra("tunnel", tunnel);
					intent.putExtra("process", "小导管安装");

					String rock_grade = getIntent().getStringExtra("rock_grade");
					intent.putExtra("rock_grade", rock_grade);
					intent.putExtra("subprocess", ProcessConst.SUB_XIAO_DAO_GUAN_AN_ZHUANG);

					// 设置按钮路径-- Level_1
					ActivityRunningConfig.getInstance().setButtonPathLevel_1(DesignInfo.CHAO_QIAN_XIAO_DAO_GUAN);

					//Intent intent = new Intent(V_Activity.this, V_zuankongActivity.class);
					startActivityForResult(intent, 1);
				}
			});
		 
		 guanpengchengpin.setOnClickListener(new View.OnClickListener() {
				
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					Intent intent = new Intent(V_Activity.this, MainActivity.class);
					DesignInfo di = new DesignInfo_V_plus();
					Gson gson = new Gson();
					String diJson = gson.toJson(di);
					intent.putExtra("design_info", diJson);
					intent.putExtra("tunnel", tunnel);
					intent.putExtra("process", "管棚成品");

					String rock_grade = getIntent().getStringExtra("rock_grade");
					intent.putExtra("rock_grade", rock_grade);
					intent.putExtra("subprocess", ProcessConst.SUB_GUAN_PENG_CHEN_PING);

					// 设置按钮路径-- Level_1
					ActivityRunningConfig.getInstance().setButtonPathLevel_1(DesignInfo.CHAO_QIAN_GUAN_PENG_CHEN_PING);

					//Intent intent = new Intent(V_Activity.this, V_zuankongActivity.class);
					startActivityForResult(intent, 1);
				}
			});
		 
		 guanpengzhujiang.setOnClickListener(new View.OnClickListener() {
				
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					Intent intent = new Intent(V_Activity.this, MainActivity.class);
					DesignInfo di = new DesignInfo_V_plus();
					Gson gson = new Gson();
					String diJson = gson.toJson(di);
					intent.putExtra("design_info", diJson);
					intent.putExtra("tunnel", tunnel);
					intent.putExtra("process", "管棚注浆");

					String rock_grade = getIntent().getStringExtra("rock_grade");
					intent.putExtra("rock_grade", rock_grade);
					intent.putExtra("subprocess", ProcessConst.SUB_GUAN_PENG_ZHU_JIANG);

					// 设置按钮路径-- Level_1
					ActivityRunningConfig.getInstance().setButtonPathLevel_1(DesignInfo.CHAO_QIAN_GUAN_PENG_ZHU_JIANG);

					//Intent intent = new Intent(V_Activity.this, V_zuankongActivity.class);
					startActivityForResult(intent, 1);
				}
			});
		 
		 gongjia.setOnClickListener(new View.OnClickListener() {
				
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					Intent intent = new Intent(V_Activity.this, MainActivity.class);
					DesignInfo di = new DesignInfo_V_plus();
					Gson gson = new Gson();
					String diJson = gson.toJson(di);
					intent.putExtra("design_info", diJson);
					intent.putExtra("tunnel", tunnel);
					intent.putExtra("process", "支立钢拱架");

					String rock_grade = getIntent().getStringExtra("rock_grade");
					intent.putExtra("rock_grade", rock_grade);
					intent.putExtra("subprocess", ProcessConst.SUB_XIAO_ZHI_LI_GANG_GONG_JIA);

					// 设置按钮路径-- Level_1
					ActivityRunningConfig.getInstance().setButtonPathLevel_1(DesignInfo.ZHI_LI_GANG_GONG_JIA);

					//Intent intent = new Intent(V_Activity.this, V_zuankongActivity.class);
					startActivityForResult(intent, 1);
				}
			});
		 
		 guanpenganzhuang.setOnClickListener(new View.OnClickListener() {
				
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					Intent intent = new Intent(V_Activity.this, MainActivity.class);
					DesignInfo di = new DesignInfo_V_plus();
					Gson gson = new Gson();
					String diJson = gson.toJson(di);
					intent.putExtra("design_info", diJson);
					intent.putExtra("tunnel", tunnel);
					intent.putExtra("process", "管棚安装");

					String rock_grade = getIntent().getStringExtra("rock_grade");
					intent.putExtra("rock_grade", rock_grade);
					intent.putExtra("subprocess", ProcessConst.SUB_GUAN_PENG_AN_ZHUANG);

					// 设置按钮路径-- Level_1
					ActivityRunningConfig.getInstance().setButtonPathLevel_1(DesignInfo.CHAO_QIAN_GUAN_PENG_AN_ZHAUNG);

					//Intent intent = new Intent(V_Activity.this, V_zuankongActivity.class);
					startActivityForResult(intent, 1);
				}
			});
		 
		 maogan.setOnClickListener(new View.OnClickListener() {
				
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					Intent intent = new Intent(V_Activity.this, MainActivity.class);
					DesignInfo di = new DesignInfo_V_plus();
					Gson gson = new Gson();
					String diJson = gson.toJson(di);
					intent.putExtra("design_info", diJson);
					intent.putExtra("tunnel", tunnel);
					intent.putExtra("process", "锚杆");

					String rock_grade = getIntent().getStringExtra("rock_grade");
					intent.putExtra("rock_grade", rock_grade);
					intent.putExtra("subprocess", ProcessConst.SUB_XIAO_MAO_GAN);

					// 设置按钮路径-- Level_1
					ActivityRunningConfig.getInstance().setButtonPathLevel_1(DesignInfo.MAO_GAN);

					//Intent intent = new Intent(V_Activity.this, V_zuankongActivity.class);
					startActivityForResult(intent, 1);
				}
			});
		 
		 guawang.setOnClickListener(new View.OnClickListener() {
				
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					Intent intent = new Intent(V_Activity.this, MainActivity.class);
					DesignInfo di = new DesignInfo_V_plus();
					Gson gson = new Gson();
					String diJson = gson.toJson(di);
					intent.putExtra("design_info", diJson);
					intent.putExtra("tunnel", tunnel);
					intent.putExtra("process", "挂网");

					String rock_grade = getIntent().getStringExtra("rock_grade");
					intent.putExtra("rock_grade", rock_grade);
					intent.putExtra("subprocess", ProcessConst.SUB_XIAO_GUA_WANG);

					// 设置按钮路径-- Level_1
					ActivityRunningConfig.getInstance().setButtonPathLevel_1(DesignInfo.GUA_WANG);

					//Intent intent = new Intent(V_Activity.this, V_zuankongActivity.class);
					startActivityForResult(intent, 1);
				}
			});
		 
		 zuankong.setOnClickListener(new View.OnClickListener() {
				
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					Intent intent = new Intent(V_Activity.this, OffsetActivity.class);
					DesignInfo di = new DesignInfo_V_plus();
					Gson gson = new Gson();
					String diJson = gson.toJson(di);
					intent.putExtra("design_info", diJson);
					intent.putExtra("tunnel", tunnel);
					intent.putExtra("process", "超前钻孔");

					String rock_grade = getIntent().getStringExtra("rock_grade");
					intent.putExtra("rock_grade", rock_grade);
					intent.putExtra("subprocess", ProcessConst.SUB_XIAO_CHAO_QIAN_ZUAN_TAN);

					// 设置按钮路径-- Level_1
					ActivityRunningConfig.getInstance().setButtonPathLevel_1(DesignInfo.CHAO_QIAN_ZUAN_TAN);

					//Intent intent = new Intent(V_Activity.this, V_zuankongActivity.class);
					startActivityForResult(intent, 1);
				}
			});
			
		 V_shuoming.setOnClickListener(new View.OnClickListener() {
				
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					Intent intent = new Intent(V_Activity.this, RemarkActivity.class);
					DesignInfo di = new DesignInfo_V_plus();
					Gson gson = new Gson();
					String diJson = gson.toJson(di);
					intent.putExtra("design_info", diJson);
					intent.putExtra("tunnel", tunnel);
					intent.putExtra("process", "进尺");
					intent.putExtra("footage_id", footage_id);

					String rock_grade = getIntent().getStringExtra("rock_grade");
					intent.putExtra("rock_grade", rock_grade);
					intent.putExtra("subprocess", ProcessConst.SUB_ZONG_JIN_CHI_SHU);

					// 设置按钮路径-- Level_1
					ActivityRunningConfig.getInstance().setButtonPathLevel_1(DesignInfo.JIN_CHI_JI_SHUO_MING);

					//Intent intent = new Intent(V_Activity.this, V_zuankongActivity.class);
					startActivityForResult(intent, 1);
				}
			});
		 
		 back.setOnClickListener(new View.OnClickListener() {
				
				@Override
				public void onClick(View v) {
					V_Activity.this.finish();
				}
			});
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.v_, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
}
