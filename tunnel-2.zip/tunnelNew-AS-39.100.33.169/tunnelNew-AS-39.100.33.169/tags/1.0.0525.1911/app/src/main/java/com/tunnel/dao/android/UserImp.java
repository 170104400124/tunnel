package com.tunnel.dao.android;

import android.content.Context;
import android.database.Cursor;
import android.widget.Toast;

import com.tunnel.model.DutyData;
import com.tunnel.model.UserData;

import java.util.List;

import tunnel.LoginActivity;
import tunnel.model.MD5Utils;

/**
 * Created by Leon on 2019/5/6.
 */

public class UserImp {


    Context context = null;
    public UserImp(Context context) {
        this.context = context;
    }

    public List<UserData> getUser(String userId, String password) {
        String sql = "select * from user where user_id='" + userId +"' and password= '"+password+"'";
        List<UserData> list = AndroidUtils.query2JavaBeans(sql, context, UserData.class);

        return list;
    }


}
