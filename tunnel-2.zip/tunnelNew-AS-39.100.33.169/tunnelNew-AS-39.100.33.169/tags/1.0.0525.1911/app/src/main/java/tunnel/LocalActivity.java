package tunnel;

import com.jie.cameraimage.R;
import com.tunnel.dao.android.ProcessConst;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AbsListView;
import android.widget.AbsListView.OnScrollListener;

import tunnel.JDBC.DBOpenHelper;

import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.RelativeLayout;
import android.widget.TextView;

public class LocalActivity extends Activity {

	private TextView txtPlace;
	public static LocalActivity instance = null;
	ListView lv;
	RelativeLayout rl;
	DBOpenHelper dbHelper = null;
	TextView upload;
	mySimpleAdapter adapter;
	List<Map<String, Object>> list ;
	int totalNum;//数据总条数
	int pageSize=15;//每页显示的条数
	int totalPage;//总的页数
	int currentPage=1;//当前页码
	boolean isbottom=false;//判断是否到当前页码的底部
	String user_id;

	RadioButton btnHome;
	RadioButton btnLocal;
	RadioButton btnUpload;
	RadioButton btnMe;

	@Override
	protected void onResume() {
		super.onResume();
		SQLiteDatabase db = dbHelper.getReadableDatabase();
		String sql="select * from log left join process  on log.process_id=process.process_id";
		Cursor c=db.rawQuery(sql, null);
		totalNum=c.getCount();
		totalPage=(int)Math.floor(totalNum/pageSize) + 1;
		if(1==currentPage)
		{
			getData(currentPage);
		}
		adapter=new mySimpleAdapter(getApplicationContext(),list, mListener);
//		if(upload.getText() == "1")
//			upload.setText("已上传");
//		else if(upload.getText() == "0")
//			upload.setText("未上传");
		lv.setAdapter(adapter);
		adapter.notifyDataSetChanged();
	}

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_local);
		dbHelper = new DBOpenHelper(LocalActivity.this);
		SQLiteDatabase db = dbHelper.getReadableDatabase();
		txtPlace = (TextView) findViewById(R.id.place);
		SharedPreferences sp = getSharedPreferences("data", Context.MODE_PRIVATE);
		String txPlace = sp.getString("place", "");
		user_id = sp.getString("user_id", "");
		upload = (TextView) findViewById(R.id.local_isUpload);
		txtPlace.setText(txPlace);
		lv=(ListView) findViewById(R.id.lv);
		rl=(RelativeLayout) findViewById(R.id.rl);
		btnHome = (RadioButton) findViewById(R.id.radio_button0);
		btnLocal = (RadioButton) findViewById(R.id.radio_button1);
		btnUpload = (RadioButton) findViewById(R.id.radio_button2);
		btnMe = (RadioButton) findViewById(R.id.radio_button3);


		btnHome.setOnClickListener(new View.OnClickListener() {

			public void onClick(View v) {
				Intent intent = new Intent(LocalActivity.this, HomeActivity.class);
				startActivity(intent);
			}
		});
		btnUpload.setOnClickListener(new View.OnClickListener() {

			public void onClick(View v) {
				Intent intent = new Intent(LocalActivity.this, NoUploadActivity.class);
				startActivity(intent);
			}
		});
		btnMe.setOnClickListener(new View.OnClickListener() {

			public void onClick(View v) {
				Intent intent = new Intent(LocalActivity.this, MeActivity.class);
				startActivity(intent);
			}
		});

		String sql="select * from log left join process on log.process_id=process.process_id where log.user_id = ?";
		Cursor c=db.rawQuery(sql, new String[]{user_id});
		totalNum=c.getCount();
		totalPage=(int)Math.ceil((totalNum/pageSize));
		if(1==currentPage)
		{
			getData(currentPage);
		}
		adapter=new mySimpleAdapter(getApplicationContext(),list,  mListener);
		adapter.notifyDataSetChanged();
		lv.setAdapter(adapter);
		adapter.notifyDataSetChanged();
		lv.setOnScrollListener(new OnScrollListener() {

			@Override
			public void onScrollStateChanged(AbsListView view, int scrollState) {
				if(isbottom&&(scrollState == OnScrollListener.SCROLL_STATE_IDLE))
				{
					rl.setVisibility(View.VISIBLE);
				}
				else
				{
					rl.setVisibility(View.GONE);
				}
			}

			@Override
			public void onScroll(AbsListView view, int firstVisibleItem,
								 int visibleItemCount, int totalItemCount) {
				isbottom=((firstVisibleItem+visibleItemCount)==totalItemCount);
				Log.i("first=",firstVisibleItem+"");
				Log.i("visible=",visibleItemCount+"");
				Log.i("total=",totalItemCount+"");
			}
		});
		if(c != null){
			c.close();
		}
		db.close();
	}


	//点击加载更多的监听事件
	public void click(View v)
	{
		currentPage++;
		list.addAll(getData(currentPage));
		adapter.notifyDataSetChanged();
		rl.setVisibility(View.GONE);
	}
	//获取当前页的数据
	@SuppressLint("NewApi")
	public List<Map<String, Object>>  getData(int currentPage){
		dbHelper = new DBOpenHelper(LocalActivity.this);
		SQLiteDatabase db = dbHelper.getReadableDatabase();
		int index = (currentPage-1)*pageSize;//0   0   1  20   2  40
		String sql = "select * from log left join process on process.process_id = log.process_id where user_id = ? order by log.save_time desc limit ?,? ";//从哪一个位置    请求多少条
		Cursor c = db.rawQuery(sql, new String[]{user_id, index+"",pageSize+""});
		return getCursorList(c);

	}
	@SuppressLint("NewApi")
	public List<Map<String, Object>> getCursorList(Cursor c){
		list = new ArrayList<Map<String,Object>>();
		String[] coloms = c.getColumnNames();//[_id,name] 有多少字段项
		while(c.moveToNext()){
			Map<String, Object> map = new HashMap<String, Object>();
			for(int i=0;i<coloms.length;i++){
				String key = coloms[i];
				Object values = null;
				int type = c.getType(i);
				switch (type) {
					case Cursor.FIELD_TYPE_BLOB:
						values = c.getBlob(i);
						break;
					case Cursor.FIELD_TYPE_FLOAT:
						values = c.getFloat(i);
						break;
					case Cursor.FIELD_TYPE_INTEGER:
						values = c.getInt(i);
						break;
					case Cursor.FIELD_TYPE_STRING:
						values = c.getString(i);
						break;

					default:
						break;
				}
				map.put(key, values);
			}

			list.add(map);
		}

		return list;

	}

	public Map<String, Class> subprocess2Activity = null;

	/**
	 * 根据子流程名，获得对应的Activity
	 * @param subProcess
	 * @return
	 */
	protected Class getActivity(String subProcess) {
		if(null == subprocess2Activity) {
			subprocess2Activity = new HashMap<String, Class>();
			subprocess2Activity.put(ProcessConst.SUB_XIAO_MAO_PENG, MainActivity.class);
			subprocess2Activity.put(ProcessConst.SUB_XIAO_DAO_GUAN_ZHU_JIANG, MainActivity.class);
			subprocess2Activity.put(ProcessConst.SUB_XIAO_DAO_GUAN_AN_ZHUANG, MainActivity.class);
			subprocess2Activity.put(ProcessConst.SUB_GUAN_PENG_CHEN_PING, MainActivity.class);
			subprocess2Activity.put(ProcessConst.SUB_GUAN_PENG_ZHU_JIANG, MainActivity.class);
			subprocess2Activity.put(ProcessConst.SUB_XIAO_ZHI_LI_GANG_GONG_JIA, MainActivity.class);
			subprocess2Activity.put(ProcessConst.SUB_GUAN_PENG_AN_ZHUANG, MainActivity.class);
			subprocess2Activity.put(ProcessConst.SUB_XIAO_MAO_GAN, MainActivity.class);
			subprocess2Activity.put(ProcessConst.SUB_XIAO_GUA_WANG, MainActivity.class);

			subprocess2Activity.put(ProcessConst.SUB_XIAO_CHAO_QIAN_ZUAN_TAN, OffsetActivity.class);

			subprocess2Activity.put(ProcessConst.SUB_ZONG_JIN_CHI_SHU, RemarkActivity.class);

			subprocess2Activity.put(ProcessConst.SUB_WEI_YAN_BIAN_GENG, RockChangeActivity.class);
		}
		return subprocess2Activity.get(subProcess);
	}


	private void jump2Activity(Integer position) {
		// 设置按钮路径-- Level_1
		Map<String, Object> itemMap = list.get(position);
		String rock_grade = itemMap.get("rock_grade").toString();
		String subprocess = itemMap.get("subprocess").toString();
		String key = itemMap.get("key").toString();
		String old_rock = "";
		if(null != itemMap.get("old_rock"))
		{
			old_rock = itemMap.get("old_rock").toString();
		}
		String new_rock = "";
		if(null != itemMap.get("new_rock"))
		{
			new_rock = itemMap.get("new_rock").toString();
		}
		String offset = "";
		if(null != itemMap.get("report_footage"))
		{
			offset = itemMap.get("report_footage").toString();
		}
		String explanation = "";
		if(null != itemMap.get("explanation"))
		{
			explanation = itemMap.get("explanation").toString();
		}

		Class targetActivity = getActivity(subprocess);

		Intent intent = new Intent(LocalActivity.this, targetActivity);

		intent.putExtra("rock_grade", rock_grade);
		intent.putExtra("subprocess", subprocess);
		intent.putExtra("explanation", explanation);
		intent.putExtra("offset", offset);
		intent.putExtra("key", key);
		//intent.putExtra("footage_id", footage_id);

		intent.putExtra("new_rock", new_rock);
		intent.putExtra("old_rock", old_rock);

		intent.putExtra("process", subprocess);

		startActivityForResult(intent, 1);
	}

	/**
	 * 实现类，响应按钮点击事件
	 */
	private mySimpleAdapter.MyClickListener mListener = new mySimpleAdapter.MyClickListener() {
		@Override
		public void onClick(View v) {
			mySimpleAdapter.ViewHolder holder = (mySimpleAdapter.ViewHolder)v.getTag();
			myOnClick(holder.position, v);
		}

		@Override
		public void myOnClick(Integer position, View v) {
			jump2Activity(position);
		}
	};
}
