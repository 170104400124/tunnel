import com.tunnel.model.DutyData;

import org.junit.Test;

import java.util.List;

import tunnel.duty.DutyParser;

import static org.junit.Assert.*;

public class DutyParserTest {
    @Test
    public void testParser() throws Exception {
        String json = "{\"duty\":[{\"id\":41,\"user_id\":\"2\",\"tunnel_id\":\"乌石咀隧道进口\"}],\"user\":{\"user_id\":\"2\",\"user_name\":\"测试2222\",\"password\":\"2\",\"position\":\"负责人\",\"access\":\"其他\",\"available\":1}}";
        DutyParser parser = new DutyParser();
        parser.parse(json, null);
        List<DutyData> duty = parser.getDutyDataList();
        assertEquals(duty.get(0).getUser_id(), "2");

        String positionBlankJson = "{\"duty\":[{\"id\":41,\"user_id\":\"2\",\"tunnel_id\":\"乌石咀隧道进口\"}],\"user\":{\"user_id\":\"2\",\"user_name\":\"测试2222\",\"password\":\"2\",\"position\":\"\",\"access\":\"其他\",\"available\":1}}";
        parser = new DutyParser();
        parser.parse(positionBlankJson, null);
        duty = parser.getDutyDataList();
        assertEquals(duty.get(0).getUser_id(), "2");

    }
}
